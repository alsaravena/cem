<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
 ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">

<link rel="stylesheet" href="css/estilos.css">
<title>Caracterización Étnica Municipal</title>
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP $V_Clase->gra_menu_general();	?>


    <section class="main row">
<?PHP if(($_GET['mod']==51 and $_GET['opcion']==3) or ($_GET['mod']==51 and $_GET['opcion']==4)){##Inicio?>

 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 <div class="text-center H2">Listado de Fichas en Histórico <br />Sólo tiene validez para efectos de información.</div>
 <table width="100%" border="1" class="table-bordered">
  <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="text-center text-uppercase h4">
		ENCUESTA: CARACTERIZACION DEMOGRAFICA Y SOCIOECONOMICA DE LA POBLACION 
		<?PHP $dato=$V_Clase->v_ficha($_GET['token']);
			if($dato[0]['GRUPO']==2){?>INDIGENA<?PHP }elseif($dato[0]['GRUPO']==1){?>AFROCOLOMBIANO<?PHP } ?> - EN EL MUNICIPIO DE SARAVENA DEPARTAMENTO DE ARAUCA    
    </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4" class="text-center text-uppercase h4 bg-primary">A. Datos Identificación</td>
  </tr> 
  <tr>
    <td width="25%" class="h3"><?PHP echo $V_Clase->trae_pregunta("A1"); ?></td>
    <td width="25%" class="h3 text-center"><?PHP echo $dato[0]['A1']; ?></td>
    <td width="25%"><?PHP echo $V_Clase->trae_pregunta("A4");?> : <?PHP echo $dato[0]['A4'];?></td>
    <td width="25%"><?PHP echo $V_Clase->trae_pregunta("A5");?> : <?PHP echo $dato[0]['A5'];?></td>
  </tr>
  <tr>
    <td><?PHP echo $V_Clase->trae_pregunta("A2");?> : <?PHP echo $dato[0]['A2'].' / '.$V_Clase->trae_departamento($dato[0]['A2']);?></td>
    <td><?PHP echo $V_Clase->trae_pregunta("A3");?> : <?PHP echo $dato[0]['A3'].' / '.$V_Clase->trae_municipio($dato[0]['A3'],$dato[0]['A2']);?></td>
 	<td><?PHP echo $V_Clase->trae_pregunta("A6");?> : <?PHP echo $dato[0]['A6'];?></td>
    <td><?PHP echo $V_Clase->trae_pregunta("A7");?> : <?PHP echo $dato[0]['A7'];?></td>
  </tr>
  <tr>
    <td colspan="4" class="text-left">Gobierno <?PHP if($dato[0]['GRUPO']==1){ ?>AfroColombiano <?PHP }elseif($dato[0]['GRUPO']==2){?>Indigena<?PHP }?> >     	
    	<b>A8:</b> <?PHP echo $dato[0]['A8'];?> <b>A9:</b> <?PHP echo $dato[0]['A9'];?> <b>A10:</b> <?PHP echo $dato[0]['A10'];?> 
    	<b>A11:</b> <?PHP echo $dato[0]['A11'];?> <b>A12:</b> <?PHP echo $dato[0]['A12'];?> <b>A13:</b> <?PHP echo $dato[0]['A13'];?> 
        <b>A14:</b> <?PHP echo $dato[0]['A14'];?> <b>A15:</b> <?PHP echo $dato[0]['A15'];?> <b>A16:</b> <?PHP echo $dato[0]['A16'];?> 
        <b>A17:</b> <?PHP echo $dato[0]['A17'];?> <b>A18:</b> <?PHP echo $dato[0]['A18'];?></td>
  </tr>   
  <tr>
    <td colspan="4" class="text-left">Control de Trabajo >
    	<b>A19:</b> <?PHP echo $dato[0]['A19'];?> <b>A20:</b> <?PHP echo $dato[0]['A20'];?> <b>A21:</b> <?PHP echo $dato[0]['A21'];?> 
        <b>A22:</b> <?PHP echo $dato[0]['A22'];?> <b>A23:</b> <?PHP echo $dato[0]['A23'];?>
 </td>
  </tr>
  <tr>
    <td colspan="4" class="text-center text-uppercase h4 bg-primary">B. Datos Vivienda</td>
  </tr>   
  <tr>
    <td colspan="2">Propiedad y Estado >
    <b>B1:</b> <?PHP echo $dato[0]['B1'];?> <b>B2:</b> <?PHP echo $dato[0]['B2'];?> <b>B3:</b> <?PHP echo $dato[0]['B3'];?>  <b>B4:</b> <?PHP echo $dato[0]['B4'];?>
    <b>B5:</b> <?PHP echo $dato[0]['B5'];?> <b>B6:</b> <?PHP echo $dato[0]['B6'];?> <b>B7:</b> <?PHP echo $dato[0]['B7'];?> <b>B8:</b> <?PHP echo $dato[0]['B8'];?>
    </td>
    <td colspan="2">Servicios Publicos >
	<b>B8:</b> <?PHP echo $dato[0]['B8'];?> <b>B9:</b> <?PHP echo $dato[0]['B9'];?> <b>B10:</b> <?PHP echo $dato[0]['B10'];?>  <b>B11:</b> <?PHP echo $dato[0]['B11'];?>
    <b>B12:</b> <?PHP echo $dato[0]['B12'];?> <b>B13:</b> <?PHP echo $dato[0]['B13'];?> <b>B14:</b> <?PHP echo $dato[0]['B14'];?> 
    </td>
  </tr>    
  <tr>
    <td colspan="4">Información Productiva > 
    <b>B15:</b> <?PHP echo $dato[0]['B15'];?> <b>B16:</b> <?PHP echo $dato[0]['B16'];?>   
    <b>B17:</b> <?PHP echo $dato[0]['B17'];?> <b>B18:</b> <?PHP echo $dato[0]['B18'];?>   
    <b>B19:</b> <?PHP echo $dato[0]['B19'];?> <b>B20:</b> <?PHP echo $dato[0]['B20'];?>   
    <b>B21:</b> <?PHP echo $dato[0]['B21'];?> <b>B22:</b> <?PHP echo $dato[0]['B22'];?>   
    <b>B23:</b> <?PHP echo $dato[0]['B23'];?> <b>B24:</b> <?PHP echo $dato[0]['B24'];?>   
    <b>B25:</b> <?PHP echo $dato[0]['B25'];?> <b>B26:</b> <?PHP echo $dato[0]['B26'];?>
    </td>   
  </tr>
  <tr>
    <td colspan="4" class="text-center text-uppercase h4 bg-primary">C. Familia</td>
  </tr>   
  <tr>
    <td>Alimentación > <b>C1:</b> <?PHP echo $dato[0]['C1'];?> <b>C2:</b> <?PHP echo $dato[0]['C2'];?>  <b>C3:</b> <?PHP echo $dato[0]['C3'];?></td>
    <td>Acceso a Servicios de Salud > <b>C4:</b> <?PHP echo $dato[0]['C4'];?> <b>C5:</b> <?PHP echo $dato[0]['C5'];?>  </td>
    <td>Apropiación Tecnologia > <b>C6:</b> <?PHP echo $dato[0]['C6'];?> <b>C7:</b> <?PHP echo $dato[0]['C7'];?> <b>C8:</b> <?PHP echo $dato[0]['C8'];?> </td>
    <td>Victimas > <b>C9:</b> <?PHP echo $dato[0]['C9'];?> <b>C10:</b> <?PHP echo $dato[0]['C10'];?>  <b>C11:</b> <?PHP echo $dato[0]['C11'];?> <b>C12:</b> <?PHP echo $dato[0]['C12'];?> <b>C13:</b> <?PHP echo $dato[0]['C13'];?> </td>
  </tr>
  <tr>
    <td colspan="4" class="text-center text-uppercase h4 bg-primary">D. Integrantes</td>
  </tr>   
    <?PHP 
	if($_GET['mod']==51 and $_GET['opcion']==3){  $dain=$V_Clase->v_integrantes_ficha($_GET['token']);
		}elseif($_GET['mod']==51 and $_GET['opcion']==4){ $dain=$V_Clase->v_integrantes_id($_GET['id']);
		}
	
	for ($i=0;$i<sizeof($dain);$i++){
	 ?>
  <tr>
    <td  colspan="4">
    <b>D1:</b> <?PHP echo $dain[$i]['D1'];?> <b>D2:</b> <?PHP echo $dain[$i]['D2'];?> 
    <b>D3:</b> <?PHP echo $dain[$i]['D3'];?> <b>D4:</b> <?PHP echo $dain[$i]['D4'];?>
    <b>D5:</b> <?PHP echo $dain[$i]['D5'];?> <b>D6:</b> <?PHP echo $dain[$i]['D6'];?>
    <b>D7:</b> <?PHP echo $dain[$i]['D7'];?> <b>D8:</b> <?PHP echo $dain[$i]['D8'].' - '.$V_Clase->trae_respuesta('D8',$dain[$i]['D8']);?>
    <b>D9:</b> <?PHP echo $dain[$i]['D9'];?> <b>D10:</b> <?PHP echo $dain[$i]['D10'];?>
    <b>D11:</b> <?PHP echo $dain[$i]['D11'];?> <b>D12:</b> <?PHP echo $dain[$i]['D12'];?> 
    <b>D13:</b> <?PHP echo $dain[$i]['D13'];?> <b>D14:</b> <?PHP echo $dain[$i]['D14'];?>
    <b>D15:</b> <?PHP echo $dain[$i]['D15'];?> <b>D16:</b> <?PHP echo $dain[$i]['D16'];?>
    <b>D17:</b> <?PHP echo $dain[$i]['D17'];?> <b>D18:</b> <?PHP echo $dain[$i]['D18'];?>
    <b>D19:</b> <?PHP echo $dain[$i]['D19'];?> <b>D20:</b> <?PHP echo $dain[$i]['D20'];?>
    
    <b>D21:</b> <?PHP echo $dain[$i]['D21'];?> <b>D22:</b> <?PHP echo $dain[$i]['D22'];?> 
    <b>D23:</b> <?PHP echo $dain[$i]['D23'];?> <b>D24:</b> <?PHP echo $dain[$i]['D24'];?>
    <b>D25:</b> <?PHP echo $dain[$i]['D25'];?> <b>D26:</b> <?PHP echo $dain[$i]['D26'];?>
    <b>D27:</b> <?PHP echo $dain[$i]['D27'];?> <b>D28:</b> <?PHP echo $dain[$i]['D28'];?>
    <b>D29:</b> <?PHP echo $dain[$i]['D29'];?> <b>D30:</b> <?PHP echo $dain[$i]['D30'];?>
    <b>D31:</b> <?PHP echo $dain[$i]['D31'];?> <b>D32:</b> <?PHP echo $dain[$i]['D32'];?>
    <b>D33:</b> <?PHP echo $dain[$i]['D33'];?> <b>D34:</b> <?PHP echo $dain[$i]['D34'];?>
    <b>D35:</b> <?PHP echo $dain[$i]['D35'];?>   
    </td>
  </tr>
    <?PHP }
	if(sizeof($dain)==0){
	 ?>
  <tr>
    <td colspan="4"> No tiene Integrantes la Ficha, Terminela. </td>
  </tr>
     <?PHP } ?>  

</table>
                    
<!-- Final Ver Ficha-->  
 
    
        </article>
        <?PHP }## Final de Ingresar?>     

                  
    </section>
    
</div>
<?PHP $V_Clase->gra_pie_pagina();?>


<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="js/funciones.js"></script>

<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
