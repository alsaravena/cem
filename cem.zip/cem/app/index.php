<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
	### Datos para Paginacion 
	if (isset($_GET["pos"]))
	{
		$inicio=$_GET["pos"];
	}else
	{
		$inicio=0;
	}### Datos para Paginacion 		
 ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">-->
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/estilos.css">
<title>Caracterización Étnica Municipal</title>
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP 
	if($_SESSION['user_rol']==1 or $_SESSION['user_rol']==2 or $_SESSION['user_rol']==3 or $_SESSION['user_rol']==4 or $_SESSION['user_rol']==7){$V_Clase->gra_menu_general(); }
	elseif($_SESSION['user_rol']==5 or $_SESSION['user_rol']==6){
			$V_Clase->gra_menu_testigo();	
		}
?>


    <section class="main row">
<?PHP if($_GET['mod']==54 and $_GET['opcion']==13){?>
 		<article class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Ficha Nucleo Familiar</h3>
              </div>
              <div class="panel-body">
				
                <form class="form-inline" name="form" action="Buscar.php" method="get" enctype="multipart/form-data">
                  <div class="form-group">
                    <label class="sr-only" for="placa">Ingrese Número Ficha</label>
                    <div class="input-group">
                      <div class="input-group-addon"><span class="glyphicon glyphicon-search"></span></div>
                      <input type="number" class="form-control" id="s" placeholder="Ingrese Número Ficha" name="s" autocomplete="off" maxlength="8" required>                    
                    </div>
                  </div>
                    <input type="submit" name="Buscar" class="btn btn-success" value="Buscar" >
                    <input type="hidden" name="mod" value="53">
                    <input type="hidden" name="opcion" value="2">
                </form>                

              </div>
            </div>
        </article>
        
 		<article class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Integrante Nucleo</h3>
              </div>
              <div class="panel-body">

                <form class="form-inline" name="form" action="Buscar.php" method="get" enctype="multipart/form-data">
                  <div class="form-group">
                    <label class="sr-only" for="placa">Ingrese Documento Identidad</label>
                    <div class="input-group">
                      <div class="input-group-addon"><span class="glyphicon glyphicon-search"></span></div>
                      <input type="number" class="form-control" id="s" placeholder="Documento Identidad" name="s" autocomplete="off" maxlength="12" required>                    
                    </div>
                  </div>
                    <input type="submit" name="BuscarDI" class="btn btn-success" value="Buscar" >
                    <input type="hidden" name="mod" value="53">
                    <input type="hidden" name="opcion" value="1">
                </form>  

              </div>
            </div>
        </article>        
 		<article class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Generar Certificado</h3>
              </div>
              <div class="panel-body">

                <form class="form-inline" name="form" action="Buscar.php" method="get" enctype="multipart/form-data">
                  <div class="form-group">
                    <label class="sr-only" for="placa">Ingrese Numero Documento</label>
                    <div class="input-group">
                      <div class="input-group-addon"><span class="glyphicon glyphicon-search"></span></div>
                      <input type="number" class="form-control" id="s" placeholder="Ingrese Cedula" name="s" autocomplete="off" maxlength="12" required>                    
                    </div>
                  </div>
                    <input type="submit" name="BuscarDIIM" class="btn btn-success" value="Buscar" >
                    <input type="hidden" name="mod" value="53">
                    <input type="hidden" name="opcion" value="3">
                </form> 
                   

              </div>
            </div>
        </article>        



		<article class="col-xs-12 col-sm-12 col-md-6 col-lg-6">

        </article>


		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <ul class="nav nav-pills nav-justified">
            <li class="active"><a data-toggle="pill" href="#mg">Madres Gestantes</a></li>
            <li><a data-toggle="pill" href="#rd">Renovación Documentos</a></li>
          </ul>
          
          <div class="tab-content">
            <div id="mg" class="tab-pane fade in active">

            <div class="panel panel-primary">

                  <table class="table table-condensed table-hover">
                  <tr>
                    <th>A1</th>
                    <th>Nombres</th>
                    <th>Fecha Encuesta</th>
                    <th>Gestación</th>
                    <th>Opciones</th>
                  </tr>
				<?php $dato=$V_Clase->pag_gestantes($inicio,$porpagina,base64_decode($_GET['opcion'])); 
                for ($i=0;$i<sizeof($dato);$i++){      ?>                  
                  <tr>
                   	<td><?PHP echo $dato[$i]['A1'];?></td>
                   	<td><?PHP echo $dato[$i]['D1'].' '.$dato[$i]['D2'].' '.$dato[$i]['D3'].' '.$dato[$i]['D4'];?></td>
                    <td><?PHP echo $dato[$i]['A20']; ?></td>
                    <td><?PHP echo ' Meses= '. $dato[$i]['meses']; 		?></td>                    
                   	<td>
                       <a class="btn btn-success" onClick="window.location='VerDatos.php?mod=51&opcion=2&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-eye-open"></span> Visualizar Ficha</a>
                    </td>
                    
                  </tr>   
                 <?PHP } 
				 
                if(sizeof($dato) ==0){
                 ?>    
                <tr>
                    <td align=center colspan="5">No hay Datos.</td>
                </tr>
                <?php } ?>                                                  
                  </table>

            </div>

            </div>
            <div id="rd" class="tab-pane fade">
              
			<div class="panel panel-primary">

                  <table class="table table-condensed table-hover">
                  <tr>
                    <th>A1</th>
                    <th>Nombres</th>
                    <th>Fecha Nacimiento</th>
                    <th>Edad</th>
                    <th>Opciones</th>
                  </tr>
				<?php $dain=$V_Clase->pag_integrantes_rc_ti($inicio,$porpagina,base64_decode($_GET['opcion'])); 
                for ($j=0;$j<sizeof($dain);$j++){      ?>                  
                  <tr>
                   	<td><?PHP echo $dain[$j]['A1'];?></td>
                   	<td><?PHP echo $dain[$j]['D1'].' '.$dain[$j]['D2'].' '.$dain[$j]['D3'].' '.$dain[$j]['D4'];?></td>
                    <td><?PHP echo $dain[$j]['D11']; 		?></td>
                    <td><?PHP echo ' Años = '. $dain[$j]['pers_annos'].' Meses= '. $dain[$j]['pers_meses'].' Dias= '. $dain[$j]['pers_dias']; 		?></td>
                   	<td>
                       <a class="btn btn-primary" onClick="window.location='VerDatos.php?mod=51&opcion=2&token=<?PHP echo base64_encode($dain[$j]['A1']); ?>&id=<?PHP echo base64_encode($dain[$j]['ID']); ?>'"><span class="glyphicon glyphicon-eye-open"></span> Visualizar Ficha</a>
                    </td>
                    
                  </tr>   
                 <?PHP } 
				 
                if(sizeof($dain) ==0){
                 ?>    
                <tr>
                    <td align=center colspan="5">No hay Datos.</td>
                </tr>
                <?php } ?>                                                  
                  </table>

            </div>              
              
            </div>
          </div>
          </article>

		<?PHP 		}## Final de Inicio ?>

    
        <?PHP if($_GET['mod']==54 and $_GET['opcion']==14){##Salir?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Cerrar Sesión del Software</h3>
              </div>
              <div class="panel-body">
				<div><h2 class="alert-warning">Cerrada la Sesión</h2></div>
				<?php  
				
				session_destroy();
				echo "<script type='text/javascript'>
					window.location='../index.php';
				</script>";?>
              </div>
            </div>
        </article>
        <?PHP }## Final de Cerrar Sesion?>     
        
       <?PHP if($_GET['mod']==54 and $_GET['opcion']==11){?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Configuración General</h3>
              </div>
              <div class="panel-body">
				
                <form name="form" action="ejecutar.php" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                   <label for="dep">Departamento</label>
                   <?PHP if($conf[0]['con_departamento']!=""){ $cargar=$conf[0]['con_departamento']; }else{ $cargar="";	} 
				   $V_Clase->comboDepartamento($cargar); ?>
                    
                  </div>
                  <div class="form-group">
                  	<label for="mun">Elige un Municipio:</label>
                    <div id="div_municipio_edes" >
                    	<?PHP 
						if($conf[0]['con_municipio']!=""){ $cargar=$conf[0]['con_departamento']; 	}else{
							?>
                            <select class="form-control" id="mun" name="mun">
                                <option value="0">Seleccione el Municipio</option>
                            </select>							
						<?PHP
							}
							$V_Clase->comboMunicipio($cargar,$conf[0]['con_municipio']);
						?>
                    </div>
                  </div> 
                  <div class="form-group">
                  	<label for="te">Tipo Elección:</label>
                    <div id="div_municipio_edes" >
                    	<select class="form-control" id="te" name="te">
                        	<option value="0">Seleccione Elección</option>
                            <option value="1" <?PHP if($conf[0]['con_tipoeleccion']==1){?> selected <?PHP }?>>Gobernador</option>
				            <option value="2"<?PHP if($conf[0]['con_tipoeleccion']==2){?> selected <?PHP }?>>Alcalde</option>
                        </select>
                    </div>
                  </div>                                    
                  <?PHP 
					if(sizeof($conf>0)){ ?> 
                  <button type="submit" class="btn btn-success">Actualizar</button>                    
                  <input type="hidden" name="operacion" value="modConfiguracion">
                  <input type="hidden" name="id" value="<?PHP echo $conf[0]['con_id'];?>">
                  <?PHP  }else{		?>
                  <button type="submit" class="btn btn-primary">Ingresar</button>
                  <input type="hidden" name="operacion" value="regConfiguracion">
				  <?PHP }?>
                </form>

              </div>
            </div>
        </article>
        <?PHP }## Final de Configuracion General		 ?>   

          
    </section>
    
</div>

<?PHP $V_Clase->gra_pie_pagina();?>



<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="js/funciones.js"></script>
  <script>
  
  $( function() {
    $( document ).tooltip();
	$('#home').tab('show');
	$('#myTabs a[href="#profile"]').tab('show') // Select tab by name
  } );
  </script>  
  </script>

<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
