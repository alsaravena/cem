<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
	### Datos para Paginacion 
	if (isset($_GET["pos"]))
	{
		$inicio=$_GET["pos"];
	}else
	{
		$inicio=0;
	}### Datos para Paginacion 		
	?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/estilos.css">
<script type="text/javascript" src="js/loader.js"></script>
<title>Caracterización Étnica Municipal</title>
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP 
	$V_Clase->gra_menu_general();	
?>


    <section class="main row">

        <?PHP if($_GET['mod']==53 and $_GET['opcion']==2){##Inicio?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="table-responsive">
<table class="table table-condensed table-hover table-striped">
<thead>
  <tr>
    <th colspan="4" class="h3 text-center"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></th>
  </tr>
  <tr>
    <th>Ficha</th>
    <th>A17</th> 
    <th>Estado</th> 
    <th>Operaciones</th>
  </tr>
</thead>  
<?PHP 
$dato=$V_Clase->pag_fichas_busqueda($_GET['s'],$inicio,$porpagina);
## Inicio For Recorrido
for ($i=0;$i<sizeof($dato);$i++){
?>
  <tr>
    <td><?PHP echo $dato[$i]['A1'];?></td>
    <td><?PHP echo $V_Clase->trae_respuesta('A17',$dato[$i]['A17']);?></td>
    <td><?PHP if($dato[$i]['ESTADO']==1){echo '<b class="text-danger">En Edición</b>';
		}elseif($dato[$i]['ESTADO']==2) {echo '<b class="text-success">Terminada</b>';}?></td>
    <td><?PHP if($dato[$i]['ESTADO']==1){
		
			if($dato[$i]['B1']==Null){
		?>
			<a class="btn btn-success" href="javascript:void(0);" title="Continuar con Carga de Datos B" onClick="window.location='CargarDatos.php?mod=50&opcion=3&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-2'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>    

		<?PHP }elseif($dato[$i]['C1']==Null){?>
			<a class="btn btn-success" href="javascript:void(0);" title="Continuar con Carga de Datos C" onClick="window.location='CargarDatos.php?mod=50&opcion=4&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-3'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>			
			
		<?PHP }else{?>
			<a class="btn btn-success" href="javascript:void(0);" title="Continuar con Carga de Datos D" onClick="window.location='CargarDatos.php?mod=50&opcion=5&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-4'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>			            
		<?PHP	}
		
		
		}elseif($dato[$i]['ESTADO']==2) {?>
    		<a class="btn btn-info" href="javascript:void(0);" title="Visualizar toda la Ficha" onClick="window.location='VerDatos.php?mod=51&opcion=1&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-eye-open"></span> Visualizar</a>    
		<?PHP }?>
        
        <?PHP if($dato[$i]['ESTADO']==2 and $dato[$i]['ARCHIVO'] == 'SIN_ARCHIVO.pdf') {?>
        <a class="btn btn-success" href="javascript:void(0);" title="Cargar Archivo Ficha Escaneada" onClick="window.location='CargarDatos.php?mod=51&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-paperclip"></span> Cargar Ficha</a>
        <?PHP } ?>
        <?PHP if($dato[$i]['ARCHIVO'] != 'SIN_ARCHIVO.pdf') {?>
        <a class="btn btn-primary" target="_blank" onclick="window.location='./files/<?PHP echo $dato[$i]['ARCHIVO']; ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Descargar Ficha</a>
    	<?PHP } ?>
        <a class="btn btn-success" href="javascript:void(0);" title="Ver Novedades" onClick="window.location='VerDatos.php?mod=51&opcion=7&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-list"></span> Novedades</a>
        
        <a class="btn btn-success" href="javascript:void(0);" title="Modificar Datos Ficha" onClick="window.location='CargarDatos.php?mod=51&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-edit"></span> Modificar</a>                
</td>  
  </tr>
<?PHP }## Final For Recorrido
if(sizeof($dato) ==0){
 ?>    
<tr>
	<td colspan="4">No hay Datos.</td>
</tr>
<?PHP } ?>
</table>

    	</div>
        </article>
        

        <?PHP }elseif(($_GET['mod']==53 and $_GET['opcion']==1) or ($_GET['mod']==53 and $_GET['opcion']==3)){##Reporte Integrantes?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="table-responsive">
<table class="table table-condensed table-hover table-striped">
<thead>
  <tr>
    <th colspan="6" class="h3 text-center"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></th>
  </tr>
  <tr>
    <th>Ficha</th>
    <th>D8</th>
    <th>D7</th>
    <th>A17</th> 
    <th>Estado</th> 
    <th>Operaciones</th>
  </tr>
</thead>  
<?PHP 
$dato=$V_Clase->pag_integrantes_busqueda($_GET['s'],$inicio,$porpagina);
## Inicio For Recorrido
for ($i=0;$i<sizeof($dato);$i++){
?>
  <tr>
    <td><?PHP echo $dato[$i]['A1'];?></td>
    <td><?PHP echo $dato[$i]['D8'].' - '.$V_Clase->trae_respuesta('D8',$dato[$i]['D8']);?></td>
    <td><?PHP echo $dato[$i]['D7'];?></td>        
    <td><?PHP echo $dato[$i]['D1'].' '.$dato[$i]['D2'].' '.$dato[$i]['D3'].' '.$dato[$i]['D4'];?></td>
    <td><?PHP if($dato[$i]['VIVO']==1){echo '<b class="text-danger">Vivo</b>';
		}elseif($dato[$i]['VIVO']==2) {echo '<b class="text-success">Fallecido</b>';}?></td>
    <td>
    		<a class="btn btn-info btn-sm" onClick="window.location='VerDatos.php?mod=51&opcion=2&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-eye-open"></span> Visualizar Ficha</a>    

        <?PHP if($dato[$i]['ARCHIVO_DI'] == 'SIN_ARCHIVO_DI.pdf') {?>
        <a class="btn btn-success btn-sm" href="javascript:void(0);" title="Cargar Documento de Identidad" onClick="window.location='CargarDatos.php?mod=51&opcion=16&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-paperclip"></span> Cargar DI</a>
        <?PHP } ?>
        <?PHP if($dato[$i]['ARCHIVO_DI'] != 'SIN_ARCHIVO_DI.pdf') {?>
        <a class="btn btn-primary btn-sm" title="Descargar Documento de Identidad" target="_blank" onclick="window.location='./files/<?PHP echo $dato[$i]['ARCHIVO_DI']; ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Descargar DI</a>
    	<?PHP } ?>
        
		<?PHP if($dato[$i]['ARCHIVO_DI'] != 'SIN_ARCHIVO_DI.pdf') {?>
        <a class="btn btn-primary btn-sm" title="Descargar Certificado" target="_blank" onclick="window.location='Generar_PDF.php?mod=53&opcion=8&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Certificado</a>
    	<?PHP } ?>

<!-- Inicio Generar Certificado-->
<div class="btn-group">
          <button class="btn btn-warning btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="glyphicon glyphicon-certificate"></span> Certificados <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=8&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Registro</a></li>
            
            <?PHP if($dato[$i]['D9']==1){?>
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=10&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Libreta Militar</a></li>
            <?PHP } ?>
            
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=11&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Afiliación Salud</a></li>

            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=12&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Duplicado Documento</a></li> 
            
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=13&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Laboral</a></li>            

          </ul>
        </div>
<!-- Final Generar Certificado-->


        <div class="btn-group">
          <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="glyphicon glyphicon-edit"></span> Opciones <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li><a href="CargarDatos.php?mod=50&opcion=10&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>#tabs-4" title="Modificar Datos D. Integrante">Modificar</a></li>
            <li><a href="CargarDatos.php?mod=50&opcion=14&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Mover Integrante de la Ficha">Mover de Ficha</a></li>
            <?PHP if($dato[$i]['VIVO']!=2){?>
            <li><a href="CargarDatos.php?mod=50&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Cambiar Estado Vivo a Fallecido">Mover a Fallecido</a></li>
            <?PHP } ?>
            <?PHP if($dato[$i]['VIVO']!=1){?>
             <li><a href="CargarDatos.php?mod=50&opcion=16&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Cambiar Estado Fallecido a Vivo">Mover a Vivo</a></li>
             <?PHP } ?>
          </ul>
        </div>

    	
</td>  
  </tr>
  <tr>
  	<td colspan="6">
    <?PHP if($_GET['opcion']==3){ ?>
    <div class="text-success text-center bg-success h4">Se ha encontrado un Resultado, Se generara el Certificado en PDF para que lo imprima</div>
	<meta http-equiv="refresh" content="10;URL=Generar_PDF.php?mod=53&opcion=8&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>">

<?PHP }?>
    
    </td>
  </tr>
  
<?PHP }## Final For Recorrido
if(sizeof($dato) ==0){
 ?>    
<tr>
	<td colspan="4">No hay Datos.</td>
</tr>
<?PHP } ?>
</table>
 
 
    	</div>
        </article>        

                 
		<?PHP }## Final de Ingresar?>     

                  
    </section>
    
</div>
<?PHP $V_Clase->gra_pie_pagina();?>


<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>

<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
