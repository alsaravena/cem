<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
	### Datos para Paginacion 
	if (isset($_GET["pos"]))
	{
		$inicio=$_GET["pos"];
	}else
	{
		$inicio=0;
	}### Datos para Paginacion 		
 ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">-->
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/estilos.css">
<title>Caracterización Étnica Municipal</title>
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP 
	if($_SESSION['user_rol']==1 or $_SESSION['user_rol']==2 or $_SESSION['user_rol']==3 or $_SESSION['user_rol']==4 or $_SESSION['user_rol']==7){$V_Clase->gra_menu_general(); }
	elseif($_SESSION['user_rol']==5 or $_SESSION['user_rol']==6){
			$V_Clase->gra_menu_testigo();	
		}
?>


    <section class="main row">
<?PHP
	if($_GET['mod'] ==54 and $_GET['opcion']==1){?>        
 		<article id="rep-usuarios" class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
              <div class="panel-body">
				<div class="table-responsive">
                  <table class="table table-condensed table-hover">
                  <tr>
                    <th>Departamento / Municipio</th>
                    <th>Rol</th> 
                    <th>Cedula</th>
                    <th>Nombre</th>
                    <th>Contacto</th>
                    <th>Opción</th>                                        
                  </tr>
				<?php $dato=$V_Clase->pag_seg_usuarios(0); 
                for ($i=0;$i<sizeof($dato);$i++){  #$V_Clase->e_clave($dato[$i]['usua_cedula']);    ?>                  
                  <tr>
                   	<td><?PHP echo $V_Clase->trae_departamento($dato[$i]['usua_departamento']);?> 
                      / <?PHP if ($dato[$i]['usua_municipio']==999){echo 'TODOS';}
	  			else{echo $V_Clase->trae_municipio($dato[$i]['usua_municipio'],$dato[$i]['usua_departamento']); }?>
				
					</td>
                   	<td><?PHP echo $dato[$i]['rol_nombre'];?></td>
                   	<td><a onClick="window.location='CentroControl.php?mod=54&opcion=4&token=<?PHP echo $dato[$i]['usua_cedula'];?>'" href="javascript:void(0);"><?PHP echo $dato[$i]['usua_cedula'];?></a></td>
                   	<td><?PHP echo $dato[$i]['usua_nombre_completo'];?></td>
                   	<td><?PHP echo $dato[$i]['usua_correo'];?> / <?PHP echo $dato[$i]['usua_telefono'];?></td>
                   	<td>
                    <a href="CentroControl.php?mod=54&opcion=3&token=<?PHP echo $dato[$i]['usua_cedula'];?>"><span class="glyphicon glyphicon-pencil"></span></a>
                    </td>                    
                  </tr>   
                 <?PHP } 
				 
                if(sizeof($dato) ==0){
                 ?>    
                <tr class="TablaFila">
                    <td align=center colspan="6">No hay Datos.</td>
                </tr>
                <?php } ?>                                                  
                  </table>
                </div>

              </div>
            </div>
        </article>        
        <?PHP }## Final de Centros de Control ?>   
    
       
      
<?PHP if(($_GET['mod']== 54 and $_GET['opcion']==2) or ($_GET['mod']==54 and $_GET['opcion']==3) ){##Registrar Usuarios

		if($_GET['opcion']==3){ $dato_e=$V_Clase->v_usuarios($_GET['token']); }
?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
              <div class="panel-body">
				
                <form class="form-horizontal" name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                <label class="control-label col-md-4" for="dep">Departamento</label>
                  <div class="col-md-8">
                   <?PHP if($conf[0]['con_departamento']!=""){ $cargar=$conf[0]['con_departamento']; }else{ $cargar="";	} 
				   $V_Clase->comboDepartamento($cargar); ?>
                  </div>
                </div>  
                 
                <div class="form-group">
                <label class="control-label col-md-4" for="mub">Elige un Municipio:</label>
                  <div class="col-md-8">
                  <div id="div_municipio_edes" >
                    	<?PHP 
						if($conf[0]['con_municipio']!=""){ $cargar=$conf[0]['con_departamento']; 	}else{
							?>
                            <select class="form-control" id="mun" name="mun">
                                <option value="0">Seleccione el Municipio</option>
                            </select>							
						<?PHP
							}
							$V_Clase->comboMunicipio($cargar,$conf[0]['con_municipio']);
						?>
                    </div>
                  </div>
                </div>                  
                 
                <div class="form-group">
                <label class="control-label col-md-4" for="ced">Cedula:</label>
                  <div class="col-md-8">
                  <?PHP if($_GET['opcion']==3){ $cargar=$dato_e[0]['usua_cedula']; }else{$cargar="";} ?>
                   <input type="number" class="form-control input-sm" id="ced" name="ced" required min="100000" placeholder="Cedula" value="<?PHP echo $cargar;?>"  <?PHP if(isset($_GET['opcion']) and $_GET['opcion']==3){ echo 'readonly'; }?> onBlur="refre_capa(document.form.ced.value, 'div_cedula', 'mod_com_ajax.php', '3')" >
                   <div id="div_cedula"></div>
                  </div>
                </div>                  

                <div class="form-group">
                <label class="control-label col-md-4" for="nc">Nombre Completo:</label>
                  <div class="col-md-8">
                <?PHP if($_GET['opcion']==3){ $cargar=$dato_e[0]['usua_nombre_completo']; }else{$cargar="";} ?>
                  <input type="text" class="form-control input-sm" id="nc" name="nc" required placeholder="Nombre Completo" value="<?PHP echo $cargar;?>">
                  </div>
                </div> 


                <div class="form-group">
                <label class="control-label col-md-4" for="ema">Correo:</label>
                  <div class="col-md-8">
                  <?PHP if($_GET['opcion']==3){ $cargar=$dato_e[0]['usua_correo']; }else{$cargar="";} ?>
                  <input type="email" class="form-control input-sm" id="em" name="em" required placeholder="Correo Electronico" value="<?PHP echo $cargar;?>">
                  </div>
                </div>        

                <div class="form-group">
                <label class="control-label col-md-4" for="tel">Telefono:</label>
                  <div class="col-md-8">
                  <?PHP if($_GET['opcion']==3){ $cargar=$dato_e[0]['usua_telefono']; }else{$cargar="";} ?>
                  <input type="text" class="form-control input-sm" id="tel" name="tel" placeholder="Telefono Fijo o Movil" value="<?PHP echo $cargar;?>">
                  </div>
                </div> 

                <div class="form-group">
                <label class="control-label col-md-4" for="rol">Rol:</label>
                  <div class="col-md-8">
                 <?PHP if($_GET['opcion']==3){ $cargar=$dato_e[0]['usua_rol']; }else{$cargar=0;} ?>
                   <?PHP $V_Clase->comboRol($cargar); ?> 
                  </div>
                </div> 

                <div class="form-group">
                <label class="control-label col-md-4" for="gp">Grupo Poblacional:</label>
                  <div class="col-md-8">
                 <?PHP if($_GET['opcion']==3){ $cargar=$dato_e[0]['usua_gp']; }else{$cargar=0;} ?>
                   <?PHP  $V_Clase->trae_pregunta_respuesta("A17",$cargar); #$cargar ?> 
                  </div>
                </div>                 

  
 
 				<div class="text-center">                
                  <?PHP 
				  if($_GET['opcion']==3){ ?> 
                  <input type="submit" name="modUsuario" class="btn btn-success btn-lg" value="Modificar Usuario" >  
                  <?PHP }else{		?>
                  <input type="submit" name="regUsuario" class="btn btn-success btn-lg" value="Registrar Usuario" >
                  <div class="alert alert-info" role="alert"><span class="glyphicon glyphicon-fire"></span> Importante: La Clave son los Cuatro (4) ultimos numeros de cedula.</div>
				  <?PHP }?>
                  </div>
                </form>

              </div>
            </div>
        </article>
<?PHP }?>

<?PHP if(($_GET['mod']== 54 and $_GET['opcion']==4) or ($_GET['mod']== 54 and $_GET['opcion']==5)) {##Ver Datos Usuarios

		$dato_e=$V_Clase->v_usuarios($_GET['token']); ?>
		<div class="text-center text-primary h3 bg-primary"><?PHP $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></div>
          <ul class="nav nav-pills nav-justified">
            <li <?PHP if ($_GET['opcion']==4){?> class="active"<?PHP } ?>><a data-toggle="pill" href="#pu">Perfil Usuario</a></li>
            <li <?PHP if ($_GET['opcion']==5){?> class="active"<?PHP } ?>><a data-toggle="pill" href="#cc">Cambiar Clave</a></li>
            <li><a data-toggle="pill" href="#su">Seguimiento Usuario</a></li>
            <li><a data-toggle="pill" href="#nov">Novedades</a></li>
          </ul>
          
        <div class="tab-content">
        	<!--Inicio Perfil del Usuario -->
          <div id="pu" class="tab-pane fade <?PHP if ($_GET['opcion']==4){?> in active<?PHP } ?>">
            
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Registrar Usuarios del Sistema</h3>
              </div>
              <div class="panel-body">
				
                <form class="form-horizontal" name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                <label class="control-label col-md-4" for="dep">Departamento</label>
                <div class="col-md-8"><?PHP echo $V_Clase->trae_departamento($dato_e[0]['usua_departamento']);?></div>
                </div>  
                 
                <div class="form-group">
                <label class="control-label col-md-4" for="mub">Elige un Municipio:</label>
                  <div class="col-md-8">
                  <?PHP echo $V_Clase->trae_municipio($dato_e[0]['usua_municipio'],$dato_e[0]['usua_departamento']); ?>
                  </div>
                </div>                  
                 
                <div class="form-group">
                <label class="control-label col-md-4" for="ced">Cédula:</label>
                  <div class="col-md-8"><?PHP echo $dato_e[0]['usua_cedula']; ?></div>
                </div>                  

                <div class="form-group">
                <label class="control-label col-md-4" for="nc">Nombre Completo:</label>
                  <div class="col-md-8"><?PHP echo $dato_e[0]['usua_nombre_completo'];  ?></div>
                </div> 


                <div class="form-group">
                <label class="control-label col-md-4" for="ema">Correo:</label>
                  <div class="col-md-8"><?PHP echo $dato_e[0]['usua_correo'];  ?></div>
                </div>        

                <div class="form-group">
                <label class="control-label col-md-4" for="tel">Telefono:</label>
                  <div class="col-md-8"><?PHP echo $dato_e[0]['usua_telefono'];?></div>
                </div> 

                <div class="form-group">
                <label class="control-label col-md-4" for="rol">Rol:</label>
                  <div class="col-md-8"><?PHP echo $V_Clase->trae_rol($dato_e[0]['usua_rol']); ?> </div>
                </div> 

                <div class="form-group">
                <label class="control-label col-md-4" for="gp">Grupo Poblacional:</label>
                  <div class="col-md-8">
                  <?PHP echo $V_Clase->trae_respuesta("A17",$dato_e[0]['usua_gp']); ?> 
                  </div>
                </div>                 

  
 
 				<div class="text-center">                
                  <input type="button" name="modUsuario" class="btn btn-success btn-lg" value="Modificar Usuario" onClick="window.location='CentroControl.php?mod=54&opcion=3&token=<?PHP echo $dato_e[0]['usua_cedula'];?>'">  
                  </div>
                </form>

              </div>
            </div>
            
            
            

            </div>
           
           	<!--Inicio Cambio de Claves -->
            <div id="cc" class="tab-pane fade <?PHP if ($_GET['opcion']==5){?> in active<?PHP } ?>">

            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Cambiar Clave Usuario</h3>
              </div>
              <div class="panel-body">
				
                <form class="form-horizontal" name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                <label class="control-label col-md-4" for="act">Clave Anterior:</label>
                  <div class="col-md-8">
                  <input type="password" class="form-control input-sm" id="act" name="act" required placeholder="Ingrese Clave Actual" value="">
                  </div>
                </div> 
                
                <div class="form-group">
                <label class="control-label col-md-4" for="ncla">Clave Nueva:</label>
                  <div class="col-md-8">
                  <input type="password" class="form-control input-sm" id="ncla" name="ncla" required placeholder="Ingrese la Clave Nueva" value="">
                  </div>
                </div> 
                
                <div class="form-group">
                <label class="control-label col-md-4" for="ccla">Confirmar Clave:</label>
                  <div class="col-md-8">
                  <input type="password" class="form-control input-sm" id="ccla" name="ccla" required placeholder="Ingrese la confirmación de Clave" value="">
                  </div>
                </div>                 
                <div class="row text-center">
                   <input type="submit" name="CambiarClave" class="btn btn-success btn-lg" value="Cambiar Clave" >
                  <input type="hidden" name="token" value="<?PHP echo $dato_e[0]['usua_cedula'];?>">
                </div>  
                </form>

              </div>
            </div>
			
            
              
            </div>

	<!--Inicio Seguimiento Usuario -->
	<div id="su" class="tab-pane fade">
              
			<div class="panel panel-primary">

				<div class="table-responsive">
				<table class="table table-condensed table-hover table-striped">
				<thead>
                	<tr>
						<th>Departamento / Municipio</th>
                    	<th>Rol</th>
                        <th>Cedula</th>
						<th>Nombres</th>
						<th>En Edición</th>
						<th>Terminados</th>
					</tr>
                </thead>    
				    <?php
				    $dato =$V_Clase->pag_seg_usuarios($_GET['token']);
					for($i=0;$i<sizeof($dato);$i++)
					{?>					
					<tr>
                        <td><?PHP echo $V_Clase->trae_departamento($dato[$i]['usua_departamento']);?> 
                          / <?PHP if ($dato[$i]['usua_municipio']==999){echo 'TODOS';}
                    else{echo $V_Clase->trae_municipio($dato[$i]['usua_municipio'],$dato[$i]['usua_departamento']); }?>
                    
                        </td>
                   		<td><?PHP echo $dato[$i]['rol_nombre'];?></td>
						<td><a href="javascript:void(0);" onClick="window.location='CentroControl.php?mod=54&opcion=4&token=<?PHP echo $dato[$i]["usua_cedula"];?>'"><?PHP echo $dato[$i]["usua_cedula"];?></a></td>
						<td><?PHP echo $dato[$i]["usua_nombre_completo"];?></td>
						<td><?PHP echo $V_Clase->Contar(5,$dato[$i]["usua_cedula"]);?></td>
						<td><?PHP echo $V_Clase->Contar(6,$dato[$i]["usua_cedula"]);?></td>
					</tr>	
					<?PHP }## Final For ?>				
				</table>


            </div>
            </div>
	</div>

	<!--Inicio Novedades -->
	<div id="nov" class="tab-pane fade">
              
			<div class="panel panel-primary">
                <div class="row bg-primary">
                   <div class="col-xs-2">Id Nov</div>	   
                   <div class="col-xs-4">Operación</div>	   
                   <div class="col-xs-4">Usuario</div>	   
                   <div class="col-xs-2">Fecha Evento</div>	   	   
                </div>
            <?PHP 
            $vNov=$V_Clase->pag_novedades_usuario($_GET['token']);
            if(sizeof($vNov) != 0 ){
            for ($i=0;$i<sizeof($vNov);$i++)
            {?>
                <div class="row">
                   <div class="col-xs-2"><?PHP echo $vNov[$i]['seg_id'];?></div>	   
                   <div class="col-xs-4"><?PHP echo $vNov[$i]['seg_operacion'];?></div>	   
                   <div class="col-xs-4"><?PHP echo $vNov[$i]['seg_usuario'];?></div>	   
                   <div class="col-xs-2"><?PHP echo $vNov[$i]['seg_fh_evento'];?></div>	    
                </div>
            
            <?PHP }
            
            }else{ ?>
                <div class="row">
                    <div class="h4 text-center">No hay registros.</div>
                </div>
            <?PHP } ?>

            </div>
            </div>
	<!--Final Novedades -->


          </div>
		
		


<?PHP }?>
<?PHP
	if($_GET['mod'] ==54 and $_GET['opcion']==6){?>        
 		<article id="rep-usuarios" class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
              <div class="panel-body">
				<div class="table-responsive">
				<table class="table table-condensed table-hover table-striped">
				<thead>
                	<tr>
						<th>Departamento / Municipio</th>
                    	<th>Rol</th>
                        <th>Cedula</th>
						<th>Nombres</th>
						<th>En Edición</th>
						<th>Terminados</th>
					</tr>
                </thead>    
				    <?php
				    $dato =$V_Clase->pag_seg_usuarios(0);
					for($i=0;$i<sizeof($dato);$i++)
					{?>					
					<tr>
                        <td><?PHP echo $V_Clase->trae_departamento($dato[$i]['usua_departamento']);?> 
                          / <?PHP if ($dato[$i]['usua_municipio']==999){echo 'TODOS';}
                    else{echo $V_Clase->trae_municipio($dato[$i]['usua_municipio'],$dato[$i]['usua_departamento']); }?>
                    
                        </td>
                   		<td><?PHP echo $dato[$i]['rol_nombre'];?></td>
						<td><a href="javascript:void(0);" onClick="window.location='CentroControl.php?mod=54&opcion=4&token=<?PHP echo $dato[$i]["usua_cedula"];?>'"><?PHP echo $dato[$i]["usua_cedula"];?></a></td>
						<td><?PHP echo $dato[$i]["usua_nombre_completo"];?></td>
						<td><?PHP echo $V_Clase->Contar(5,$dato[$i]["usua_cedula"]);?></td>
						<td><?PHP echo $V_Clase->Contar(6,$dato[$i]["usua_cedula"]);?></td>
					</tr>	
					<?PHP }## Final For ?>				
				</table>


                </div>

              </div>
            </div>
        </article>        
        <?PHP }## Final de Centros de Control ?>   


         <?PHP if($_GET['mod']==54 and $_GET['opcion']==15){##Configuracion General ?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
              <div class="panel-body">
				
                <form name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                   <label for="dep">Departamento</label>
                   <?PHP if($conf[0]['con_departamento']!=""){ $cargar=$conf[0]['con_departamento']; }else{ $cargar="";	} 
				   $V_Clase->comboDepartamento($cargar); ?>
                    
                  </div>
                  <div class="form-group">
                  	<label for="mun">Elige un Municipio:</label>
                    <div id="div_municipio_edes" >
                    	<?PHP 
						if($conf[0]['con_municipio']!=""){ $cargar=$conf[0]['con_departamento']; 	}else{
							?>
                            <select class="form-control" id="mun" name="mun">
                                <option value="0">Seleccione el Municipio</option>
                            </select>							
						<?PHP
							}
							$V_Clase->comboMunicipio($cargar,$conf[0]['con_municipio']);
						?>
                    </div>
                  </div> 
                  <div class="form-group">
                  	<label for="en">Entidad:</label>
                    	<input type="text" id="en" required name="entidad" value="<?PHP echo $conf[0]['con_entidad'];?>" class="form-control input-sm" >
                    
                  </div>                                    
                  <?PHP 
					if(sizeof($conf>0)){ ?> 
                  <button type="submit" class="btn btn-success">Actualizar</button>                    
                  <input type="hidden" name="operacion" value="modConfiguracion">
                  <input type="hidden" name="id" value="<?PHP echo $conf[0]['con_id'];?>">
                  <?PHP  }else{		?>
                  <button type="submit" class="btn btn-primary">Ingresar</button>
                  <input type="hidden" name="operacion" value="regConfiguracion">
				  <?PHP }?>
                </form>

              </div>
            </div>
        </article>
        <?PHP }## Final de Configuracion General ?>   

                  
    </section>
    
</div>

<footer>
	<div class="container text-center">
		<h5>Usuario Logueado: <?PHP echo $_SESSION['user_nombres'];?></h5>
		<h5>Desarrollo de Aplicación 2015</h5>
    </div>    
</footer>



<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="js/funciones.js"></script>
  <script>
  
  $( function() {
    $( document ).tooltip();
  } );
  </script>  
  </script>

<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
