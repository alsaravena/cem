<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
	### Datos para Paginacion 
	if (isset($_GET["pos"]))
	{
		$inicio=$_GET["pos"];
	}else
	{
		$inicio=0;
	}### Datos para Paginacion 		
	?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/estilos.css">
<script type="text/javascript" src="js/loader.js"></script>
<title>Caracterización Étnica Municipal</title>
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP 
	$V_Clase->gra_menu_general();	
?>


    <section class="main row">

        <?PHP if($_GET['mod']==52 and $_GET['opcion']==1){##Inicio?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
              <div class="panel-body">
                      
        <div class="table-responsive">
<table class="table table-condensed table-hover table-striped">
<thead>
  <tr>
    <th>Ficha</th>
    <th>A17</th> 
    <th>A18</th>
    <th>Estado</th> 
    <th>Operaciones</th>
  </tr>
</thead>  
<?PHP 
$dato=$V_Clase->pag_fichas($inicio,$porpagina,base64_decode($_GET['opcion']));
## Inicio For Recorrido
for ($i=0;$i<sizeof($dato);$i++){
?>
  <tr>
    <td><?PHP echo $dato[$i]['A1'];?></td>
    <td><?PHP echo $V_Clase->trae_respuesta('A17',$dato[$i]['A17']);?></td>
    <td><?PHP echo $V_Clase->trae_respuesta('A18',$dato[$i]['A18']);?></td>    
    <td><?PHP if($dato[$i]['ESTADO']==1){echo '<b class="text-danger">En Edición</b>';
		}elseif($dato[$i]['ESTADO']==2) {echo '<b class="text-success">Terminada</b>';}?></td>
    <td><?PHP if($dato[$i]['ESTADO']==1){
		
			if($dato[$i]['B1']==Null){
		?>
			<a class="btn btn-success btn-sm" href="javascript:void(0);" title="Continuar con Carga de Datos B" onClick="window.location='CargarDatos.php?mod=50&opcion=3&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-2'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>    

		<?PHP }elseif($dato[$i]['C1']==Null){?>
			<a class="btn btn-success btn-sm" href="javascript:void(0);" title="Continuar con Carga de Datos C" onClick="window.location='CargarDatos.php?mod=50&opcion=4&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-3'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>			
			
		<?PHP }else{?>
			<a class="btn btn-success btn-sm" href="javascript:void(0);" title="Continuar con Carga de Datos D" onClick="window.location='CargarDatos.php?mod=50&opcion=5&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-4'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>			            
		<?PHP	}
		
		
		}elseif($dato[$i]['ESTADO']==2) {?>
    		<a class="btn btn-info btn-sm" href="javascript:void(0);" title="Visualizar toda la Ficha" onClick="window.location='VerDatos.php?mod=51&opcion=1&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-eye-open"></span> Visualizar</a>    
		<?PHP }?>
        
        <?PHP if($dato[$i]['ESTADO']==2 and $dato[$i]['ARCHIVO'] == 'SIN_ARCHIVO.pdf') {?>
        <a class="btn btn-success btn-sm" href="javascript:void(0);" title="Cargar Archivo Ficha Escaneada" onClick="window.location='CargarDatos.php?mod=51&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-paperclip"></span> Cargar Ficha</a>
        <?PHP } ?>
        <?PHP if($dato[$i]['ARCHIVO'] != 'SIN_ARCHIVO.pdf') {?>
        <a class="btn btn-primary btn-sm" target="_blank" onclick="window.location='./files/<?PHP echo $dato[$i]['ARCHIVO']; ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Descargar Ficha</a>
    	<?PHP } ?>
        <a class="btn btn-success btn-sm" href="javascript:void(0);" title="Ver Novedades" onClick="window.location='VerDatos.php?mod=51&opcion=7&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-list"></span> Novedades</a>
              
        <?PHP if($dato[$i]['ESTADO']==2){?>		
        <div class="btn-group">
          <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="glyphicon glyphicon-edit"></span> Modificar <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li><a href="CargarDatos.php?mod=50&opcion=7&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>#tabs-1">Modificar A. Ficha</a></li>
            <li><a href="CargarDatos.php?mod=50&opcion=8&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>#tabs-2">Modificar B. Vivienda</a></li>
            <li><a href="CargarDatos.php?mod=50&opcion=9&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>#tabs-3">Modificar C. Familia</a></li>
            <li role="separator" class="divider"></li>
    		<li><a href="VerDatos.php?mod=51&opcion=1&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#i">Ver Integrantes</a></li>
    		<li><a href="CargarDatos.php?mod=50&opcion=5&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>#tabs-4">Agregar Integrante</a></li>            
          </ul>
        </div>
        <?PHP }?>                
</td>  
  </tr>
<?PHP }## Final For Recorrido
if(sizeof($dato) ==0){
 ?>    
<tr>
	<td colspan="5">No hay Datos.</td>
</tr>
<?PHP } ?>
</table>
		</div>
        </div>
    	</div>
        </article>
 
<div class="text-center h4">Resultados Encontrados: <?PHP echo sizeof($dato);?><br /> <hr>
<?PHP
#### Inician los Datos de Paginacion
if ($inicio==0){
		echo '<span class="glyphicon glyphicon-arrow-left"></span> Anteriores';
	}else{
		$anterior=$inicio-$porpagina;
		echo '<a href="?mod='.$_GET['mod'].'&opcion='.$_GET['opcion'].'&pos='.$anterior.'" title="Anteriores">
				<span class="glyphicon glyphicon-arrow-left"></span>
		Anteriores </a>';
	}
		
	echo '&nbsp;&nbsp;||&nbsp;&nbsp;';

	if (count($dato)==$porpagina){
		$proximo=$inicio+$porpagina;
		echo '<a href="?mod='.$_GET['mod'].'&opcion='.$_GET['opcion'].'&pos='.$proximo.'" title="Siguientes">
			Siguientes
			<span class="glyphicon glyphicon-arrow-right"></span>
		</a>';
	}else{
		echo 'Siguientes <span class="glyphicon glyphicon-arrow-right"></span>';
	}
?>
</div> 	                
        

        <?PHP }elseif($_GET['mod']==52 and $_GET['opcion']==2){##Reporte Integrantes?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
              <div class="panel-body">
                      
        <div class="table-responsive">
<table class="table table-condensed table-hover table-striped">
<thead>
  <tr>
    <th>Ficha</th>
    <th>D8</th>
    <th>D7</th>
    <th>A17</th> 
    <th>Estado</th> 
    <th>Operaciones</th>
  </tr>
</thead>  
<?PHP 
$dato=$V_Clase->pag_integrantes($inicio,$porpagina,base64_decode($_GET['opcion']));
## Inicio For Recorrido
for ($i=0;$i<sizeof($dato);$i++){
?>
  <tr>
    <td><?PHP echo $dato[$i]['A1'];?></td>
    <td><?PHP echo $dato[$i]['D8'].' - '.$V_Clase->trae_respuesta('D8',$dato[$i]['D8']);?></td>
    <td><?PHP echo $dato[$i]['D7'];?></td>        
    <td><?PHP echo $dato[$i]['D1'].' '.$dato[$i]['D2'].' '.$dato[$i]['D3'].' '.$dato[$i]['D4'];?></td>
    <td><?PHP if($dato[$i]['VIVO']==1){echo '<b class="text-danger">Vivo</b>';
		}elseif($dato[$i]['VIVO']==2) {echo '<b class="text-success">Fallecido</b>';}?></td>
    <td>
    		<a class="btn btn-info btn-sm" onClick="window.location='VerDatos.php?mod=51&opcion=2&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-eye-open"></span> Visualizar Ficha</a>    

        <?PHP if($dato[$i]['ARCHIVO_DI'] == 'SIN_ARCHIVO_DI.pdf') {?>
        <a class="btn btn-success btn-sm" href="javascript:void(0);" title="Cargar Documento de Identidad" onClick="window.location='CargarDatos.php?mod=51&opcion=16&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-paperclip"></span> Cargar DI</a>
        <?PHP } ?>
        <?PHP if($dato[$i]['ARCHIVO_DI'] != 'SIN_ARCHIVO_DI.pdf') {?>
        <a class="btn btn-primary btn-sm" title="Descargar Documento de Identidad" target="_blank" onclick="window.location='./files/<?PHP echo $dato[$i]['ARCHIVO_DI']; ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Descargar DI</a>
    	<?PHP } ?>
        
		<?PHP #if($dato[$i]['ARCHIVO_DI'] != 'SIN_ARCHIVO_DI.pdf') {?>
<!--        <a class="btn btn-primary btn-sm" title="Descargar Certificado" target="_blank" onclick="window.location='Generar_PDF.php?mod=53&opcion=8&token=<?PHP #echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP #echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Certificado</a>
-->
    	<?PHP #} ?>


<!-- Inicio Generar Certificado-->
<div class="btn-group">
          <button class="btn btn-warning btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="glyphicon glyphicon-certificate"></span> Certificados <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=8&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Registro</a></li>
            
            <?PHP if($dato[$i]['D9']==1){?>
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=10&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Libreta Militar</a></li>
            <?PHP } ?>
            
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=11&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Afiliación Salud</a></li>

            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=12&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Duplicado Documento</a></li> 
            
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=13&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Laboral</a></li>         
            
            <li><a href="javascript:void(0);" title="Certificado de Servicios Salud" onclick="window.location='Generar_PDF.php?mod=53&opcion=14&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Servicios Salud</a></li>
            
            <li><a href="javascript:void(0);" title="Certificado de Matrimonio ó Unión Civil" onclick="window.location='Generar_PDF.php?mod=53&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Unión</a></li>   

          </ul>
        </div>
<!-- Final Generar Certificado-->

        <div class="btn-group">
          <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="glyphicon glyphicon-edit"></span> Opciones <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li><a href="CargarDatos.php?mod=50&opcion=10&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>#tabs-4" title="Modificar Datos D. Integrante">Modificar</a></li>
            <li><a href="CargarDatos.php?mod=50&opcion=14&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Mover Integrante de la Ficha">Mover de Ficha</a></li>
            <?PHP if($dato[$i]['VIVO']!=2){?>
            <li><a href="CargarDatos.php?mod=50&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Cambiar Estado Vivo a Fallecido">Mover a Fallecido</a></li>
            <?PHP } ?>
            <?PHP if($dato[$i]['VIVO']!=1){?>
             <li><a href="CargarDatos.php?mod=50&opcion=16&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Cambiar Estado Fallecido a Vivo">Mover a Vivo</a></li>
             <?PHP } ?>
          </ul>
        </div>

    	
</td>  
  </tr>
<?PHP }## Final For Recorrido
if(sizeof($dato) ==0){
 ?>    
<tr>
	<td colspan="4">No hay Datos.</td>
</tr>
<?PHP } ?>
</table>

            </div>	
			</div>
    	</div>
        
        </article>        
<div class="text-center h4">Resultados Encontrados: <?PHP echo sizeof($dato);?><br /> <hr>
<?PHP
#### Inician los Datos de Paginacion
if ($inicio==0){
		echo '<span class="glyphicon glyphicon-arrow-left"></span> Anteriores';
	}else{
		$anterior=$inicio-$porpagina;
		echo '<a href="?mod='.$_GET['mod'].'&opcion='.$_GET['opcion'].'&pos='.$anterior.'" title="Anteriores">
				<span class="glyphicon glyphicon-arrow-left"></span>
		Anteriores </a>';
	}
		
	echo '&nbsp;&nbsp;||&nbsp;&nbsp;';

	if (count($dato)==$porpagina){
		$proximo=$inicio+$porpagina;
		echo '<a href="?mod='.$_GET['mod'].'&opcion='.$_GET['opcion'].'&pos='.$proximo.'" title="Siguientes">
			Siguientes
			<span class="glyphicon glyphicon-arrow-right"></span>
		</a>';
	}else{
		echo 'Siguientes <span class="glyphicon glyphicon-arrow-right"></span>';
	}
?>
</div>  
  
      <?PHP }elseif($_GET['mod']==52 and $_GET['opcion']==3){##Indicador Edades	  ?>
	  <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <div class="row">
            <div class="panel panel-primary">
                 <div class="panel-heading">
                  <h3 class="panel-title">Personal > Grupo Etareos</h3>
                 </div>
            <div class="panel-body">
            
            <?PHP 
			$hombre=$V_Clase->calcular_edad_hombre();
			
			$h1=0; $h2=0; $h3=0; $h4=0; $h5=0;
			for($i=0;$i<sizeof($hombre); $i++){
			#echo 'EDAD= '.$hombre[$i]['EDAD_ACTUAL'].' cuantos= '.$hombre[$i]['TOTAL'].'<br />';

				if($hombre[$i]['EDAD_ACTUAL']>0 and $hombre[$i]['EDAD_ACTUAL'] <=5){
					$h1=$h1+$hombre[$i]['TOTAL'];
				}elseif($hombre[$i]['EDAD_ACTUAL']>=6 and $hombre[$i]['EDAD_ACTUAL'] <=15){
					$h2=$h2+$hombre[$i]['TOTAL'];
				}elseif($hombre[$i]['EDAD_ACTUAL']>=16 and $hombre[$i]['EDAD_ACTUAL'] <=30){
					$h3=$h3+$hombre[$i]['TOTAL'];
				}elseif($hombre[$i]['EDAD_ACTUAL']>=31 and $hombre[$i]['EDAD_ACTUAL'] <=60){
					$h4=$h4+$hombre[$i]['TOTAL'];
				}elseif($hombre[$i]['EDAD_ACTUAL']>=60){
					$h5=$h5+$hombre[$i]['TOTAL'];												
				}	
			}
			
			
			$mujer=$V_Clase->calcular_edad_mujer();			
			$m1=0; $m2=0; $m3=0; $m4=0; $m5=0;
			for($m=0;$m<sizeof($mujer); $m++){
			#echo 'EDAD= '.$mujer[$m]['EDAD_ACTUAL'].' cuantos= '.$mujer[$m]['TOTAL'].'<br />';

				if($mujer[$m]['EDAD_ACTUAL']>0 and $mujer[$m]['EDAD_ACTUAL'] <=5){
					$m1=$m1+$mujer[$m]['TOTAL'];
				}elseif($mujer[$m]['EDAD_ACTUAL']>=6 and $mujer[$m]['EDAD_ACTUAL'] <=15){
					$m2=$m2+$mujer[$m]['TOTAL'];
				}elseif($mujer[$m]['EDAD_ACTUAL']>=16 and $mujer[$m]['EDAD_ACTUAL'] <=30){
					$m3=$m3+$mujer[$m]['TOTAL'];
				}elseif($mujer[$m]['EDAD_ACTUAL']>=31 and $mujer[$m]['EDAD_ACTUAL'] <=60){
					$m4=$m4+$mujer[$m]['TOTAL'];
				}elseif($mujer[$m]['EDAD_ACTUAL']>=60){
					$m5=$m5+$mujer[$m]['TOTAL'];												
				}	
			}
			?>
      <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([
          ['Edades', 'Hombre', 'Mujer'],
          ['0-5', <?PHP echo $h1;?>, <?PHP echo $m1;?>],
          ['6-15', <?PHP echo $h2;?>, <?PHP echo $m2;?>],
          ['16-30', <?PHP echo $h3;?>, <?PHP echo $m3;?>],
          ['31-60', <?PHP echo $h4;?>, <?PHP echo $m4;?>],
          ['>60', <?PHP echo $h5;?>, <?PHP echo $m5;?>]
        ]);

        var options = {
          width: '100%',
          chart: {
            title: 'Grupos Etareós Poblacion Caracterizada',
            subtitle: 'Información por edades.'
          },
          series: {
            0: { axis: 'Hombre' }, // Bind series 0 to an axis named 'distance'.
            1: { axis: 'Mujer' } // Bind series 1 to an axis named 'brightness'.
          },
          axes: {
            y: {
              distance: {label: 'parsecs'}, // Left y-axis.
              brightness: {side: 'right', label: 'apparent magnitude'} // Right y-axis.
            }
          }
        };

      var chart = new google.charts.Bar(document.getElementById('piechart_edad'));
      chart.draw(data, options);
    };
    </script>    
            <div id="piechart_edad" style="width:auto; height:400px;"></div>
                                       
              </div>
             <table class="table table-condensed table-responsive text-center">
             <tr>
             	<td>Edad</td>
                <td>Hombre</td>
                <td>Mujer</td>
             </tr>
             <tr>
             	<td>0-5</td>
                <td><?PHP echo $h1; ?></td>
                <td><?PHP echo $m1; ?></td>
             </tr>
             <tr>
             	<td>6-15</td>
                <td><?PHP echo $h2; ?></td>
                <td><?PHP echo $m2; ?></td>
             </tr>   
             <tr>
             	<td>16-30</td>
                <td><?PHP echo $h3; ?></td>
                <td><?PHP echo $m3; ?></td>
             </tr>
             <tr>
             	<td>31-60</td>
                <td><?PHP echo $h4; ?></td>
                <td><?PHP echo $m4; ?></td>
             </tr>
             <tr>
             	<td>>60</td>
                <td><?PHP echo $h5; ?></td>
                <td><?PHP echo $m5; ?></td>
             </tr>
             <tr>
             	<td>Total</td>
                <td><?PHP echo $h1+$h2+$h3+$h4+$h5; ?></td>
                <td><?PHP echo $m1+$m2+$m3+$m4+$m5; ?></td>
             </tr>                                                                 
             </table> 
            </div>            
      </div>
      </article>  
        
        <?PHP }elseif($_GET['mod']==52 and $_GET['opcion']==10){##Estadisticas
		?>
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="text-center text-primary h3 bg-primary"><?PHP $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']); if(isset($_GET['token'])){ $_SESSION["user_grupo"]=$_GET['token']; $_SESSION["user_temporal"]=1; 
			if($_GET['c']==17){$_SESSION['c']='A17'; 
			}elseif($_GET['c']==18){$_SESSION['c']='A18';
			}elseif($_GET['c']==19){$_SESSION['c']='GRUPO';
			}
		} ?></div>
<div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-user"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(1,99);?></div>
                                        <div>Familias Caracterizadas</div>
                                    </div>
                                </div>
                            </div>
                            <a href="establecimiento.php?mod=31&opcion=16">
                                <div class="panel-footer">
                                    <span class="pull-left">Ver Detalles</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-list"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(2,99);?></div>
                                        <div>Personas Caracterizadas</div>
                                    </div>
                                </div>
                            </div>
                            <a href="establecimiento.php?mod=31&opcion=15">
                                <div class="panel-footer">
                                    <span class="pull-left">Ver Detalles</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-alert"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(3,99);?></div>
                                        <div>Fichas en Edición</div>
                                    </div>
                                </div>
                            </div>
                            <a href="Reportes.php?mod=52&opcion=1">
                                <div class="panel-footer">
                                    <span class="pull-left">Ver Fichas en Edición</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-tag"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(4,99);?></div>
                                        <div>Fichas Terminadas</div>
                                    </div>
                                </div>
                            </div>
                            <a href="Reportes.php?mod=52&opcion=1">
                                <div class="panel-footer">
                                    <span class="pull-left">Ver Fichas Terminadas</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>        
        

<?PHP $V_Clase->grafica_variable('A2',1);?>
<?PHP $V_Clase->grafica_variable('A3',1);?>
<?PHP $V_Clase->grafica_variable('A4',1);?>
<?PHP $V_Clase->grafica_variable('A8',1);?>
<?PHP $V_Clase->grafica_variable('A9',1);?>
<?PHP $V_Clase->grafica_variable('A10',1);?>
<?PHP $V_Clase->grafica_variable('A11',1);?>
<?PHP $V_Clase->grafica_variable('A12',1);?>
<?PHP $V_Clase->grafica_variable('A13',1);?>
<?PHP $V_Clase->grafica_variable('A14',1);?>
<?PHP $V_Clase->grafica_variable('A15',1);?>
<?PHP $V_Clase->grafica_variable('A16',1);?>
<?PHP $V_Clase->grafica_variable('A17',1);?>
<?PHP $V_Clase->grafica_variable('A18',2);?>


<hr>
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Ubicación de las Familias</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['A4 Zona', 'Respuesta'],
                  ['1. Cabecera', <?PHP echo $V_Clase->Contar(7,1);?>],
                  ['2. Centro Poblado', <?PHP echo $V_Clase->Contar(7,2);?>],
				  ['3. Rural Disperso', <?PHP echo $V_Clase->Contar(7,3);?>]
                ]);
        
                var options = {
                  title: 'A4 Zona',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A4'));
                chart.draw(data, options);
              }
            </script>
        
            <div id="piechart_A4" style="width:auto; height:400px;"></div>
                                       
              </div>
            </div>            
      </div>
        
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Participacion en Juntas de Acción Comunal</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Hace parte de la Junta de Acción Comunal?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(9,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(9,2);?>]		  
                ]);
        
                var options = {
                  title: 'A9 ¿Hace parte de la Junta de Acción Comunal?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A9'));
                chart.draw(data, options);	
              }
            </script>
                <div id="piechart_A9" style="width:auto; height:auto;"></div>                                       
                </div>
      		</div>
      </div>     
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Participación en Proyectos Comunitarios</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Participa en algún proyecto comunitario?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(10,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(10,2);?>]		  
                ]);
        
                var options = {
                  title: 'A10 ¿Participa en algún proyecto comunitario?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A10'));
                chart.draw(data, options);	
              }
            </script>
                <div id="piechart_A10" style="width:auto; height:auto;"></div>                                       
                </div>
      		</div>
      </div>              

      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Conoce las Problemáticas de la comunidad</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Conoce las problemática y/o necesidades de su comunidad?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(11,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(11,2);?>]		  
                ]);
        
                var options = {
                  title: 'A11 ¿Conoce las problemática y/o necesidades de su comunidad?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A11'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_A11" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>
      </div>        
	

      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Conoce la Oficinas de Asuntos de la Ciudad</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Conoce la oficina de asuntos étnicos de su municipio?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(12,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(12,2);?>]		  
                ]);
        
                var options = {
                  title: 'A12 ¿Conoce la oficina de asuntos étnicos de su municipio?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A12'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_A12" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Conoce problemas de su Población</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Conoce los Programas para la población Afrocolombiana / Indígena de su municipio?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(13,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(13,2);?>]		  
                ]);
        
                var options = {
                  title: 'A13 ¿Conoce los Programas para la población Afrocolombiana / Indígena de su municipio?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A13'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_A13" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Pertenecen a la Asociación de la Ciudad</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Pertenece a ASONESA?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(14,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(14,2);?>]		  
                ]);
        
                var options = {
                  title: 'A14 ¿Pertenece a ASONESA?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A14'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_A14" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>      

      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Pertenecen a la Asociación de Cabildos</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['A15 ¿Pertenece a ASCATIDAR?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(15,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(15,2);?>]		  
                ]);
        
                var options = {
                  title: 'A15 ¿Pertenece a ASCATIDAR?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A15'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_A15" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
         
<div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Cual</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['A17 ¿Cual?', 'Respuesta'],
                  ['1. Resguardo Indigena Valles de Sol', <?PHP echo $V_Clase->Contar(17,1);?>],
                  ['2. Resguardo Indigena Playas Bojaba', <?PHP echo $V_Clase->Contar(17,2);?>],
                  ['3. Asentamiento Ancestral Calafitas', <?PHP echo $V_Clase->Contar(17,3);?>],
                  ['4. Kichwa', <?PHP echo $V_Clase->Contar(17,4);?>],
                  ['5. Consejo Comunitario Palma', <?PHP echo $V_Clase->Contar(17,5);?>],
                  ['6. Consejo Comunitario Cocosar', <?PHP echo $V_Clase->Contar(17,6);?>],				   
                ]);
        
                var options = {
                  title: 'A17 ¿Cual?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A17'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_A17" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Comunidades</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['A15 ¿Pertenece a ASCATIDAR?', 'Respuesta'],
                  ['1. Comunidad Uncaria', <?PHP echo $V_Clase->Contar(18,1);?>],
                  ['2. Comunidad Chivaraquia', <?PHP echo $V_Clase->Contar(15,2);?>],
				  ['3. Comunidad San Miguel', <?PHP echo $V_Clase->Contar(18,3);?>],
				  ['4. Comunidad Playas de Bojaba', <?PHP echo $V_Clase->Contar(18,4);?>],
				  ['5. Comunidad Uncacia', <?PHP echo $V_Clase->Contar(18,5);?>],
				  ['6. Comunidad Calafitas I', <?PHP echo $V_Clase->Contar(18,6);?>],
				  ['7. Comunidad Calafitas II', <?PHP echo $V_Clase->Contar(18,1);?>]		  
                ]);
        
                var options = {
                  title: 'A18 ¿Comunidad?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_A18'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_A18" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>              
        </article>
        
        
        <?PHP }elseif($_GET['mod']==52 and $_GET['opcion']==11){##Estadisticas B?>
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="text-center text-primary h3 bg-primary"><?PHP $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></div>
	<div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-user"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(24,1);?></div>
                                        <div>Familias Con Vivienda Propia</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-list"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(32,1);?></div>
                                        <div>Familias con Energía Eléctrica</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-alert"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(33,1);?></div>
                                        <div>Familias con Alcantarillado</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-tag"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(35,1);?></div>
                                        <div>Familias con Agua Potable</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
      </div>        

<?PHP $V_Clase->grafica_variable('B1',1);?>
<?PHP $V_Clase->grafica_variable('B2',1);?>
<?PHP $V_Clase->grafica_variable('B3',1);?>
<?PHP $V_Clase->grafica_variable('B4',1);?>
<?PHP $V_Clase->grafica_variable('B5',1);?>
<?PHP $V_Clase->grafica_variable('B6',1);?>
<?PHP $V_Clase->grafica_variable('B7',1);?>
<?PHP $V_Clase->grafica_variable('B8',1);?>
<?PHP $V_Clase->grafica_variable('B9',1);?>
<?PHP $V_Clase->grafica_variable('B10',1);?>
<?PHP $V_Clase->grafica_variable('B11',1);?>
<?PHP $V_Clase->grafica_variable('B12',1);?>
<?PHP $V_Clase->grafica_variable('B13',1);?>
<?PHP $V_Clase->grafica_variable('B14',2);?>
<?PHP $V_Clase->grafica_variable('B15',1);?>
<?PHP $V_Clase->grafica_variable('B16',1);?>
<?PHP $V_Clase->grafica_variable('B17',1);?>
<?PHP $V_Clase->grafica_variable('B18',1);?>
<?PHP $V_Clase->grafica_variable('B19',1);?>
<?PHP $V_Clase->grafica_variable('B20',1);?>
<?PHP $V_Clase->grafica_variable('B21',1);?>
<?PHP $V_Clase->grafica_variable('B22',1);?>
<?PHP $V_Clase->grafica_variable('B23',1);?>
<?PHP $V_Clase->grafica_variable('B24',1);?>
<?PHP $V_Clase->grafica_variable('B25',1);?>
<?PHP $V_Clase->grafica_variable('B26',1);?>

        
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Propiedad y Estado > Tipo de Vivienda</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['B1 Tipo', 'Respuesta'],
                  ['1. Propia', <?PHP echo $V_Clase->Contar(24,1);?>],
                  ['2. Inquilinato', <?PHP echo $V_Clase->Contar(24,2);?>],
				  ['3. Familiar', <?PHP echo $V_Clase->Contar(24,3);?>],
				  ['4. Usufructo', <?PHP echo $V_Clase->Contar(24,4);?>],
                  ['5. Arrendado', <?PHP echo $V_Clase->Contar(24,5);?>],
				  ['6. Albergue', <?PHP echo $V_Clase->Contar(24,6);?>],
				  ['7. Invasión', <?PHP echo $V_Clase->Contar(24,7);?>],
                  ['8 En situación de calle  ', <?PHP echo $V_Clase->Contar(24,8);?>],
				  ['9 No Tiene', <?PHP echo $V_Clase->Contar(24,9);?>]
                ]);
        
                var options = {
                  title: 'B1 Tipo',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B1'));
                chart.draw(data, options);
              }
            </script>
        
            <div id="piechart_B1" style="width:auto; height:400px;"></div>
                                       
              </div>
            </div>            
      </div>
        
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Propiedad y Estado > Cuantas Habitaciones tienen las viviendas</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['B2 ¿Cuántas habitaciones?', 'Respuesta'],
                  ['1. Una', <?PHP echo $V_Clase->Contar(25,1);?>],
                  ['2. Dos', <?PHP echo $V_Clase->Contar(25,2);?>],
				  ['3. Tres', <?PHP echo $V_Clase->Contar(25,3);?>],
                  ['4. Cuatro', <?PHP echo $V_Clase->Contar(25,4);?>],
                  ['5. Cinco o más', <?PHP echo $V_Clase->Contar(25,5);?>]				  
                ]);
        
                var options = {
                  title: 'B2 ¿Cuántas habitaciones?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B2'));
                chart.draw(data, options);	
              }
            </script>
                <div id="piechart_B2" style="width:auto; height:auto;"></div>                                       
                </div>
      		</div>
      </div>     
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Propiedad y Estado > Riesgos de las viviendas</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Esta su vivienda expuesta a riesgos naturales?', 'Respuesta'],
                  ['1. Inundaciones', <?PHP echo $V_Clase->Contar(30,1);?>],
                  ['2. Deslizamientos', <?PHP echo $V_Clase->Contar(30,2);?>],
                  ['3. Basuras', <?PHP echo $V_Clase->Contar(30,3);?>],
                  ['4. Ninguno', <?PHP echo $V_Clase->Contar(30,4);?>]				  		  
                ]);
        
                var options = {
                  title: 'B7 ¿Esta su vivienda expuesta a riesgos naturales?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B7'));
                chart.draw(data, options);	
              }
            </script>
                <div id="piechart_B7" style="width:auto; height:auto;"></div>                                       
                </div>
      		</div>
      </div>              

      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Servicios Públicos > Acceso a Energía Electrica</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Cuenta con acceso a Energia Electrica?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(32,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(32,2);?>]		  
                ]);
        
                var options = {
                  title: 'B9 ¿Cuenta con acceso a Energia Electrica?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B9'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_B9" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>
      </div>        
	

      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Servicios Públicos > Alcantarillado</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Cuenta con acceso a Alcantarillado?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(33,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(33,2);?>]		  
                ]);
        
                var options = {
                  title: 'B10 ¿Cuenta con acceso a Alcantarillado?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B10'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_B10" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>

	<div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Servicios Públicos > Pozo Séptico</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿La vivienda tiene pozo séptico?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(34,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(34,2);?>]		  
                ]);
        
                var options = {
                  title: 'B11 ¿La vivienda tiene pozo séptico?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B11'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_B11" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Servicios Públicos > Agua Potable</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Cuenta con acceso a agua potable?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(35,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(35,2);?>]		  
                ]);
        
                var options = {
                  title: 'B12 ¿Cuenta con acceso a agua potable?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B12'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_B12" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Servicios Públicos > Manejo de Basuras</h3>
                 </div>
            <div class="panel-body">
			<script type="text/javascript">
                google.charts.load("current", {packages:["corechart"]});
                google.charts.setOnLoadCallback(drawChart);
                function drawChart() {
                  var data = google.visualization.arrayToDataTable([
                    ["Element", "Cantidad", { role: "style" } ],
                    ['1. Camion recolector',  <?PHP echo $V_Clase->Contar(37,1);?>,'#4285f4'],
                    ['2. Enterrada',  <?PHP echo $V_Clase->Contar(37,2);?>,'#4285f4'],
                    ['3. Quemada', <?PHP echo $V_Clase->Contar(37,3);?>,'#4285f4'],
					['4. Botadero Comunitario', <?PHP echo $V_Clase->Contar(37,4);?>,'#4285f4'],
                    ['5, Otro',  <?PHP echo $V_Clase->Contar(37,5);?>,'#4285f4']
                        
                  ]);
            
                  var view = new google.visualization.DataView(data);
                  view.setColumns([0, 1,
                                   { calc: "stringify",
                                     sourceColumn: 1,
                                     type: "string",
                                     role: "annotation" },
                                   2]);
            
                  var options = {
                    title: "Gestión de Procesos ",
                    width: 600,
                    height: 400,
                    bar: {groupWidth: "95%"},
                    legend: { position: "none" },
                  };
                  var chart = new google.visualization.BarChart(document.getElementById("barchart_tContrato"));
                  chart.draw(view, options);
              }
              </script>
            <div id="barchart_tContrato"></div>            
            

            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Cómo eliminan la basura en el hogar?', 'Respuesta'],
                   ['1. Camion recolector',  <?PHP echo $V_Clase->Contar(37,1);?>],
                   ['2. Enterrada',  <?PHP echo $V_Clase->Contar(37,2);?>],
                   ['3. Quemada', <?PHP echo $V_Clase->Contar(37,3);?>],
				   ['4. Botadero Comunitario', <?PHP echo $V_Clase->Contar(37,4);?>],
                   ['5, Otro',  <?PHP echo $V_Clase->Contar(37,5);?>]		  
                ]);
        
                var options = {
                  title: 'B14 ¿Cómo eliminan la basura en el hogar?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B14'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_B14" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>      
              
        </article>



       <?PHP }elseif($_GET['mod']==52 and $_GET['opcion']==12){##Estadisticas C?>
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="text-center text-primary h3 bg-primary"><?PHP $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></div>
	<div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-user"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(50,1);?></div>
                                        <div>Familias con Falta Alimentos</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-list"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(32,1);?></div>
                                        <div>Familias con Fallas de Salud</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-alert"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(58,1);?></div>
                                        <div>Familias con Discriminación</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-tag"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(59,1);?></div>
                                        <div>Familias con Victimas</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
      </div>        
<?PHP $V_Clase->grafica_variable('C1',1);?>
<?PHP $V_Clase->grafica_variable('C2',1);?>
<?PHP $V_Clase->grafica_variable('C3',1);?>
<?PHP $V_Clase->grafica_variable('C4',1);?>
<?PHP $V_Clase->grafica_variable('C5',1);?>
<?PHP $V_Clase->grafica_variable('C6',1);?>
<?PHP $V_Clase->grafica_variable('C7',1);?>
<?PHP $V_Clase->grafica_variable('C8',1);?>
<?PHP $V_Clase->grafica_variable('C9',1);?>
<?PHP $V_Clase->grafica_variable('C10',1);?>
<?PHP $V_Clase->grafica_variable('C11',1);?>
<?PHP $V_Clase->grafica_variable('C12',1);?>
<?PHP $V_Clase->grafica_variable('C13',1);?>        
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Alimentación > Acceso a Alimentos</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['C1 ¿En los últimos 15 días se han acostado sin comer por falta de recursos y/o alimentos?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(50,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(50,2);?>]
                ]);
        
                var options = {
                  title: '¿En los últimos 15 días se han acostado sin comer por falta de recursos y/o alimentos?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C1'));
                chart.draw(data, options);
              }
            </script>
        
            <div id="piechart_C1" style="width:auto; height:400px;"></div>
                                       
              </div>
            </div>            
      </div>
        
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Alimentación > Preocupación por abastecimiento de alimentos</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['C2 ¿Existe preocupación por el abastecimiento de alimentos en su hogar?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(51,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(51,2);?>]			  
                ]);
        
                var options = {
                  title: '¿Existe preocupación por el abastecimiento de alimentos en su hogar?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C2'));
                chart.draw(data, options);	
              }
            </script>
                <div id="piechart_C2" style="width:auto; height:auto;"></div>                                       
                </div>
      		</div>
      </div>     
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Alimentación > Comidas al día</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Cuántas comidas consume al día?', 'Respuesta'],
                  ['1. Uno', <?PHP echo $V_Clase->Contar(52,1);?>],
                  ['2. Dos', <?PHP echo $V_Clase->Contar(52,2);?>],
				  ['3. Tres', <?PHP echo $V_Clase->Contar(52,3);?>],
                  ['4. Cuatro', <?PHP echo $V_Clase->Contar(52,4);?>],
                  ['5. Cinco', <?PHP echo $V_Clase->Contar(52,5);?>],
				  ['6. Seis', <?PHP echo $V_Clase->Contar(52,6);?>]				  		  		  
                ]);
        
                var options = {
                  title: 'C3 ¿Cuántas comidas consume al día?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C3'));
                chart.draw(data, options);	
              }
            </script>
                <div id="piechart_C3" style="width:auto; height:auto;"></div>                                       
                </div>
      		</div>
      </div>              

      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Acceso a Servicios de Salud > Estado de salud</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿En los últimos 30 días ha estado enfermo?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(53,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(53,2);?>]		  
                ]);
        
                var options = {
                  title: 'C4 ¿En los últimos 30 días ha estado enfermo?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C4'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_C4" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>
      </div>        
	

      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Acceso a Servicios de Salud > Dificultades de Acceso</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Tiene dificultades para el acceso a servicios médicos?', 'Respuesta'],
                  ['1. Niguna', <?PHP echo $V_Clase->Contar(54,1);?>],
                  ['2. Distancia', <?PHP echo $V_Clase->Contar(54,2);?>],	
                  ['3. Falta dinero', <?PHP echo $V_Clase->Contar(54,3);?>],
                  ['4. Barreras administrativas', <?PHP echo $V_Clase->Contar(54,4);?>]					  	  
                ]);
        
                var options = {
                  title: 'C5 ¿Tiene dificultades para el acceso a servicios médicos?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C5'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_C5" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>

	<div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Apropiación Tecnologia > Uso de aparatos tecnológicos</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Sabe utilizar aparatos tecnológicos?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(55,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(55,2);?>]		  
                ]);
        
                var options = {
                  title: 'C6 ¿Sabe utilizar aparatos tecnológicos?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C6'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_C6" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Apropiación Tecnologia > Acceso a servicio de Internet</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Tiene Acceso a Internet?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(56,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(56,2);?>]		  
                ]);
        
                var options = {
                  title: 'C7 ¿Tiene Acceso a Internet?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C7'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_C7" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Apropiación Tecnologia > Orientación del uso de Internet</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Usualmente para que usa Internet?', 'Respuesta'],
                   ['1. Consulta e Investigacion',  <?PHP echo $V_Clase->Contar(57,1);?>],
                   ['2. Redes sociales y ocio',  <?PHP echo $V_Clase->Contar(57,2);?>],
                   ['3. Trabajo y negocios ', <?PHP echo $V_Clase->Contar(57,3);?>],
				   ['4. Otro', <?PHP echo $V_Clase->Contar(57,4);?>]		  
                ]);

                var options = {
                  title: 'C8 ¿Usualmente para que usa Internet?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C8'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_C8" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>      
              
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Victimas > Nivel de discriminación</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Se ha sentido discriminado por su color de piel, raza o etnia?', 'Respuesta'],
                   ['1. Si',  <?PHP echo $V_Clase->Contar(58,1);?>],
                   ['2. No',  <?PHP echo $V_Clase->Contar(58,2);?>]	  
                ]);

                var options = {
                  title: 'C9 ¿Se ha sentido discriminado por su color de piel, raza o etnia?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C9'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_C9" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>      
              
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Victimas > Ha sido</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Ha sido victima de conflicto armado?', 'Respuesta'],
                   ['1. Si',  <?PHP echo $V_Clase->Contar(59,1);?>],
                   ['2. No',  <?PHP echo $V_Clase->Contar(59,2);?>]	  
                ]);

                var options = {
                  title: 'C10 ¿Ha sido victima de conflicto armado?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C10'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_C10" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>      
              
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Numero Usual Familia > Datos Promedio Familias</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Cuantos integrantes?', 'Respuesta'],
                   ['1. Uno',  <?PHP echo $V_Clase->Contar(62,1);?>],
                   ['2. Dos',  <?PHP echo $V_Clase->Contar(62,2);?>],
                   ['3. Tres', <?PHP echo $V_Clase->Contar(62,3);?>],
				   ['4. Cuatro', <?PHP echo $V_Clase->Contar(62,4);?>],
				   ['5. Cinco',  <?PHP echo $V_Clase->Contar(62,5);?>],
                   ['6. Seis', <?PHP echo $V_Clase->Contar(62,6);?>],
				   ['7. Siete', <?PHP echo $V_Clase->Contar(62,7);?>]		  
                ]);

                var options = {
                  title: 'C13 ¿Cuantos integrantes?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_C13'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_C13" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>      
              



        </article>
        
       <?PHP }elseif($_GET['mod']==52 and $_GET['opcion']==13){##Estadisticas D?>
		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="text-center text-primary h3 bg-primary"><?PHP $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></div>
	<div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-user"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(93,2);?></div>
                                        <div>Integrantes Desempleados</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-list"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(91,1);?></div>
                                        <div>Integrantes Discapacitados</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-alert"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(93,1);?></div>
                                        <div>Integrantes Embarazadas</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="glyphicon glyphicon-tag"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?PHP $V_Clase->Contar(89,1);?></div>
                                        <div>Integrantes Enfermos</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
      </div>        
        

<?PHP $V_Clase->grafica_variable_integrante('D6',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D8',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D9',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D10',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D15',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D16',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D17',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D18',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D19',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D20',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D21',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D22',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D23',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D24',1);?>

<?PHP $V_Clase->grafica_variable_integrante('D25',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D26',1);?>
<?PHP #$V_Clase->grafica_variable_integrante('D27',1); # Puntaje Sisben?>
<?PHP $V_Clase->grafica_variable_integrante('D28',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D29',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D30',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D31',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D32',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D33',2);?>
<?PHP $V_Clase->grafica_variable_integrante('D34',1);?>
<?PHP $V_Clase->grafica_variable_integrante('D35',1);?>


      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Personal > Sexo</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['Sexo', 'Respuesta'],
                  ['1. Hombre', <?PHP echo $V_Clase->Contar(70,1);?>],
                  ['2. Mujer', <?PHP echo $V_Clase->Contar(70,2);?>]
                ]);
        
                var options = {
                  title: 'D9 Sexo',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_D9'));
                chart.draw(data, options);
              }
            </script>
        
            <div id="piechart_D9" style="width:auto; height:400px;"></div>
                                       
              </div>
            </div>            
      </div>
        
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Personal > Parentestco</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['Parentesco', 'Respuesta'],
                  ['1. Jefe (a)', <?PHP echo $V_Clase->Contar(69,1);?>],
                  ['2. Cónyuge o compañero (a) ', <?PHP echo $V_Clase->Contar(69,2);?>],
				  ['3. Hijo (a) ', <?PHP echo $V_Clase->Contar(69,3);?>],
                  ['4. Yerno/Nuera', <?PHP echo $V_Clase->Contar(69,4);?>],
                  ['5. Nieto (a)', <?PHP echo $V_Clase->Contar(69,5);?>],
				  ['6. Padres o suegros', <?PHP echo $V_Clase->Contar(69,6);?>],
				  ['7. Hermanos (as)', <?PHP echo $V_Clase->Contar(69,7);?>],
                  ['8. Otros parientes', <?PHP echo $V_Clase->Contar(69,8);?>],
                  ['9. Otros no parientes', <?PHP echo $V_Clase->Contar(69,9);?>],
                  ['10. Hijastro (a)', <?PHP echo $V_Clase->Contar(69,10);?>]				  				  
                ]);
 
                var options = {
                  title: 'D8 Parentesco',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_B2'));
                chart.draw(data, options);	
              }
            </script>
                <div id="piechart_B2" style="width:auto; height:auto;"></div>                                       
                </div>
      		</div>
      </div>     
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Enfoque > Situación Diferencial</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['Situación Diferencial', 'Respuesta'],
                  ['1. Mujer Gestante', <?PHP echo $V_Clase->Contar(76,1);?>],
                  ['2. Madre Lactante', <?PHP echo $V_Clase->Contar(76,2);?>],
                  ['3. Adulto Mayor', <?PHP echo $V_Clase->Contar(76,3);?>],
                  ['4. Mujer Cabeza Hogar', <?PHP echo $V_Clase->Contar(76,4);?>],
				  ['5. Padre Cabeza Hogar', <?PHP echo $V_Clase->Contar(76,5);?>],
                  ['6. Ninguna de las Anteriores', <?PHP echo $V_Clase->Contar(76,6);?>]				  		  
                ]);
  
                 var options = {
                  title: 'D15 Situación Diferencial',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_D15'));
                chart.draw(data, options);	
              }
            </script>
                <div id="piechart_D15" style="width:auto; height:auto;"></div>  
                </div>
      		</div>
      </div>                   
	

      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Enfoque > Como se autoreconoce</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Cuenta con acceso a Alcantarillado?', 'Respuesta'],
                  ['1 Afrodescendiente', <?PHP echo $V_Clase->Contar(77,1);?>],
                  ['2 Afrocolombiano', <?PHP echo $V_Clase->Contar(77,2);?>],
				  ['3. Raizal', <?PHP echo $V_Clase->Contar(77,3);?>],
                  ['4. Palenquero', <?PHP echo $V_Clase->Contar(77,4);?>],
				  ['5. Negro', <?PHP echo $V_Clase->Contar(77,5);?>],
				  ['6. Kichwa', <?PHP echo $V_Clase->Contar(77,6);?>],
				  ['7. U´wa', <?PHP echo $V_Clase->Contar(77,7);?>],
                  ['8. Piaroa', <?PHP echo $V_Clase->Contar(77,8);?>],
				  ['9. Sikuani Playero', <?PHP echo $V_Clase->Contar(77,9);?>],
                  ['10. Inga', <?PHP echo $V_Clase->Contar(77,10);?>],
				  ['11. Makaguan', <?PHP echo $V_Clase->Contar(77,11);?>],
                  ['12. Betoy', <?PHP echo $V_Clase->Contar(77,12);?>],
				  ['13. Hitnu', <?PHP echo $V_Clase->Contar(77,13);?>],
                  ['14. No se Autoreconoce', <?PHP echo $V_Clase->Contar(77,14);?>]		  
                ]);
        
                var options = {
                  title: 'D16 ¿Como se Reconoce?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_D16'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_D16" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>

	<div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Educación > Población Escolarizada</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Se encuentra escolarizado?', 'Respuesta'],
                  ['1. Si', <?PHP echo $V_Clase->Contar(78,1);?>],
                  ['2. No', <?PHP echo $V_Clase->Contar(78,2);?>]		  
                ]);
        
                var options = {
                  title: 'D17 ¿Se encuentra escolarizado?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_D17'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_D17" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Educación > Nivel Escolaridad Alcanzado</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['Nivel Escolaridad Alcanzado', 'Respuesta'],
                  ['1 Ninguno', <?PHP echo $V_Clase->Contar(80,1);?>],
                  ['2 Primaria', <?PHP echo $V_Clase->Contar(80,2);?>],
				  ['3 Basica Secundaria (6 a 9)', <?PHP echo $V_Clase->Contar(80,3);?>],
                  ['4 Media (10 a 11)', <?PHP echo $V_Clase->Contar(80,4);?>],
				  ['5 Tecnico', <?PHP echo $V_Clase->Contar(80,5);?>],
                  ['6 Tecnologo', <?PHP echo $V_Clase->Contar(80,6);?>],
				  ['7 Universitario', <?PHP echo $V_Clase->Contar(80,7);?>],
                  ['8 PostGrado', <?PHP echo $V_Clase->Contar(80,8);?>],
				  ['9 Educación Propia', <?PHP echo $V_Clase->Contar(80,9);?>]			  
                ]);
                var options = {
                  title: 'D19 Nivel Escolaridad Alcanzado',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_D19'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_D19" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>
      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Educación > Aprovechamiento del Tiempo Libre</h3>
                 </div>
            <div class="panel-body">
            <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['¿Actividad Recreativa?', 'Respuesta'],
                   ['1. Deporte',  <?PHP echo $V_Clase->Contar(84,1);?>],
                   ['2. Cultura',  <?PHP echo $V_Clase->Contar(84,2);?>],
                   ['3. Artesanal', <?PHP echo $V_Clase->Contar(84,3);?>],
				   ['4. Culinaria', <?PHP echo $V_Clase->Contar(84,4);?>],
                   ['5. Cine',  <?PHP echo $V_Clase->Contar(84,5);?>],
				   ['6. Otro',  <?PHP echo $V_Clase->Contar(84,6);?>]		  
                ]);
        
                var options = {
                  title: 'D23 ¿Actividad Recreativa?',
                  is3D: true,
                };
        
                var chart = new google.visualization.PieChart(document.getElementById('piechart_D23'));
                chart.draw(data, options);	
              }
            </script>
            <div id="piechart_D23" style="width:auto; height:auto;"></div>                                       
            </div>
      	</div>        
      </div>      


      
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title">Información Laboral > Trabajos</h3>
                 </div>
            <div class="panel-body">
			<script type="text/javascript">
                google.charts.load("current", {packages:["corechart"]});
                google.charts.setOnLoadCallback(drawChart);
                function drawChart() {
                  var data = google.visualization.arrayToDataTable([
                    ["Element", "Cantidad", { role: "style" } ],
                    ['1 Agricultor',  <?PHP echo $V_Clase->Contar(94,1);?>,'#4285f4'],
                    ['2 Comerciante',  <?PHP echo $V_Clase->Contar(94,2);?>,'#4285f4'],
                    ['3 Estudiante', <?PHP echo $V_Clase->Contar(94,3);?>,'#4285f4'],
					['4 Empleado (a) Obrero (a)', <?PHP echo $V_Clase->Contar(94,4);?>,'#4285f4'],
                    ['5 Empleado (a) Domestico (a)',  <?PHP echo $V_Clase->Contar(94,5);?>,'#4285f4'],
					
                    ['6 Ganadero (a)',  <?PHP echo $V_Clase->Contar(94,6);?>,'#4285f4'],
                    ['7 Oficios Varios',  <?PHP echo $V_Clase->Contar(94,7);?>,'#4285f4'],
                    ['8 Pescador (a)', <?PHP echo $V_Clase->Contar(94,8);?>,'#4285f4'],
					['9 Docente', <?PHP echo $V_Clase->Contar(94,9);?>,'#4285f4'],
                    ['10 Funcionario (a) Público',  <?PHP echo $V_Clase->Contar(94,10);?>,'#4285f4'],
                    ['11 Profesional',  <?PHP echo $V_Clase->Contar(94,11);?>,'#4285f4'],
                    ['12 Servicios Técnicos',  <?PHP echo $V_Clase->Contar(94,12);?>,'#4285f4'],
                    ['13 Vendedor Ambulante', <?PHP echo $V_Clase->Contar(94,13);?>,'#4285f4'],
					['14 Minero', <?PHP echo $V_Clase->Contar(94,14);?>,'#4285f4'],
                    ['15 Trabajo en el hogar',  <?PHP echo $V_Clase->Contar(94,15);?>,'#4285f4'],
					['16 Modista / Sastre',  <?PHP echo $V_Clase->Contar(94,16);?>,'#4285f4'],
                    ['17 Artesano (a)',  <?PHP echo $V_Clase->Contar(94,17);?>,'#4285f4'],
                    ['18  Autoridad Tradicional (Cacique)', <?PHP echo $V_Clase->Contar(94,18);?>,'#4285f4'],
					['19 Gobernador Indígena', <?PHP echo $V_Clase->Contar(94,19);?>,'#4285f4'],
                    ['20 Otro',  <?PHP echo $V_Clase->Contar(94,20);?>,'#4285f4']                        
                  ]);
            
                  var view = new google.visualization.DataView(data);
                  view.setColumns([0, 1,
                                   { calc: "stringify",
                                     sourceColumn: 1,
                                     type: "string",
                                     role: "annotation" },
                                   2]);
            
                  var options = {
                    title: "D33 ¿Cuál es su ocupación? ",
                    width: 800,
                    height: 700,
                    bar: {groupWidth: "95%"},
                    legend: { position: "none" },
                  };
                  var chart = new google.visualization.BarChart(document.getElementById("barchart_D33"));
                  chart.draw(view, options);
              }
              </script>
            <div id="barchart_D33"></div>            
          </div>
      	</div>        
      </div>      
              
        </article>    
                
        <?PHP }elseif($_GET['mod']==53 and $_GET['opcion']==4){##Filtro Integrantes?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
              <div class="panel-body">
				
                
                <form name="form" action="ResultadosFiltrar.php" method="get" enctype="multipart/form-data">
                <input type="hidden" value="<?PHP echo $_GET['mod'];?>" name="mod">
                <input type="hidden" value="<?PHP echo $_GET['opcion'];?>" name="opcion">

    <div class="row">     
    	<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("A2");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6">
		<?PHP if($conf[0]['con_departamento']!=""){ $cargar=$conf[0]['con_departamento']; }else{ $cargar="";	} 
				   $V_Clase->comboDepartamento($cargar); ?>
        </div>
        <div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("A3");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6">
			<div id="div_municipio_edes" >
                    	<?PHP 
						if($conf[0]['con_municipio']!=""){ $cargar=$conf[0]['con_departamento']; 	}else{
							?>
                            <select class="form-control" id="mun" name="mun">
                                <option value="0">Seleccione el Municipio</option>
                            </select>							
						<?PHP
							}
							$V_Clase->comboMunicipio($cargar,$conf[0]['con_municipio']);
						?>
         	</div>
        </div>  
	</div>
                  
    <div class="row">     
    	<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("D1");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><?PHP $cargar=""; $V_Clase->trae_pregunta_respuesta("D1",$cargar);?></div>
        <div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("D2");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><?PHP $cargar=""; $V_Clase->trae_pregunta_respuesta("D2",$cargar);?></div>  
	</div>

    <div class="row">     
    	<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("D3");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><?PHP $cargar=""; $V_Clase->trae_pregunta_respuesta("D3",$cargar);?></div>
        <div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("D4");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><?PHP $cargar=""; $V_Clase->trae_pregunta_respuesta("D4",$cargar);?></div>  
	</div>                        

    <div class="row">     
    	<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("D7");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><?PHP $cargar=""; $V_Clase->trae_pregunta_respuesta("D7",$cargar);?></div>
 
	</div>                        
                                                                                             
                  <button type="submit" class="btn btn-success">Filtrar</button>                    
                </form>

              </div>
            </div>
        </article>

        <?PHP }elseif($_GET['mod']==53 and $_GET['opcion']==5){##Filtro Grupos Poblacionales?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?> - Cantidad Fichas</h3>
              </div>
              <div class="panel-body"> 
				<div class="col-xs-12 col-sm-12 col-lg-6 col-md-6 h3">
                	<a class="btn btn-sm btn-success" title="Ver Estadisticas por Grupo Poblacional" onClick="window.location='Reportes.php?mod=52&opcion=10&token=2&c=19'">
                    <span class="glyphicon glyphicon-stats"></span> Estadisticas
                    </a>
                    <a class="btn btn-sm btn-warning" title="Generar Censo" onClick="window.location='excel.php?mod=54&opcion=9&token=2&c=19'">
                    <span class="glyphicon glyphicon-download"></span> Censo
                    </a>
                
                Indigena <span class="badge"><?PHP $V_Clase->Contar(99,2); ?></span></div>
                
                <div class="col-xs-12 col-sm-12 col-lg-6 col-md-6 h3">
                    <a class="btn btn-sm btn-success" title="Ver Estadisticas por Grupo Poblacional" onClick="window.location='Reportes.php?mod=52&opcion=10&token=1&c=19'">
                    <span class="glyphicon glyphicon-stats"></span> Estadisticas
                    </a>
                    <a class="btn btn-sm btn-warning" title="Generar Censo" onClick="window.location='excel.php?mod=54&opcion=9&token=1&c=19'">
                    <span class="glyphicon glyphicon-download"></span> Censo
                    </a>
                
                Afrocolombiano <span class="badge"><?PHP $V_Clase->Contar(99,1); ?></span></div>
                
               </div>
            </div>	                	
        </article>  
 		<article class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Puede Seleccionar el Grupo Poblacional</h3>
              </div>
                <ul class="list-group">           
				<?PHP 
                $dato=$V_Clase->pag_pregunta_A17('A17');
                for ($i=0;$i<sizeof($dato);$i++){
                ?>
                <li class="list-group-item">
					<span class="badge"><?PHP $V_Clase->Contar(100,$dato[$i]['rep_numero']); ?></span>
					<a class="btn btn-sm btn-success" title="Ver Estadisticas por Grupo Poblacional" onClick="window.location='Reportes.php?mod=52&opcion=10&token=<?PHP echo $dato[$i]['rep_numero']; ?>&c=17'">
                    <span class="glyphicon glyphicon-stats"></span> Estadisticas
                    </a>
                    <a class="btn btn-sm btn-warning" title="Generar Censo" onClick="window.location='excel.php?mod=54&opcion=9&token=<?PHP echo $dato[$i]['rep_numero']; ?>&c=17'">
                    <span class="glyphicon glyphicon-download"></span> Censo
                    </a>
                    <?PHP echo $dato[$i]['rep_nombre'];?>
                </li>     
                <?PHP }?>
               </ul>
            </div>	                	
        </article> 
 
 		<article class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Puede Seleccionar Comunidad</h3>
              </div>
                <ul class="list-group">           
				<?PHP 
                $dato=$V_Clase->pag_pregunta_A18('A18');
                for ($i=0;$i<sizeof($dato);$i++){
                ?>
                <li class="list-group-item">
					<a class="btn btn-sm btn-success" title="Ver Estadisticas por Grupo Poblacional" onClick="window.location='Reportes.php?mod=52&opcion=10&token=<?PHP echo $dato[$i]['rep_numero']; ?>&c=18'">
                    <span class="glyphicon glyphicon-stats"></span> Estadisticas
                    </a>
                    <span class="badge"><?PHP $V_Clase->Contar(101,$dato[$i]['rep_numero']); ?></span>
					<a class="btn btn-sm btn-warning" title="Generar Censo" onClick="window.location='excel.php?mod=54&opcion=9&token=<?PHP echo $dato[$i]['rep_numero']; ?>&c=18'">
                    <span class="glyphicon glyphicon-download"></span> Censo
                    </a>
					<?PHP echo $dato[$i]['rep_nombre'];?>
                </li>     
                <?PHP }?>
               </ul>
            </div>	                	
        </article>                        
        
       <?PHP }elseif($_GET['mod']==53 and $_GET['opcion']==9){##Filtro Fichas?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
              <div class="panel-body">
				<form name="form" action="ResultadosFiltrar.php" method="get" enctype="multipart/form-data">
                <input type="hidden" value="<?PHP echo $_GET['mod'];?>" name="mod">
                <input type="hidden" value="<?PHP echo $_GET['opcion'];?>" name="opcion">
    <div class="row">     
    	<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("A2");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6">
		<?PHP if($conf[0]['con_departamento']!=""){ $cargar=$conf[0]['con_departamento']; }else{ $cargar="";	} 
				   $V_Clase->comboDepartamento($cargar); ?>
        </div>
        <div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("A3");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6">
			<div id="div_municipio_edes" >
                    	<?PHP 
						if($conf[0]['con_municipio']!=""){ $cargar=$conf[0]['con_departamento']; 	}else{
							?>
                            <select class="form-control" id="mun" name="mun">
                                <option value="0">Seleccione el Municipio</option>
                            </select>							
						<?PHP
							}
							$V_Clase->comboMunicipio($cargar,$conf[0]['con_municipio']);
						?>
         	</div>
        </div>  
	</div>
                  
    <div class="row">     
    	<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("A17");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><?PHP $cargar=""; $V_Clase->trae_pregunta_respuesta("A17",$cargar);?></div>
        <div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><b><?PHP echo $V_Clase->trae_pregunta("A18");?></b></div>
		<div class="col-xs-12 col-sm-6 col-lg-3 col-md-6"><?PHP $cargar=""; $V_Clase->trae_pregunta_respuesta("A18",$cargar);?></div>  
	</div>    
                                                                                     
                  <button type="submit" class="btn btn-success">Filtrar</button>                                   
                </form>
              </div>
            </div>
        </article>
 	                
		<?PHP }## Final de Ingresar?>     

                  
    </section>
    
</div>
<?PHP $V_Clase->gra_pie_pagina();?>


<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/funciones.js"></script>
<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
