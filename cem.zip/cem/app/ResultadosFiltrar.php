<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
	### Datos para Paginacion 
	if (isset($_GET["pos"]))
	{
		$inicio=$_GET["pos"];
	}else
	{
		$inicio=0;
	}### Datos para Paginacion 		
	?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/estilos.css">
<script type="text/javascript" src="js/loader.js"></script>
<title>Caracterización Étnica Municipal</title>
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP 
	$V_Clase->gra_menu_general();	
?>


    <section class="main row">
        <?PHP if($_GET['mod']==53 and $_GET['opcion']==4){##Filtro Integrantes?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>
                <table class="table table-condensed table-hover table-striped">
                <thead>
                  <tr>
                    <th>Ficha</th>
                    <th>D8</th>
                    <th>D7</th>
                    <th>A17</th> 
                    <th>Estado</th> 
                    <th>Operaciones</th>
                  </tr>
                </thead>  
                <?PHP 
                $dato=$V_Clase->pag_integrantes_filtrar($inicio,$porpagina,$_GET['dep'],$_GET['mun'],$_GET['D1'],$_GET['D2'],$_GET['D3'],$_GET['D4'],$_GET['D7']);
                ## Inicio For Recorrido
                for ($i=0;$i<sizeof($dato);$i++){
                ?>
                  <tr>
                    <td><?PHP echo $dato[$i]['A1'];?></td>
                    <td><?PHP echo $dato[$i]['D8'].' - '.$V_Clase->trae_respuesta('D8',$dato[$i]['D8']);?></td>
                    <td><?PHP echo $dato[$i]['D7'];?></td>        
                    <td><?PHP echo $dato[$i]['D1'].' '.$dato[$i]['D2'].' '.$dato[$i]['D3'].' '.$dato[$i]['D4'];?></td>
                    <td><?PHP if($dato[$i]['VIVO']==1){echo '<b class="text-danger">Vivo</b>';
                        }elseif($dato[$i]['VIVO']==2) {echo '<b class="text-success">Fallecido</b>';}?></td>
                    <td>
                            <a class="btn btn-info btn-sm" onClick="window.location='VerDatos.php?mod=51&opcion=2&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-eye-open"></span> Visualizar Ficha</a>    
                
                        <?PHP if($dato[$i]['ARCHIVO_DI'] == 'SIN_ARCHIVO_DI.pdf') {?>
                        <a class="btn btn-success btn-sm" href="javascript:void(0);" title="Cargar Documento de Identidad" onClick="window.location='CargarDatos.php?mod=51&opcion=16&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-paperclip"></span> Cargar DI</a>
                        <?PHP } ?>
                        <?PHP if($dato[$i]['ARCHIVO_DI'] != 'SIN_ARCHIVO_DI.pdf') {?>
                        <a class="btn btn-primary btn-sm" title="Descargar Documento de Identidad" target="_blank" onclick="window.location='./files/<?PHP echo $dato[$i]['ARCHIVO_DI']; ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Descargar DI</a>
                        <?PHP } ?>
                        
                        <?PHP if($dato[$i]['ARCHIVO_DI'] != 'SIN_ARCHIVO_DI.pdf') {?>
                        <a class="btn btn-primary btn-sm" title="Descargar Certificado" target="_blank" onclick="window.location='Generar_PDF.php?mod=53&opcion=8&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Certificado</a>
                        <?PHP } ?>
                

<!-- Inicio Generar Certificado-->
<div class="btn-group">
          <button class="btn btn-warning btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="glyphicon glyphicon-certificate"></span> Certificados <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=8&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Registro</a></li>
            
            <?PHP if($dato[$i]['D9']==1){?>
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=10&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Libreta Militar</a></li>
            <?PHP } ?>
            
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=11&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Afiliación Salud</a></li>

            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=12&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Duplicado Documento</a></li> 
            
            <li><a href="javascript:void(0);" title="Certificado de Registro" onclick="window.location='Generar_PDF.php?mod=53&opcion=13&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Laboral</a></li>         
            
            <li><a href="javascript:void(0);" title="Certificado de Servicios Salud" onclick="window.location='Generar_PDF.php?mod=53&opcion=14&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Servicios Salud</a></li>
            
            <li><a href="javascript:void(0);" title="Certificado de Matrimonio ó Unión Civil" onclick="window.location='Generar_PDF.php?mod=53&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>'" target="_parent">Unión</a></li>   

          </ul>
        </div>
<!-- Final Generar Certificado-->
                
                
                        <div class="btn-group">
                          <button class="btn btn-success btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="glyphicon glyphicon-edit"></span> Opciones <span class="caret"></span>
                          </button>
                          <ul class="dropdown-menu">
                            <li><a href="CargarDatos.php?mod=50&opcion=10&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>#tabs-4" title="Modificar Datos D. Integrante">Modificar</a></li>
                            <li><a href="CargarDatos.php?mod=50&opcion=14&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Mover Integrante de la Ficha">Mover de Ficha</a></li>
                            <?PHP if($dato[$i]['VIVO']!=2){?>
                            <li><a href="CargarDatos.php?mod=50&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Cambiar Estado Vivo a Fallecido">Mover a Fallecido</a></li>
                            <?PHP } ?>
                            <?PHP if($dato[$i]['VIVO']!=1){?>
                             <li><a href="CargarDatos.php?mod=50&opcion=16&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>&id=<?PHP echo base64_encode($dato[$i]['ID']); ?>&g=<?PHP echo $dato[$i]['GRUPO']; ?>" title="Cambiar Estado Fallecido a Vivo">Mover a Vivo</a></li>
                             <?PHP } ?>
                          </ul>
                        </div>
                
                        
                </td>  
                  </tr>
                <?PHP }## Final For Recorrido
                if(sizeof($dato) ==0){
                 ?>    
                <tr class="text-center h4 text-danger">
                    <td colspan="6">No hay Resultados.</td>
                </tr>
                <?PHP } ?>
                </table>              
              
            </div>
        </article>
<div class="text-center h4">Resultados Encontrados: <?PHP echo sizeof($dato);?><br /> <hr>
<?PHP
#### Inician los Datos de Paginacion
if ($inicio==0){
		echo '<span class="glyphicon glyphicon-arrow-left"></span> Anteriores';
	}else{
		$anterior=$inicio-$porpagina;
		echo '<a href="?mod='.$_GET['mod'].'&opcion='.$_GET['opcion'].'&pos='.$anterior.'&dep='.$_GET['dep'].'&mun='.$_GET['mun'].'&D1='.$_GET['D1'].'&D2='.$_GET['D2'].'&D3='.$_GET['D3'].'&D4='.$_GET['D4'].'&D7='.$_GET['D7'].'" title="Anteriores">
				<span class="glyphicon glyphicon-arrow-left"></span>
		Anteriores </a>';
	}
		
	echo '&nbsp;&nbsp;||&nbsp;&nbsp;';

	if (count($dato)==$porpagina){
		$proximo=$inicio+$porpagina;
		echo '<a href="?mod='.$_GET['mod'].'&opcion='.$_GET['opcion'].'&pos='.$proximo.'&dep='.$_GET['dep'].'&mun='.$_GET['mun'].'&D1='.$_GET['D1'].'&D2='.$_GET['D2'].'&D3='.$_GET['D3'].'&D4='.$_GET['D4'].'&D7='.$_GET['D7'].'" title="Siguientes">
			Siguientes
			<span class="glyphicon glyphicon-arrow-right"></span>
		</a>';
	}else{
		echo 'Siguientes <span class="glyphicon glyphicon-arrow-right"></span>';
	}
?>

</div>


        <?PHP }elseif($_GET['mod']==53 and $_GET['opcion']==9){##Filtro Fichas?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></h3>
              </div>

<table class="table table-condensed table-hover table-striped">
<thead>
  <tr>
    <th>Ficha</th>
    <th>A17</th>
    <th>A18</th> 
    <th>Estado</th> 
    <th>Operaciones</th>
  </tr>
</thead>  
<?PHP 
$dato=$V_Clase->pag_fichas_filtrar($inicio,$porpagina,$_GET['dep'],$_GET['mun'],$_GET['A17'],$_GET['A18']);
## Inicio For Recorrido
for ($i=0;$i<sizeof($dato);$i++){
?>
  <tr>
    <td><?PHP echo $dato[$i]['A1'];?></td>
    <td><?PHP echo $V_Clase->trae_respuesta('A17',$dato[$i]['A17']);?></td>
    <td><?PHP echo $V_Clase->trae_respuesta('A18',$dato[$i]['A18']);?></td>    
    <td><?PHP if($dato[$i]['ESTADO']==1){echo '<b class="text-danger">En Edición</b>';
		}elseif($dato[$i]['ESTADO']==2) {echo '<b class="text-success">Terminada</b>';}?></td>
    <td><?PHP if($dato[$i]['ESTADO']==1){
		
			if($dato[$i]['B1']==Null){
		?>
			<a class="btn btn-success btn-sm" href="javascript:void(0);" title="Continuar con Carga de Datos B" onClick="window.location='CargarDatos.php?mod=50&opcion=3&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-2'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>    

		<?PHP }elseif($dato[$i]['C1']==Null){?>
			<a class="btn btn-success btn-sm" href="javascript:void(0);" title="Continuar con Carga de Datos C" onClick="window.location='CargarDatos.php?mod=50&opcion=4&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-3'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>			
			
		<?PHP }else{?>
			<a class="btn btn-success btn-sm" href="javascript:void(0);" title="Continuar con Carga de Datos D" onClick="window.location='CargarDatos.php?mod=50&opcion=5&g=<?PHP echo $dato[$i]['GRUPO']; ?>&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>#tabs-4'"><span class="glyphicon glyphicon-plus"></span> Continuar</a>			            
		<?PHP	}
		
		
		}elseif($dato[$i]['ESTADO']==2) {?>
    		<a class="btn btn-info btn-sm" href="javascript:void(0);" title="Visualizar toda la Ficha" onClick="window.location='VerDatos.php?mod=51&opcion=1&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-eye-open"></span> Visualizar</a>    
		<?PHP }?>
        
        <?PHP if($dato[$i]['ESTADO']==2 and $dato[$i]['ARCHIVO'] == 'SIN_ARCHIVO.pdf') {?>
        <a class="btn btn-success btn-sm" href="javascript:void(0);" title="Cargar Archivo Ficha Escaneada" onClick="window.location='CargarDatos.php?mod=51&opcion=15&token=<?PHP echo base64_encode($dato[$i]['A1']); ?>'"><span class="glyphicon glyphicon-paperclip"></span> Cargar Ficha</a>
        <?PHP } ?>
        <?PHP if($dato[$i]['ARCHIVO'] != 'SIN_ARCHIVO.pdf') {?>
        <a class="btn btn-primary btn-sm" target="_blank" onclick="window.location='./files/<?PHP echo $dato[$i]['ARCHIVO']; ?>'"><span class="glyphicon glyphicon-cloud-download"></span> Descargar Ficha</a>
    	<?PHP } ?>

              
          
</td>  
  </tr>
<?PHP }## Final For Recorrido
if(sizeof($dato) ==0){
 ?>    
   <tr class="text-center h4 text-danger">
    <td colspan="5">No hay Resultados.</td>
   </tr>
<?PHP } ?>
</table>

            </div>
        </article>

<div class="text-center h4">Resultados Encontrados: <?PHP echo sizeof($dato);?><br /> <hr>
<?PHP
#### Inician los Datos de Paginacion
if ($inicio==0){
		echo '<span class="glyphicon glyphicon-arrow-left"></span> Anteriores';
	}else{
		$anterior=$inicio-$porpagina;
		echo '<a href="?mod='.$_GET['mod'].'&opcion='.$_GET['opcion'].'&pos='.$anterior.'&dep='.$_GET['dep'].'&mun='.$_GET['mun'].'&A17='.$_GET['A17'].'&A18='.$_GET['A18'].'" title="Anteriores">
				<span class="glyphicon glyphicon-arrow-left"></span>
		Anteriores </a>';
	}
		
	echo '&nbsp;&nbsp;||&nbsp;&nbsp;';

	if (count($dato)==$porpagina){
		$proximo=$inicio+$porpagina;
		echo '<a href="?mod='.$_GET['mod'].'&opcion='.$_GET['opcion'].'&pos='.$proximo.'&dep='.$_GET['dep'].'&mun='.$_GET['mun'].'&A17='.$_GET['A17'].'&A18='.$_GET['A18'].'" title="Siguientes">
			Siguientes
			<span class="glyphicon glyphicon-arrow-right"></span>
		</a>';
	}else{
		echo 'Siguientes <span class="glyphicon glyphicon-arrow-right"></span>';
	}
?>

</div> 	                
		<?PHP }## Final de Ingresar?>     

                  
    </section>
    
</div>
<?PHP $V_Clase->gra_pie_pagina();?>


<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/funciones.js"></script>
<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
