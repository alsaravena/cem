<?php
// Spanish; Castilian
global $l;
$l = Array();

// PAGE META DESCRIPTORS --------------------------------------

$l['a_meta_charset'] = 'UTF-8';
$l['a_meta_dir'] = 'ltr';
$l['a_meta_language'] = 'es';

// TRANSLATIONS --------------------------------------
$l['w_page'] = 'SIDOGEN = OscarCamiloCR -página';

//============================================================+
// END OF FILE
//============================================================+