<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
 ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">

<link rel="stylesheet" href="css/estilos.css">
<title>Caracterización Étnica Municipal</title>
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP $V_Clase->gra_menu_general();	?>


    <section class="main row">
<?PHP if(($_GET['mod']==51 and $_GET['opcion']==1) or ($_GET['mod']==51 and $_GET['opcion']==2)){##Inicio?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 
<div class="h3 text-center">Ficha Técnica 
		<?PHP $dato=$V_Clase->v_ficha($_GET['token']);
			if($dato[0]['GRUPO']==2){?>Indigena<?PHP }elseif($dato[0]['GRUPO']==1){?>Afrocolombiano<?PHP } ?>
            <?PHP if(isset($_GET['token'])){echo 'Numero: '.base64_decode($_GET['token']);}?>
    </div>
   
<!-- Inicio  - Componente A --> 
	<div class="row text-left h2 bg-primary">A. FICHA</div>
	<div class="row text-left h4 bg-primary">Identificación Ficha</div>

    <div class="row">    
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A1"); ?> : <?PHP echo $dato[0]['A1'];?>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A2");?> : <?PHP echo $V_Clase->trae_departamento($dato[0]['A2']);?>
        </div>
   
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A3");?> : <?PHP echo $V_Clase->trae_municipio($dato[0]['A3'],$dato[0]['A2']);?>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">    	
            <?PHP echo $V_Clase->trae_pregunta("A4");?> : <?PHP echo $dato[0]['A4'];?>
        </div>
    </div>                 

    <div class="row"> 
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A5");?> : <?PHP echo $dato[0]['A5'];?>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A6");?> : <?PHP echo $dato[0]['A6'];?>        
        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A7");?> : <?PHP echo $dato[0]['A7'];?>        
        </div> 
    </div> 
  
	  
    <div class="row text-left h4 bg-success">Gobierno <?PHP if($dato[0]['GRUPO']==1){ ?>AfroColombiano <?PHP }elseif($dato[0]['GRUPO']==2){?>Indigena<?PHP }?></div>
	<div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A8");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A8'];?></div>  
    </div>
    <div class="row">     
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A9");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A9'];?></div>  
	</div>
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A10");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A10'];?></div>  
	</div>
	<div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A11");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A11'];?></div>  
    </div>
    <div class="row">     
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A12");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A12'];?></div>  
	</div>
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A13");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A13'];?></div>  
	</div>
    <?PHP if($dato[0]['GRUPO']==1){ # Afrocolombiano?>
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A14");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A14'];?></div> 
    </div> 
    <?PHP }else{?> <input type="hidden" value="" name="A14"><?PHP } ?>
    <?PHP if($dato[0]['GRUPO']==2){ # Indigena?>   
    <div class="row">     
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A15");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A15'];?></div>  
	</div>
    <?PHP }else{?> <input type="hidden" value="" name="A15"><?PHP } ?>
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A16");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A16'];?></div>  
    </div>
    <div class="row">     
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A17");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A17'];?></div>  
	</div>
    <?PHP if($dato[0]['GRUPO']==2){ # Indigena?>   
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A18");?></div>
		<div class="col-xs-4">: <?PHP echo $dato[0]['A18'];?></div>  
	</div>
    <?PHP }else{?> <input type="hidden" value="" name="A18"><?PHP } ?>
    <div class="row text-left h4 bg-primary">Control de Trabajo</div>

    <div class="row">
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A19");?> : <?PHP echo $dato[0]['A19'];?>
      </div>
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A20");?> : <?PHP echo $dato[0]['A20'];?>
      </div>      
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A21");?> : <?PHP echo $dato[0]['A21'];?>
      </div>      
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A22");?> : <?PHP echo $dato[0]['A22'];?>
      </div>
    </div>

    <div class="row">
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A23");?> : <?PHP echo $dato[0]['A23'];?>
      </div>           
    </div>
          
                    
<!-- Inicio  - Componente B -->
	  <div class="row text-left h2 bg-primary">A. VIVIENDA</div>
      <div class="row text-left h4 bg-primary">Propiedad y Estado</div>
      
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("B1");?> : <?PHP echo $dato[0]['B1'];?>
          </div>
          
<!--Inicio Mostrar-->
<div id="b2-b8" style="display:<?PHP if(base64_decode($_GET['opcion']) == 7){ echo 'block;';}else{ echo 'block;';}?>">
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B2");?> : <?PHP echo $dato[0]['B2'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B3");?> : <?PHP echo $dato[0]['B3'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B4");?> : <?PHP echo $dato[0]['B4'];?>
          </div>
	</div><!--Final Mostrar-->                    
        </div>  
        
        <div class="row" id="b2-b8-2" style="display:<?PHP if(base64_decode($_GET['opcion']) == 7){ echo 'block;';}else{ echo 'block;';}?>">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("B5");?> : <?PHP echo $dato[0]['B5'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B6");?> : <?PHP echo $dato[0]['B6'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B7");?> : <?PHP echo $dato[0]['B7'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B8");?> : <?PHP echo $dato[0]['B8'];?>
          </div>
        </div>              
      
      <div class="row text-left h4 bg-success">Servicios Publicos</div>
      
        <div class="row">
          <div class="col-md-4">
		  <?PHP echo $V_Clase->trae_pregunta("B9");?> : <?PHP echo $dato[0]['B9'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("B10");?> : <?PHP echo $dato[0]['B10'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("B11");?> : <?PHP echo $dato[0]['B11'];?>
          </div>
        </div>   
        
        <div class="row">
          <div class="col-md-4">
		  <?PHP echo $V_Clase->trae_pregunta("B12");?> : <?PHP echo $dato[0]['B12'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("B13");?> : <?PHP echo $dato[0]['B13'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("B14");?> : <?PHP echo $dato[0]['B14'];?>
          </div>
        </div>   
                      
      <div class="row text-left h4 bg-primary">Información Productiva</div>

        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("B15");?> : <?PHP echo $dato[0]['B15'];?>
          </div>
          <div class="col-md-3" id="B16">
          <?PHP echo $V_Clase->trae_pregunta("B16");?> : <?PHP echo $dato[0]['B16'];?>
          </div>
          <div class="col-md-3" id="B17">
          <?PHP echo $V_Clase->trae_pregunta("B17");?> : <?PHP echo $dato[0]['B17'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B18");?> : <?PHP echo $dato[0]['B18'];?>
          </div>
        </div> 
        
        <div class="row">
          <div class="col-md-3" id="B19">
		  <?PHP echo $V_Clase->trae_pregunta("B19");?> : <?PHP echo $dato[0]['B19'];?>
          </div>
          <div class="col-md-3" id="B20">
          <?PHP echo $V_Clase->trae_pregunta("B20");?> : <?PHP echo $dato[0]['B20'];?>
          </div>
          <div class="col-md-3" id="B21">
          <?PHP echo $V_Clase->trae_pregunta("B21");?> : <?PHP echo $dato[0]['B21'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B22");?> : <?PHP echo $dato[0]['B22'];?>
          </div>
        </div> 
        
        <div class="row">
          <div class="col-md-3" id="B23">
		  <?PHP echo $V_Clase->trae_pregunta("B23");?> : <?PHP echo $dato[0]['B23'];?>
          </div>
          <div class="col-md-3" id="B24">
          <?PHP echo $V_Clase->trae_pregunta("B24");?> : <?PHP echo $dato[0]['B24'];?>
          </div>
          <div class="col-md-3" id="B25">
          <?PHP echo $V_Clase->trae_pregunta("B25");?> : <?PHP echo $dato[0]['B25'];?>
          </div>
          <div class="col-md-3" id="B26">
          <?PHP echo $V_Clase->trae_pregunta("B26");?> : <?PHP echo $dato[0]['B26'];?>
          </div>
        </div>                                       

<!-- Inicio  - Componente C -->
	<div class="row text-left h2 bg-primary">C. FAMILIA</div>
	<div class="row text-left h4 bg-primary">Alimentación</div>
        <div class="row">
          <div class="col-md-4">
		  <?PHP echo $V_Clase->trae_pregunta("C1");?> : <?PHP echo $dato[0]['C1'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C2");?> : <?PHP echo $dato[0]['C2'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C3");?>: <?PHP echo $dato[0]['C3'];?>
          </div>         
        </div> 

	<div class="row text-left h4 bg-success">Acceso a Servicios de Salud</div>        
        <div class="row">
          <div class="col-md-6">
          <?PHP echo $V_Clase->trae_pregunta("C4");?> : <?PHP echo $dato[0]['C4'];?>
          </div>
          <div class="col-md-6">
		  <?PHP echo $V_Clase->trae_pregunta("C5");?> : <?PHP echo $dato[0]['C5'];?>
          </div>
        </div> 
    
	<div class="row text-left h4 bg-success">Apropiación Tecnologia</div>        
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C6");?> : <?PHP echo $dato[0]['C6'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C7");?> : <?PHP echo $dato[0]['C7'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C8");?> : <?PHP echo $dato[0]['C8'];?>
          </div>
        </div>         

	<div class="row text-left h4 bg-primary">Victimas</div>        
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("C9");?> : <?PHP echo $dato[0]['C9'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("C10");?> : <?PHP echo $dato[0]['C10'];?>
          </div>
          <div class="col-md-3" id="C11">
          <?PHP echo $V_Clase->trae_pregunta("C11");?> : <?PHP echo $dato[0]['C11'];?>
          </div>
          <div class="col-md-3" id="C12">
          <?PHP echo $V_Clase->trae_pregunta("C12");?> : <?PHP echo $dato[0]['C12'];?>
          </div>
        </div>                 

	<div class="row text-left h4 bg-primary">Integrantes de la Familia</div>        
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("C13");?> : <?PHP echo $dato[0]['C13'];?>
          </div>
        </div>                                     
  

<!-- Final Tab 3 -->
<a name="i"></a>
	<div class="row text-left h2 bg-primary">D. INTEGRANTES</div>
    <?PHP 
	if($_GET['mod']==51 and $_GET['opcion']==1){  $dain=$V_Clase->v_integrantes_ficha($_GET['token']);
		}elseif($_GET['mod']==51 and $_GET['opcion']==2){ $dain=$V_Clase->v_integrantes_id($_GET['id']);
		}
	
	for ($i=0;$i<sizeof($dain);$i++){
	 ?>
    
	<div class="row text-left h4 bg-primary">Personal</div>
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("D1");?> : <?PHP echo $dain[$i]['D1'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D2");?> : <?PHP echo $dain[$i]['D2'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D3");?> : <?PHP echo $dain[$i]['D3'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D4");?> : <?PHP echo $dain[$i]['D4'];?>
          </div>
        </div>                 

        <div class="row">
         <?PHP if($dato[0]['GRUPO']==2){ # Indigena?>   
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D5");?> : <?PHP echo $dain[$i]['D5'];?>
          </div>  
         <?PHP }else{?> <input type="hidden" value="" name="D5"><?PHP } ?>

          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("D6");?> : <?PHP echo $dain[$i]['D6'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D7");?> : <?PHP echo $dain[$i]['D7'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D8");?> : <?PHP echo $dain[$i]['D8'];?>
          </div>
        </div>                 

        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("D9");?> : <?PHP echo $dain[$i]['D9'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D10");?> : <?PHP echo $dain[$i]['D10'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D11");?> : <?PHP echo $dain[$i]['D11'];?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D12");?> : <?PHP echo $dain[$i]['D12'];?>
          </div>
        </div>                 

        <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("D13");?>  : <?PHP echo $dain[$i]['D13'];?>
        </div>
   
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("D14");?> : <?PHP echo $dain[$i]['D14'];?>             
        </div>
          
        </div>                 




	<div class="row text-left h4 bg-success">Enfoque</div>
        <div class="row">
          <div class="col-md-6">
          <?PHP echo $V_Clase->trae_pregunta("D15");?> : <?PHP echo $dain[$i]['D15'];?>
          </div>
          <div class="col-md-6">
          <?PHP echo $V_Clase->trae_pregunta("D16");?> : <?PHP echo $dain[$i]['D16'];?>
          </div>

        </div> 
    
	<div class="row text-left h4 bg-success">Educación</div>
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D17");?> : <?PHP echo $dain[$i]['D17'];?>
          </div>
          <div class="col-md-4" id="D18">
          <?PHP echo $V_Clase->trae_pregunta("D18");?> : <?PHP echo $dain[$i]['D18'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D19");?> : <?PHP echo $dain[$i]['D19'];?>
          </div>
        </div> 
        
        <div class="row">
           <?PHP if($dato[0]['GRUPO']==2){ # Indigena?>   
              <div class="col-md-3">
              <?PHP echo $V_Clase->trae_pregunta("D20");?> : <?PHP echo $dain[$i]['D20'];?>
              </div>
            <?PHP }else{?> <input type="hidden" value="" name="D20"><?PHP } ?>
    
           <?PHP if($dato[0]['GRUPO']==2){ # Indigena?>   
              <div class="col-md-3">
              <?PHP echo $V_Clase->trae_pregunta("D21");?> : <?PHP echo $dain[$i]['D21'];?>
              </div>
            <?PHP }else{?> <input type="hidden" value="" name="D21"><?PHP } ?>

           <?PHP if($dato[0]['GRUPO']==2){ # Indigena?>   
              <div class="col-md-3">
              <?PHP echo $V_Clase->trae_pregunta("D22");?> : <?PHP echo $dain[$i]['D22'];?>
              </div>
            <?PHP }else{?> <input type="hidden" value="" name="D22"><?PHP } ?>                
          
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D23");?> : <?PHP echo $dain[$i]['D23'];?>
          </div>
        </div>         

    
	<div class="row text-left h4 bg-success">Salud y Discapacidad </div>
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D24");?> : <?PHP echo $dain[$i]['D24'];?>
          </div>
          <div class="col-md-4" id="D25">
          <?PHP echo $V_Clase->trae_pregunta("D25");?> : <?PHP echo $dain[$i]['D25'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D26");?> : <?PHP echo $dain[$i]['D26'];?>
          </div>
        </div>  

        <div class="row">
          <div class="col-md-4" id="D27">
          <?PHP echo $V_Clase->trae_pregunta("D27");?> : <?PHP echo $dain[$i]['D27'];?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D28");?> : <?PHP echo $dain[$i]['D28'];?>
          </div>
          <div class="col-md-4" id="D29">
          <?PHP echo $V_Clase->trae_pregunta("D29");?> : <?PHP echo $dain[$i]['D29'];?>
          </div>
        </div>  
        
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D30");?> : <?PHP echo $dain[$i]['D30'];?>
          </div>
          <div class="col-md-4" id="D31">
          <?PHP echo $V_Clase->trae_pregunta("D31");?> : <?PHP echo $dain[$i]['D31'];?>
          </div>
          <div class="col-md-4" id="D32">
          <?PHP echo $V_Clase->trae_pregunta("D32");?> : <?PHP echo $dain[$i]['D32'];?>
          </div>
        </div>          
    
	<div class="row text-left h4 bg-primary">Información Laboral</div>     
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D33");?> : <?PHP echo $dain[$i]['D33'];?>
          </div>
          <div class="col-md-4" id="D34">
          <?PHP echo $V_Clase->trae_pregunta("D34");?> : <?PHP echo $dain[$i]['D34'];?>
          </div>
          <div class="col-md-4" id="D35">
          <?PHP echo $V_Clase->trae_pregunta("D35");?> : <?PHP echo $dain[$i]['D35'];?>
          </div>
        </div>                  
  	<hr>
    <?PHP }
	if(sizeof($dain)==0){
	 ?>
        <div class="row">
          <div class="col-md-12 text-center">
           No tiene Integrantes la Ficha, Terminela.  
          </div>           
        </div>
     <?PHP } ?>
        <div class="row">
          <div class="col-md-12 text-center">
            
<?PHP if($_GET['mod']==51 and $_GET['opcion']==1){##Inicio?>   
            <input type="button" name="Imprimir" onClick="window.location='Imprimir.php?mod=51&opcion=3&token=<?PHP echo $_GET['token']?>';" class="btn btn-success btn-lg" value="Imprimir MD Familia" >
            <input type="button" name="Generar" onClick="window.location='Generar_PDF.php?mod=51&opcion=6&token=<?PHP echo $_GET['token']?>';" class="btn btn-success btn-lg" value="Descargar Ficha Familia" >
            
<?PHP }elseif($_GET['mod']==51 and $_GET['opcion']==2){?>            
            <input type="button" name="Imprimir" onClick="window.location='Imprimir.php?mod=51&opcion=3&token=<?PHP echo $_GET['token']?>';" class="btn btn-success btn-lg" value="Imprimir MD Familia" > 
            
            <input type="button" name="Imprimir" onClick="window.location='Imprimir.php?mod=51&opcion=4&token=<?PHP echo $_GET['token']?>&id=<?PHP echo $_GET['id']?>';" class="btn btn-success btn-lg" value="Imprimir MD Integrante" >
            
            <a href="Generar_PDF.php?mod=51&opcion=5&token=<?PHP echo $_GET['token']?>&id=<?PHP echo $_GET['id']?>" class="btn btn-success btn-lg" target="_blank">Descargar Ficha Individual</a>            
<?PHP } ?>                        

            
            
            <input type="hidden" name="mod" value="50">
            <input type="hidden" name="g" value="<?PHP echo $dato[0]['GRUPO'];?>">
            <input type="hidden" name="token" value="<?PHP echo $_GET['token']?>">       
          </div>           
        </div>
                    
<!-- Final Ver Ficha-->  
 
    
        </article>
        <?PHP }## Final de Ingresar?>     


<?PHP if($_GET['mod']==51 and $_GET['opcion']==7){##Inicio?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 
<div class="h3 text-center">Ficha Técnica 
		<?PHP $dato=$V_Clase->v_ficha($_GET['token']);
			if($dato[0]['GRUPO']==2){?>Indigena<?PHP }elseif($dato[0]['GRUPO']==1){?>Afrocolombiano<?PHP } ?>
            <?PHP if(isset($_GET['token'])){echo 'Numero: '.base64_decode($_GET['token']);}?>
    </div>
   
<!-- Inicio  - Componente A --> 
	<div class="row text-left h2 bg-primary">A. FICHA</div>
	<div class="row text-left h4 bg-primary">Identificación Ficha</div>

    <div class="row">    
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A1"); ?> : <?PHP echo $dato[0]['A1'];?>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A2");?> : <?PHP echo $V_Clase->trae_departamento($dato[0]['A2']);?>
        </div>
   
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A3");?> : <?PHP echo $V_Clase->trae_municipio($dato[0]['A3'],$dato[0]['A2']);?>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">    	
            <?PHP echo $V_Clase->trae_pregunta("A4");?> : <?PHP echo $dato[0]['A4'];?>
        </div>
    </div>                 

    <div class="row"> 
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A5");?> : <?PHP echo $dato[0]['A5'];?>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A6");?> : <?PHP echo $dato[0]['A6'];?>        
        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A7");?> : <?PHP echo $dato[0]['A7'];?>        
        </div> 
    </div> 

	<div class="row">
    	<div class="h3 text-center">Novedades Relacionadas</div>
    </div>
	<div class="row bg-primary">
       <div class="col-xs-2">Id Nov</div>	   
       <div class="col-xs-4">Operación</div>	   
       <div class="col-xs-4">Usuario</div>	   
       <div class="col-xs-2">Fecha Evento</div>	   	   
	</div>
<?PHP 
$vNov=$V_Clase->pag_novedades_ficha(base64_decode($_GET['token']));
if(sizeof($vNov) != 0 ){
for ($i=0;$i<sizeof($vNov);$i++)
{?>
	<div class="row">
       <div class="col-xs-2"><?PHP echo $vNov[$i]['seg_id'];?></div>	   
       <div class="col-xs-4"><?PHP echo $vNov[$i]['seg_operacion'];?></div>	   
       <div class="col-xs-4"><?PHP echo $vNov[$i]['seg_usuario'];?></div>	   
       <div class="col-xs-2"><?PHP echo $vNov[$i]['seg_fh_evento'];?></div>	    
	</div>

<?PHP }

}else{ ?>
	<div class="row">
    	<div class="h4 text-center">No hay registros.</div>
    </div>
<?PHP } ?>


        </article>
        <?PHP }## Final de Mostrar Novedades?>    
                  
    </section>
    
</div>
<?PHP $V_Clase->gra_pie_pagina();?>


<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="js/funciones.js"></script>

<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
