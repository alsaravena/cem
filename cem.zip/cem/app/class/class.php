<?php
session_start();
date_default_timezone_set('America/Bogota');
setlocale(LC_ALL, 'es_ES');
$hoy =date('Y-m-d');
$fecha_file=date('YmdHis');
$fecha_server=date('Y-m-d');
$pre_file = substr(md5(uniqid(rand())),0,10);
$porpagina=50;
$name_bd= "bd_caracterizacion";
class cTrabajo
{

	private $configuracion=array();
	private $pregunta=array();
	private $celda=array();
	private $dato=array();
	private $ficha=array();
	private $integrante=array();
	private $candidato=array();
	private $municipios=array();
	private $novedades=array();
	private $usuarios=array();
	
		
	public static function con()
	{
#web    $con=mysql_connect("localhost:3306","cem_bd_user","CEMEtnica2016*");
#ofi     $con=mysql_connect("localhost","root","123456");
#casa   
		$con=mysql_connect("localhost","root","");
		mysql_query("SET NAMES 'utf8'");
		mysql_select_db("bd_caracterizacion");
		#mysql_select_db("saravena_cem");
			
		return $con;
	}
	
	public function Guia_Diseno($mod, $op)
	{
		$sql="select * from par_guias where guia_publico =1 and guia_modulo = '".$mod."' and guia_opcion = '".$op."'" ;
		$res=mysql_query($sql, cTrabajo::con()) or die ('Error seleccionado Guia');
		$guia=mysql_fetch_assoc($res); 
		echo $guia['guia_titulo'];
	}
	
	public static function comboUnPais($cargar)
	{

	$sSQL="select * from par_un_paises ;";
	$result=mysql_query($sSQL,cTrabajo::con());
	?>
	<select class="form-control input-sm" id="pais" name="pais" title="Seleccione el Pais." onChange ="refre_capa(document.form4.pais.value, 'div_dep_edes', 'mod_com_ajax.php', '4')">
	<option title="0 - Seleccione Uno... " value="0"  selected>0 - Seleccione Uno... </option>
	<?PHP				$c=0;
	while ($row=mysql_fetch_assoc($result))
	{
    	if(($cargar==0) && $c==0){ 			$c=1;
		echo '<option title="'.$row["pa_nombre"].'" value="'.$row["pa_id"].'">'.$row["pa_id"].' - '.$row["pa_nombre"].'</option>';
		}else{
   			if($cargar==$row["pa_id"]){
   			echo '<option title="'.$row["pa_nombre"].'" value="'.$row["pa_id"].'" selected>'.$row["pa_id"].' - '.$row["pa_nombre"].'</option>';
			}else{
			echo '<option title="'.$row["pa_nombre"].'" value="'.$row["pa_id"].'">'.$row["pa_id"].' - '.$row["pa_nombre"].'</option>';
			}
		}
		
	 }
	 echo '</select>';
	}	

	public static function comboUnDepartamentos($cargar,$dep)
	{

	$sSQL="select * from par_un_departamentos where pa_id =".$cargar." ;";
	$result=mysql_query($sSQL,cTrabajo::con());
?>
<select class="form-control input-sm" id="dep_un" name="dep_un" title="Seleccione el Departamento." onChange ="refre_capa_dos(document.form4.dep_un.value, 'div_mun_un', 'mod_com_ajax.php', '5', document.form4.pais.value)" title="Debe seleccionar">
	<?PHP
    				$c=0;
	while ($row=mysql_fetch_assoc($result))
	{
    	if(($cargar==0) && $c==0){ 			$c=1;
		echo '<option title="'.$row["dep_nombre"].'" value="'.$row["dep_id"].'" selected>'.$row["dep_nombre"].'</option>';
		}else{
   			if($dep==$row["dep_id"]){
   			echo '<option title="'.$row["dep_nombre"].'" value="'.$row["dep_id"].'" selected>'.$row["dep_nombre"].'</option>';
			}else{
			echo '<option title="'.$row["dep_nombre"].'" value="'.$row["dep_id"].'">'.$row["dep_nombre"].'</option>';
			}
		}
		
	 }
	 echo '</select>';
	}

	public static function comboUnMunicipio($pais,$departamento,$cargar)
	{

	$sSQL="select * from par_un_municipio where pa_id = ".$pais." AND dep =".$departamento."  ;";
	$result=mysql_query($sSQL,cTrabajo::con());

	echo '<select class="form-control input-sm" id="mun_un" name="mun_un" title="Debe seleccionar">';				$c=0;
	while ($row=mysql_fetch_assoc($result))
	{
    	if(($cargar==0) && $c==0){ 			$c=1;
		echo '<option title="'.$row["mun_nombre"].'" value="'.$row["mun_id"].'" selected>'.$row["mun_nombre"].'</option>';
		}else{
   			if($cargar==$row["mun_id"]){
   			echo '<option title="'.$row["mun_nombre"].'" value="'.$row["mun_id"].'" selected>'.$row["mun_nombre"].'</option>';
			}else{
			echo '<option title="'.$row["mun_nombre"].'" value="'.$row["mun_id"].'">'.$row["mun_nombre"].'</option>';
			}
		}
		
	 }
	 echo '</select>';
	}	


	
	public static function comboDepartamento($cargar)
	{

	$sSQL="select * from par_departamentos ;";
	$result=mysql_query($sSQL,cTrabajo::con());
	?>
	<select class="form-control input-sm" id="dep" name="dep" title="Seleccione el Departamento." onChange ="refre_capa(document.form.dep.value, 'div_municipio_edes', 'mod_com_ajax.php', '1')"><?PHP				$c=0;
	while ($row=mysql_fetch_assoc($result))
	{
    	if(($cargar==0) && $c==0){ 			$c=1;
		echo '<option title="'.$row["dep_nombre"].'" value="'.$row["dep_id"].'" selected>'.$row["dep_nombre"].'</option>';
		}else{
   			if($cargar==$row["dep_id"]){
   			echo '<option title="'.$row["dep_nombre"].'" value="'.$row["dep_id"].'" selected>'.$row["dep_nombre"].'</option>';
			}else{
			echo '<option title="'.$row["dep_nombre"].'" value="'.$row["dep_id"].'">'.$row["dep_nombre"].'</option>';
			}
		}
		
	 }
	 echo '</select>';
	}	

	public static function comboMunicipio($cargar,$mun)
	{

	$sSQL="select * from par_municipio where dep =".$cargar." or dep=1  ;";
	$result=mysql_query($sSQL,cTrabajo::con());

	echo '<select class="form-control input-sm" id="mun" name="mun" title="Debe seleccionar">';				$c=0;
	while ($row=mysql_fetch_assoc($result))
	{
    	if(($cargar==0) && $c==0){ 			$c=1;
		echo '<option title="'.$row["mun_nombre"].'" value="'.$row["mun_id"].'" selected>'.$row["mun_nombre"].'</option>';
		}else{
   			if($mun==$row["mun_id"]){
   			echo '<option title="'.$row["mun_nombre"].'" value="'.$row["mun_id"].'" selected>'.$row["mun_nombre"].'</option>';
			}else{
			echo '<option title="'.$row["mun_nombre"].'" value="'.$row["mun_id"].'">'.$row["mun_nombre"].'</option>';
			}
		}
		
	 }
	 echo '</select>';
	}	
	
	public static function comboRol($cargar)
	{

	$sSQL="select * from seg_usuarios_rol order by rol_id ASC ;";
	$result=mysql_query($sSQL,cTrabajo::con());

	echo '<select class="form-control input-sm" id="rol" name="rol" title="Debe seleccionar">';				$c=0;
	while ($row=mysql_fetch_assoc($result))
	{
    	if(($cargar==0) && $c==0){ 			$c=1;
		echo '<option title="'.$row["rol_nombre"].'" value="'.$row["rol_id"].'" selected>'.$row["rol_nombre"].'</option>';
		}else{
   			if($cargar==$row["rol_id"]){
   			echo '<option title="'.$row["rol_nombre"].'" value="'.$row["rol_id"].'" selected>'.$row["rol_nombre"].'</option>';
			}else{
			echo '<option title="'.$row["rol_nombre"].'" value="'.$row["rol_id"].'">'.$row["rol_nombre"].'</option>';
			}
		}
		
	 }
	 echo '</select>';
	}	


## Cargar Datos de Acceso	
	public function Ins_HistorialAccesos($ip,$user,$id_sesion,$nav,$so)
	{
	    $sql="insert into seg_usuarios_log values (Null,$user,NOW(),'$ip', '$nav', '$so', '$id_sesion', Null, Null, Null); "; 
		$res=mysql_query($sql,cTrabajo::con());
	}	
public function detectar()
{
	$browser=array("IE","OPERA","MOZILLA","NETSCAPE","FIREFOX","SAFARI","CHROME");
	$os=array("WIN","MAC","LINUX");
 
	# definimos unos valores por defecto para el navegador y el sistema operativo
	$info['browser'] = "OTHER";
	$info['os'] = "OTHER";
 
	# buscamos el navegador con su sistema operativo
	foreach($browser as $parent)
	{
		$s = strpos(strtoupper($_SERVER['HTTP_USER_AGENT']), $parent);
		$f = $s + strlen($parent);
		$version = substr($_SERVER['HTTP_USER_AGENT'], $f, 15);
		$version = preg_replace('/[^0-9,.]/','',$version);
		if ($s)
		{
			$info['browser'] = $parent;
			$info['version'] = $version;
		}
	}
 
	# obtenemos el sistema operativo
	foreach($os as $val)
	{
		if (strpos(strtoupper($_SERVER['HTTP_USER_AGENT']),$val)!==false)
			$info['os'] = $val;
	}
 
	# devolvemos el array de valores
	return $info;
}	

## Listar Departamentos 
	public function l_Departamentos()
	{
		$sql="SELECT * FROM `par_departamentos` ORDER BY  `dep_nombre` ASC";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
		return $this->celda;
	}

#### Cargar Municipios desde Departamentos
	public function l_Municipios($id)
	{
		$sql="select * from par_municipio where dep =".$id." or dep =1";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->dato[]=$reg;
		}
		return $this->dato;
	}	

#### Cargar Departamentos  desde Pais
	public function l_un_Departamentos($id)
	{
		$sql="select * from par_un_departamentos where pa_id =".$id.";";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->dato[]=$reg;
		}
		return $this->dato;
	}
#### Cargar Municipios desde Departamentos y Pais
	public function l_un_Municipios($pais,$departamento)
	{
		$sql="select * from par_un_municipio where pa_id = ".$pais." AND dep =".$departamento." ;";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->dato[]=$reg;
		}
		return $this->dato;
	}	


	public function pag_fichas($inicio,$porpagina,$opcion)
	{
		if($_SESSION['user_rol']<=2){
		$sql="SELECT * FROM  `ce_nucleo`  
				ORDER BY  A1 DESC
				limit $inicio,$porpagina ;";
		}else{
		$sql="SELECT * FROM  `ce_nucleo`  
				WHERE A19 = ".$_SESSION['user_cedula']."
				ORDER BY  A1 DESC
				limit $inicio,$porpagina ;";	
		}

		//echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
			return $this->celda;
	} ### Final

	public function pag_fichas_busqueda($s,$inicio,$porpagina)
	{
		$sql="SELECT * FROM  `ce_nucleo`
				WHERE
				A1 LIKE '%".$s."%'  
				ORDER BY  A1 DESC
				limit $inicio,$porpagina ;";
		//echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
			return $this->celda;
	} ### Final	
	
	public function pag_fichas_filtrar($inicio,$porpagina,$dep,$mun,$A17,$A18)
	{

$SQLini="SELECT * FROM  `ce_nucleo`   
			WHERE ";
### Variable 1
if(isset($dep) and $dep>0){
	$SQLini.=" A2 = '".$dep."' "; 		$sql1=1;
}else{ 
	$sql1=" " ; 
}
### Variable 2	
if(isset($mun) and $mun>0){
	if($sql1==" "){
		$SQLini.=" A3 = '".$mun."' "; 			$sql2=1;
	}else{
		$SQLini.=" AND A3 = '".$mun."' "; 			$sql2=" ";
	}
}else{
	$sql2=" "; 
}
	
### Variable 3
if(isset($A17) and $A17>0){
	if($sql1==" " ){
		$SQLini.=" A17 = '".$A17."' "; 			$sql3=1;
	}else{
		$SQLini.=" AND A17 = '".$A17."' "; 			$sql3=" ";
	}
}else{
	$sql3=" "; 
}

### Variable 4
if(isset($A18) and $A18>0){
	if($sql1==" " ){
		$SQLini.=" A18 = '".$A18."' "; 			$sql4=1;
	}else{
		$SQLini.=" AND A18 = '".$A18."' "; 			$sql4=" ";
	}
}else{
	$sql4=" "; 
}

	$SQLfinal=" ORDER BY  A1 DESC
				limit $inicio,$porpagina ;";
	$sql= $SQLini.$SQLfinal;

		//echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
			return $this->celda;
	} ### Final	
	
## Ver Ficha
	public function v_ficha($token)
	{
		$sql="SELECT * FROM  `ce_nucleo` where A1 =".base64_decode($token).";";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->ficha[]=$reg;
		}
		return $this->ficha;
	}
	
## Ver Integrante ficha
	public function v_integrantes_ficha($token)
	{
		$sql="SELECT * FROM  `ce_integrantes` where A1 =".base64_decode($token)." ORDER BY D8 ASC ;";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->integrante[]=$reg;
		}
		return $this->integrante;
	}			
	
## Ver Integrante ID
	public function v_integrantes_id($token)
	{
		$sql="SELECT * FROM  `ce_integrantes` where ID =".base64_decode($token)." ORDER BY D8 ASC ; ";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->integrante[]=$reg;
		}
		return $this->integrante;
	}	
	
## Ver Integrante ID Fallecido
	public function v_integrantes_fallecido($token)
	{
		$sql="UPDATE ce_integrantes SET `VIVO` = '2' WHERE `ID` = ".base64_decode($token).";";
		$res=mysql_query($sql, cTrabajo::con());		
	}		
## Ver Integrante ID Vivo
	public function v_integrantes_vivo($token)
	{
		$sql="UPDATE ce_integrantes SET `VIVO` = '1' WHERE `ID` = ".base64_decode($token).";";
		$res=mysql_query($sql, cTrabajo::con());		
	}	
	public function pag_integrantes($inicio,$porpagina,$opcion)
	{

		if($_SESSION['user_rol']<=2){
		$sql="SELECT * FROM  `ce_integrantes`
				INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1  
				ORDER BY  ce_integrantes.A1 DESC
				limit $inicio,$porpagina ;";
		}else{
		$sql="SELECT * FROM  `ce_integrantes`
				INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 
				WHERE ce_nucleo.A19 = ".$_SESSION['user_cedula']." 
				ORDER BY  ce_integrantes.A1 DESC
				limit $inicio,$porpagina ;";	
		}



		//echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->integrante[]=$reg;
		}
			return $this->integrante;
	} ### Final 

	public function pag_integrantes_busqueda($s,$inicio,$porpagina)
	{

		$sql="SELECT * FROM  `ce_integrantes`
				INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 	
				WHERE
				D7 LIKE '%".$s."%'   
				ORDER BY  ce_integrantes.A1 DESC
				limit $inicio,$porpagina ;";
		//echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->integrante[]=$reg;
		}
			return $this->integrante;
	} ### Final 

	public function pag_integrantes_filtrar($inicio,$porpagina,$dep,$mun,$D1,$D2,$D3,$D4,$D7)
	{

$SQLini="SELECT * FROM  `ce_integrantes`
				INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1  
				WHERE ";
### Variable 1
if(isset($dep) and $dep>0){
	$SQLini.=" A2 = '".$dep."' "; 		$sql1=1;
}else{ 
	$sql1=" " ; 
}
### Variable 2	
if(isset($mun) and $mun>0){
	if($sql1==" "){
		$SQLini.=" A3 = '".$mun."' "; 			$sql2=1;
	}else{
		$SQLini.=" AND A3 = '".$mun."' "; 			$sql2=" ";
	}
}else{
	$sql2=" "; 
}
### Variable 5
if($D4 == ""){
	$sql5=" "; 
}else{
	if($sql1==" " and $sql2==" "){
		$SQLini.=" D4 LIKE '%".$D4."%' "; 			$sql5=1;
	}else{
		$SQLini.=" AND D4 LIKE '%".$D4."%' " ; 			$sql5=" ";
	}		
}

### Variable 6	
if(isset($D7) and $D7>0){
	if($sql1==" " and $sql2==" " and $sql5==" "){
		$SQLini.=" D7 = ".$D7." "; 			$sql6=1;
	}else{
		$SQLini.=" AND D7 = ".$D7." " ; 			$sql6=" ";
	}		
}else{
	$sql6=" "; 
}	
	
### Variable 3
if($D3 == ""){
	$sql3=" "; 
}else{
	if($sql1==" " and $sql2==" " and $sql5==" " and $sql6==" "){
		$SQLini.=" D3 LIKE '%".$D3."%' "; 			$sql3=1;
	}else{
		$SQLini.=" AND D3 LIKE '%".$D3."%' " ; 			$sql3=" ";
	}		
}
### Variable 4
if($D2 == ""){
	$sql4=" "; 
}else{
	if($sql1==" " and $sql2==" " and $sql5==" " and $sql6==" "){
		$SQLini.=" D2 LIKE '%".$D2."%' "; 			$sql4=1;
	}else{
		$SQLini.=" AND D2 LIKE '%".$D2."%' " ; 			$sql4=" ";
	}		
}
### Variable 7
if($D1 == ""){
	$sql7=" "; 
}else{
	if($sql1==" " and $sql2==" " and $sql3==" " and $sql5==" " and $sql6==" "){
		$SQLini.=" D1 LIKE '%".$D1."%' "; 			$sql7=1;
	}else{
		$SQLini.=" AND D1 LIKE '%".$D1."%' " ; 			$sql7=" ";
	}		
}

	$SQLfinal=" ORDER BY  ce_integrantes.A1 DESC
				limit $inicio,$porpagina ; ;";
	$sql= $SQLini.$SQLfinal;
			
		#echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->integrante[]=$reg;
		}
			return $this->integrante;
	} ### Final 


	public function pag_gestantes($inicio,$porpagina,$opcion)
	{

		$sql="SELECT *, (SELECT period_diff(date_format(now(), '%Y%m'), date_format(A22, '%Y%m')) FROM ce_nucleo WHERE ce_integrantes.A1 = ce_nucleo.A1) AS meses 
		FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 
		WHERE D15 = '1' ORDER BY A20 DESC
		limit $inicio,$porpagina;";
		//echo "$sql<br>"; SELECT *, (SELECT DATEDIFF(`decr_fecha`, NOW())) as dias FROM decretos 
		/*SELECT *, (SELECT period_diff(date_format(now(), '%Y%m'), date_format(A22, '%Y%m')) FROM ce_nucleo) AS meses FROM  `ce_integrantes` 
				INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1
				WHERE D32 = '1' 
				
				ORDER BY  A20 DESC
				limit $inicio,$porpagina 
				select period_diff(date_format(now(), '%Y%m'), date_format(A22, '%Y%m')) as meses from ce_nucleo
				*/		
				
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->integrante[]=$reg;
		}
			return $this->integrante;
	} ### Final 


	public function pag_integrantes_rc_ti($inicio,$porpagina,$opcion)
	{

		$sql="SELECT ID, A1, D1, D2, D3, D4, D11, YEAR( CURDATE( ) ) - YEAR( D11 ) - IF( MONTH( CURDATE( ) ) < MONTH( D11), 1, IF ( MONTH(CURDATE( )) = MONTH(D11), IF (DAY( CURDATE( ) ) < DAY( D11 ),1,0 ),0)) AS pers_annos, MONTH(CURDATE()) - MONTH( D11) + 12 * IF( MONTH(CURDATE())<MONTH(D11), 1,IF(MONTH(CURDATE())=MONTH(D11),IF (DAY(CURDATE())<DAY(D11),1,0),0) ) - IF(MONTH(CURDATE())<>MONTH(D11),(DAY(CURDATE())<DAY(D11)), IF (DAY(CURDATE())<DAY(D11),1,0 ) ) AS pers_meses, ( DAY( CURDATE( ) ) - DAY( D11 ) +30 * ( DAY(CURDATE( )) < DAY(D11) )) AS pers_dias FROM ce_integrantes
		
				WHERE D6=3 OR D6=4  
				ORDER BY  A1 DESC
				limit $inicio,$porpagina ;";
		//echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
			return $this->celda;
	} ### Final 

	##### Inicio Trae Cuantos Integrantes Ficha
	public function trae_cuantos_integrantes($token)
	{
		$sql="SELECT C13 FROM ce_nucleo  WHERE A1 = '$token';";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error en 011: Traer Cuantos Integrantes");
		$reg=mysql_fetch_array($ejecutar); 
		return $reg[0]; 	
	} #### Final de Trae Pregunta
	
	##### Inicio Trae Cuantos Integrantes Registrados
	public function trae_cuantos_integrantes_registrados($token)
	{
		$sql="SELECT COUNT(A1) AS total FROM ce_integrantes  WHERE A1 = '$token';";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error en 012: Traer Cuantos Integrantes Registrados");
		$reg=mysql_fetch_array($ejecutar); 
		return $reg[0]; 	
	} #### Final de Trae Pregunta	

	public function pag_municipios($dep)
	{
		$sql="SELECT t1.dep, t1.mun_id, t1.mun_nombre 
				FROM par_municipio t1
				WHERE  t1.dep = ".$dep." 
				ORDER BY t1.mun_id ASC ;";
		#echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->municipios[]=$reg;
		}
			return $this->municipios;
	} ### Final 

	

	public function pag_seg_usuarios($cargar)
	{
		if($cargar>0){# Con tal
		$sql="SELECT * FROM `seg_usuarios` 
				INNER JOIN seg_usuarios_rol ON seg_usuarios.usua_rol= seg_usuarios_rol.rol_id 
				WHERE seg_usuarios.usua_cedula= $cargar	;";
			
		}elseif($cargar==0){## Todos
		$sql="SELECT * FROM `seg_usuarios` 
				INNER JOIN seg_usuarios_rol ON seg_usuarios.usua_rol= seg_usuarios_rol.rol_id;";			
		}
		#echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->usuarios[]=$reg;
		}
			return $this->usuarios;
	} ### Final 


## Ver Configuracion
	public function v_configuracion()
	{
		$sql="SELECT * FROM  `par_configuracion` ;";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->configuracion[]=$reg;
		}
		return $this->configuracion;
	}	
	

## Ver Usuarios
	public function v_usuarios($token)
	{
		$sql="SELECT * FROM  `seg_usuarios` where usua_cedula =$token;";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->dato[]=$reg;
		}
		return $this->dato;
	}	

	public function pag_pregunta_A17($opcion)
	{

		$sql="SELECT * FROM  `par_respuestas`
				WHERE rep_pregunta = '$opcion'
				ORDER BY  rep_numero ASC ;";
		//echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->dato[]=$reg;
		}
			return $this->dato;
	} ### Final 
	
	public function pag_pregunta_A18($opcion)
	{

		$sql="SELECT * FROM  `par_respuestas`
				WHERE rep_pregunta = '$opcion'
				ORDER BY  rep_numero ASC ;";
		//echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
			return $this->celda;
	} ### Final 	

	##### Inicio Trae Pregunta
	public function trae_pregunta($token)
	{
		$sql="SELECT pre_nombre FROM par_preguntas  WHERE pre_identificacion = '$token';";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error en 001: Traer Preguntas");
		$reg=mysql_fetch_array($ejecutar); 
		return '<small>'.$token.' '.$reg[0].'</small>'; 	
	} #### Final de Trae Pregunta

	##### Inicio Trae Pregunta Grafica
	public function trae_pregunta_g($token)
	{
		$sql="SELECT pre_nombre FROM par_preguntas  WHERE pre_identificacion = '$token';";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error en 001: Traer Preguntas");
		$reg=mysql_fetch_array($ejecutar); 
		return $token.' '.$reg[0]; 	
	} #### Final de Trae Pregunta Grafica	
	##### Inicio Trae Pregunta
	public function trae_rol($token)
	{
		$sql="SELECT rol_nombre FROM seg_usuarios_rol  WHERE rol_id = '$token';";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error en 017: Traer Nombre Rol");
		$reg=mysql_fetch_array($ejecutar); 
		return $reg[0]; 	
	} #### Final de Trae Pregunta	
	
	## Inicio Trae Pregunta con Tipo
	public function trae_pregunta_tipo($token)
	{
		$sql="SELECT pre_nombre, pre_clase FROM  `par_preguntas`  
						where pre_identificacion = '$token' ;";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->pregunta[]=$reg;
		}
		return $this->pregunta;
	}	
	

	## Inicio Trae Pregunta con Tipo
	public function trae_pregunta_completa($token,$cargar)
	{
		$sql="SELECT pre_nombre, pre_clase FROM `par_preguntas` where pre_identificacion = '$token' ;";
		$result = mysql_query($sql, cTrabajo::con()) or die ("Error 002: Consulta Pregunta");
		$row = mysql_fetch_assoc($result);	echo $token.' '.$row['pre_nombre'];?>        
        <?PHP
		if($row['pre_clase']=="number" or $row['pre_clase']=="text" or $row['pre_clase']=="date"){?>
		 <input type="<?PHP echo $row['pre_clase'];?>" name="<?PHP echo $token; ?>" placeholder="<?PHP echo $token; ?>" class="form-control input-sm" title="<?PHP self::trae_respuestas($token); ?>" value="<?PHP echo $cargar; ?>">	
          <?PHP
		}elseif($row['pre_clase']=="select"){
			$sSQL="select * from par_respuestas WHERE rep_pregunta = '$token' OR rep_pregunta ='Z' ORDER BY `rep_numero` ASC";
			$result=mysql_query($sSQL,cTrabajo::con());
		
			echo '<select name="'.$token.'" title="Debe seleccionar" class="form-control input-sm">';				$c=0;
			while ($row=mysql_fetch_assoc($result))
			{
				if(($cargar==0) && $c==0){ 			$c=1;
				echo '<option title="'.$row["rep_nombre"].'" value="'.$row["rep_numero"].'" selected>'.$row["rep_numero"].' - '.$row["rep_nombre"].'</option>';
				}else{
					if($cargar==$row["rep_numero"]){
					echo '<option title="'.$row["rep_nombre"].'" value="'.$row["rep_numero"].'" selected>'.$row["rep_numero"].' - '.$row["rep_nombre"].'</option>';
					}else{
					echo '<option title="'.$row["rep_nombre"].'" value="'.$row["rep_numero"].'">'.$row["rep_numero"].' - '.$row["rep_nombre"].'</option>';
					}
				}
				
			 }
			 echo '</select>';	

			}## Cierre SI
		
	}

	## Inicio Trae Pregunta con Tipo
	public function trae_pregunta_respuesta($token,$cargar)
	{ 
		$sql="SELECT pre_nombre, pre_clase FROM `par_preguntas` where pre_identificacion = '$token' ;";
		$result = mysql_query($sql, cTrabajo::con()) or die ("Error 003: Consulta Pregunta");
		$row = mysql_fetch_assoc($result);	
        
		if($row['pre_clase']=="number" or $row['pre_clase']=="text" or $row['pre_clase']=="date"){?>
		 <input type="<?PHP echo $row['pre_clase'];?>" name="<?PHP echo $token; ?>" id="<?PHP echo $token; ?>" placeholder="<?PHP echo $token; ?>" class="form-control input-sm" title="<?PHP self::trae_respuestas($token); ?>" value="<?PHP echo $cargar; ?>">	
          <?PHP
		}elseif($row['pre_clase']=="select"){
			$sSQL="select * from par_respuestas WHERE rep_pregunta = '$token' OR rep_pregunta ='Z' ORDER BY `rep_numero` ASC";
			$result=mysql_query($sSQL,cTrabajo::con());
		
			echo '<select name="'.$token.'" id="'.$token.'" title="Debe seleccionar" class="form-control input-sm">';				$c=0;
			while ($row=mysql_fetch_assoc($result))
			{
				if(($cargar==0) && $c==0){ 			$c=1;
				echo '<option title="'.$row["rep_nombre"].'" value="'.$row["rep_numero"].'" selected>'.$row["rep_numero"].' - '.$row["rep_nombre"].'</option>';
				}else{
					if($cargar==$row["rep_numero"]){
					echo '<option title="'.$row["rep_nombre"].'" value="'.$row["rep_numero"].'" selected>'.$row["rep_numero"].' - '.$row["rep_nombre"].'</option>';
					}else{
					echo '<option title="'.$row["rep_nombre"].'" value="'.$row["rep_numero"].'">'.$row["rep_numero"].' - '.$row["rep_nombre"].'</option>';
					}
				}
				
			 }
			 echo '</select>';	
		}## Cierre SI
		
	}
	
	## Inicio Trae Opciones de Respuesta
	public function trae_respuestas($token)
	{
		$sql="SELECT rep_numero, rep_nombre FROM `par_respuestas` where rep_pregunta = '$token' ;";
		$result = mysql_query($sql, cTrabajo::con()) or die ("Error 004: Consulta Respuestas Pregunta");
		
		if(mysql_num_rows ($result) != 0 ){
			while($row = mysql_fetch_assoc($result)){
				echo $row['rep_numero'].' -'.$row['rep_nombre'].' ';
				}
		}else{
			echo 'Seleccione ó Ingrese dato';	
		}
		?> 
        
        
        
		<?PHP
	}
	
		
	
	##### Inicio Trae Nombre Departamento
	public function trae_departamento($token)
	{
		$sql="SELECT dep_nombre FROM par_departamentos  WHERE dep_id = $token;";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error en Departamento");
		$reg=mysql_fetch_array($ejecutar); 
		return $reg[0]; 	
	} #### Final de Trae Nombre Departamento

	##### Inicio Trae Nombre Municipio
	public function trae_municipio($token,$dep)
	{
		$sql="SELECT mun_nombre FROM par_municipio  WHERE dep=$dep and mun_id = $token ;";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error en Municipio");
		$reg=mysql_fetch_array($ejecutar); 
		return $reg[0]; 	
	} #### Final de Trae Nombre Municipio

	##### Inicio Trae Respuestas Preguntas
	public function trae_respuesta($preg,$num)
	{
		$sql="SELECT rep_nombre FROM par_respuestas  WHERE rep_pregunta='$preg' and rep_numero = '$num' ;";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 03: Traer Respuestas");
		$reg=mysql_fetch_array($ejecutar); 
		return $reg[0]; 	
	} #### Final de Trae Nombre Municipio

	public function total_votos_candidato($token)
	{
		$sql="SELECT SUM(vot_votos) as total FROM `vot_votacion` WHERE vot_candidato = ".$token."  ";			

		#echo "$sql<br>"; #final filtro
		$res=mysql_query($sql,cTrabajo::con());
		if ($reg=mysql_fetch_array($res))
		{
			$total=$reg["total"];
		}
			return $total;
	} ### Final Filtro de Contar Sumar Procesos

## Cargar usuario Existente	
	public function c_usuario_ced_clave($user, $password)
	{
 	$sql="select * from seg_usuarios where usua_cedula=$user and usua_clave=MD5('$password')";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
			return $this->celda;
	}	

	public function gra_menu_general(){?>

        <nav class="navbar navbar-default">
          <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display navbar-default navbar-header navbar-brand -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="index.php?mod=54&opcion=13">CEM</a>
            </div>
        
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li class="active"><a href="index.php?mod=54&opcion=13">
                <span class="glyphicon glyphicon-home"></span> Inicio <span class="sr-only">(current)</span></a></li>
                <li class="dropdown">
                  <a href="CargarDatos.php?mod=50&opcion=0" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Carga Datos <span class="caret"></span></a>
                  <ul class="dropdown-menu">              
                    <li><a href="CargarDatos.php?mod=50&opcion=2&g=1">Afrocolombiano</a></li>
                    <li><a href="CargarDatos.php?mod=50&opcion=2&g=2">Indigena</a></li>                      
                  </ul>
                </li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Consultar Datos <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="Reportes.php?mod=52&opcion=1">
                    <span class="glyphicon glyphicon-th-list"></span>  Reporte Fichas</a></li>  
                    <li><a href="Reportes.php?mod=52&opcion=2">
                    	<span class="glyphicon glyphicon-th-list"></span> Reporte Integrantes</a></li>
                    <li><a href="Reportes.php?mod=53&opcion=9">
                    <span class="glyphicon glyphicon-sort-by-alphabet"></span> Filtrar Datos Fichas</a></li>
                    <li><a href="Reportes.php?mod=53&opcion=4">
                    <span class="glyphicon glyphicon-sort-by-alphabet"></span> Filtrar Datos Integrantes</a></li>
                    <li><a href="Reportes.php?mod=52&opcion=10">
                    	<span class="glyphicon glyphicon-stats"></span> Estadisticas A</a></li>   
                    <li><a href="Reportes.php?mod=52&opcion=11">
                    	<span class="glyphicon glyphicon-stats"></span> Estadisticas B</a></li>   
                    <li><a href="Reportes.php?mod=52&opcion=12">
                    	<span class="glyphicon glyphicon-stats"></span> Estadisticas C</a></li>   
                    <li><a href="Reportes.php?mod=52&opcion=13">
                    	<span class="glyphicon glyphicon-stats"></span> Estadisticas D</a></li>
                    <li><a href="Reportes.php?mod=52&opcion=3">
                    	<span class="glyphicon glyphicon-sort-by-order"></span> Indicador Etáreo</a></li>
                    <li><a href="Reportes.php?mod=53&opcion=5">Seleccionar Grupo Poblacional</a></li>                
                  </ul>
                </li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Opciones <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="CentroControl.php?mod=54&opcion=15">
                    	<span class="glyphicon glyphicon-cog"></span> Configuración Básica</a></li>
                    <li role="separator" class="divider"></li>  
                    <li><a href="CentroControl.php?mod=54&opcion=1" title="Reporte Usuarios">Reporte Usuarios</a></li>
                    <li><a href="CentroControl.php?mod=54&opcion=2" title="Registrar Usuarios">Registrar Usuarios</a></li>
                    <li><a href="CentroControl.php?mod=54&opcion=6" title="Seguimiento Usuarios">Seguimiento Usuarios</a></li>
                                        
                    <li role="separator" class="divider"></li>
                    <li><a href="backup.php">
                    	<span class="glyphicon glyphicon-save-file"></span> Generar Backup</a></li> 
                    <li><a href="excel.php?mod=54&opcion=9&token=0&c=0">
                    	<span class="glyphicon glyphicon-save-file"></span> Exportar Excel</a></li>   
                    <li><a href="files/afrocolombiano.pdf">
                    	<span class="glyphicon glyphicon-save-file"></span> Ficha Técnica Afrocolombiano</a></li>  
                    <li><a href="files/indigena.pdf">
                    	<span class="glyphicon glyphicon-save-file"></span> Ficha Técnica Indigena</a></li>
                  </ul>
                </li>
              </ul>
<!--              <form class="navbar-form navbar-left" role="search">
                <div class="form-group">
                  <input type="text" class="form-control" placeholder="Buscar">
                </div>
                <button type="submit" class="btn btn-primary">Buscar</button>
              </form>-->
              <ul class="nav navbar-nav navbar-right">
                
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> Usuario <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="CentroControl.php?mod=54&opcion=4&token=<?PHP echo $_SESSION['user_cedula'];?>">Perfil</a></li>
                    <li><a href="CentroControl.php?mod=54&opcion=5&token=<?PHP echo $_SESSION['user_cedula'];?>">Cambiar Clave</a></li>
                                   
                  </ul>
                </li>
                <li><a href="index.php?mod=54&opcion=14"><span class="glyphicon glyphicon-log-in"></span> Salir</a></li>
              </ul>
            </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
        </nav>    

<?PHP		
	}

public function gra_pie_pagina(){?>
<footer>
	<div class="container text-center">
		<h5>Usuario: <?PHP echo $_SESSION['user_nombres'];?></h5>
		<h5>Alcaldía Municipal de Saravena - Oficina Asuntos Étnicos - Carlos Martinez</h5>
    </div>    
</footer>
<?PHP		
	}
	
### Realizar Contar Registros
	public function Contar($p,$s)
	{	 
		$n="SELECT Count( * ) FROM ce_nucleo ";
		$i="SELECT Count( * ) FROM ce_integrantes ";
		$j="INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 ";
		if(isset($_SESSION['c']) and $_SESSION['c']=='A17'){$c="A17";
			}elseif($_SESSION['c']=='A18'){$c="A18";
			}elseif($_SESSION['c']=='GRUPO'){$c="GRUPO";
			}
			
		if($p==1){	
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql ="$n WHERE $c = ".$_SESSION['user_grupo']." ;";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n ;"; }			 	
		
		}elseif ($p==2) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE ce_nucleo.$c = ".$_SESSION['user_grupo'].";";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i ;"; }					
		
		}elseif ($p==3) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND ESTADO=1;";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE ESTADO=1;"; }	
		
		}elseif ($p==4) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND ESTADO=2;";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE ESTADO=2;"; }			
		
		}elseif ($p==5) {
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A19='$s' AND ESTADO=1;";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A19='$s' AND ESTADO=1;"; }			
				
		}elseif ($p==6) {  $sql =" ";
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A19='$s' AND ESTADO=2;";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A19='$s' AND ESTADO=2;"; }			

		}elseif ($p==7) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A4='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A4='$s';"; }	
		}elseif ($p==8) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A8='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A8='$s';"; }
			
		}elseif ($p==9) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A9='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A9='$s';"; }
		
		}elseif ($p==10) {
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A10='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A10='$s';"; }		
		
		}elseif ($p==11) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A11='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A11='$s';"; }
				
		}elseif ($p==12) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A12='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A12='$s';"; }
				
		}elseif ($p==13) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A13='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A13='$s';"; }
				
		}elseif ($p==14) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A14='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A14='$s';"; }
		
		}elseif ($p==15) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A15='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A15='$s';"; }		
		
		}elseif ($p==16) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A16='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A16='$s';"; }
		
		}elseif ($p==17) {
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A17='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A17='$s';"; }
		
		}elseif ($p==18) {  $sql =" $n WHERE A18='$s';";
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND A18='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE A18='$s';"; }		
		
		}elseif ($p==24) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B1='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B1='$s';"; }
					
		}elseif ($p==25) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B2='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B2='$s';"; }

		}elseif ($p==26) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B3='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B3='$s';"; }

		}elseif ($p==27) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B4='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B4='$s';"; }

		}elseif ($p==28) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B5='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B5='$s';"; }			

		}elseif ($p==29) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B6='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B6='$s';"; }
								
		}elseif ($p==30) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B7='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B7='$s';"; }

		}elseif ($p==31) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B8='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B8='$s';"; }
								
		}elseif ($p==32) {
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B9='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B9='$s';"; }
					
		}elseif ($p==33) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B10='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B10='$s';"; }
					
		}elseif ($p==34) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B11='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B11='$s';"; }
					
		}elseif ($p==35) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B12='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B12='$s';"; }
					
		}elseif ($p==37) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B14='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B14='$s';"; }			

		}elseif ($p==38) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B15='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B15='$s';"; }
					
		}elseif ($p==39) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B16='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B16='$s';"; }
					
		}elseif ($p==40) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B17='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B17='$s';"; }
					
		}elseif ($p==41) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B18='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B18='$s';"; }			
		
		}elseif ($p==42) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B19='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B19='$s';"; }
					
		}elseif ($p==43) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B20='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B20='$s';"; }
					
		}elseif ($p==44) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B21='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B21='$s';"; }
					
		}elseif ($p==45) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B22='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B22='$s';"; }			
		
		}elseif ($p==46) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B23='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B23='$s';"; }
					
		}elseif ($p==47) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B24='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B24='$s';"; }
					
		}elseif ($p==48) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B25='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B25='$s';"; }
					
		}elseif ($p==49) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND B26='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE B26='$s';"; }			
		
		}elseif ($p==50) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C1='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C1='$s';"; }			

		}elseif ($p==51) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C2='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C2='$s';"; }			

		}elseif ($p==52) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C3='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C3='$s';"; }			

		}elseif ($p==53) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C4='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C4='$s';"; }			

		}elseif ($p==54) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C5='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C5='$s';"; }			

		}elseif ($p==55) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C6='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C6='$s';"; }			

		}elseif ($p==56) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C7='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C7='$s';"; }			

		}elseif ($p==57) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C8='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C8='$s';"; }			

		}elseif ($p==58) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C9='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C9='$s';"; }			

		}elseif ($p==59) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C10='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C10='$s';"; }			

		}elseif ($p==60) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C11='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C11='$s';"; }			

		}elseif ($p==61) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C12='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C12='$s';"; }			

		}elseif ($p==62) {  ##Uso PriNombre			
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $n WHERE $c = ".$_SESSION['user_grupo']." AND C13='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $n WHERE C13='$s';"; }			

		}elseif ($p==66) { #Nombre Ancestral
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D5='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D5='$s';"; }			
			
		}elseif ($p==67) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D6='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D6='$s';"; }			
		
		}elseif ($p==68) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D7='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D7='$s';"; }			
		
		}elseif ($p==69) {  $sql =" $i WHERE D8='$s';";
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D8='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D8='$s';"; }			

		}elseif ($p==70) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D9='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D9='$s';"; }			
		
		}elseif ($p==71) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D10='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D10='$s';"; }			
		
		}elseif ($p==72) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D11='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D11='$s';"; }			

		}elseif ($p==73) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D12='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D12='$s';"; }			

		}elseif ($p==74) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D13='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D13='$s';"; }			

		}elseif ($p==75) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D14='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D14='$s';"; }			

		}elseif ($p==76) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D15='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D15='$s';"; }			

		}elseif ($p==77) {  	
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D16='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D16='$s';"; }					
		
		}elseif ($p==78) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D17='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D17='$s';"; }					

		}elseif ($p==79) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D18='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D18='$s';"; }					

		}elseif ($p==80) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D19='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D19='$s';"; }					

		}elseif ($p==81) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D20='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D20='$s';"; }					

		}elseif ($p==82) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D21='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D21='$s';"; }					

		}elseif ($p==83) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D22='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D22='$s';"; }					

		}elseif ($p==84) {
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D23='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D23='$s';"; }					

		}elseif ($p==85) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D24='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D24='$s';"; }					

		}elseif ($p==86) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D25='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D25='$s';"; }					

		}elseif ($p==87) { 	
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D26='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D26='$s';"; }					

		}elseif ($p==88) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D27='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D27='$s';"; }					

		}elseif ($p==89) { 
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D28='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D28='$s';"; }					

		}elseif ($p==90) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D29='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D29='$s';"; }					

		}elseif ($p==91) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D30='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D30='$s';"; }					

		}elseif ($p==92) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D31='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D31='$s';"; }					

		}elseif ($p==93) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D32='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D32='$s';"; }					

		}elseif ($p==94) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D33='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D33='$s';"; }					

		}elseif ($p==95) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D34='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D34='$s';"; }					

		}elseif ($p==96) {  
			if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql =" $i $j WHERE $c = ".$_SESSION['user_grupo']." AND D35='$s';";	 
			}elseif($_SESSION['user_rol']<=2){ $sql =" $i WHERE D35='$s';"; }					
		
		}elseif ($p==99) {  $sql =" $n WHERE GRUPO='$s';";
		}elseif ($p==100) { $sql =" $n WHERE A17='$s';"; 
		}elseif ($p==101) { $sql =" $n WHERE A18='$s';"; 		
		
		}
		#echo $sql;		
		$rs = mysql_query($sql,cTrabajo::con()) or die ("Error 05: Contar Registros");
		$reg=mysql_fetch_array($rs);
		echo number_format($reg[0],0);

	}
		
######  Inicio  Usuarios
	public function pag_usuarios()
	{

		$sql="SELECT * FROM seg_usuarios ORDER BY usua_cedula DESC;";
		#echo "$sql<br>";
		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
			return $this->celda;
	} ### Final Usuarios	
	
## Edicion de Clave
	public function e_clave($token)
	{ 
		$sql="update seg_usuarios "
			." set "
			." usua_clave=md5('".substr($token,-4)."')"
			." where "
			." usua_cedula=$token ";
		$res=mysql_query($sql,cTrabajo::con());
		
	}

public function IngNov($ficha,$token,$traza,$apoyo,$user_nombres){
## Ingreso de la Novedad
$sql = "insert into seg_novedades values (Null, '".$ficha."', '".$token."', '".$apoyo."', '".$traza."', '$user_nombres', Now())";
$rs = mysql_query($sql,cTrabajo::con()) or die ("Error 010: Registro Novedad");			

}##### Ingreso de la Novedad

###### Carga Paginado Novedades
	public function pag_novedades_ficha($ficha)
	{
		$sql ="select * from seg_novedades where seg_ficha = '".$ficha."' order by seg_fh_evento DESC ";		

		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_array($res))
		{
			$this->novedades[]=$reg;
		}
			return $this->novedades;
	} ### Final Paginado Novedades

###### Carga Paginado Novedades
	public function pag_novedades_usuario($cargar)
	{
		$sql ="select * from seg_novedades where seg_id_ap = '".$cargar."' order by seg_fh_evento DESC ";		

		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_array($res))
		{
			$this->novedades[]=$reg;
		}
			return $this->novedades;
	} ### Final Paginado Novedades
## Ver Usuario
	public function v_usuario($token)
	{
		$sql="SELECT * FROM  `seg_usuarios` where usua_cedula =$token;";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
		return $this->celda;
	}	
	
## Ver Integrante
	public function v_integrante($token)
	{
		$sql="SELECT * FROM  `ce_integrantes` where D7 =$token;";
		$res=mysql_query($sql, cTrabajo::con());
		while ($reg=mysql_fetch_assoc($res))
		{
			$this->celda[]=$reg;
		}
		return $this->celda;
	}		

###### Graficar Datos de la variable.
	public function grafica_variable_tabla_nucleo($pregunta)
	{
	if(isset($_SESSION['c']) and $_SESSION['c']=='A17'){$c="A17";
			}elseif($_SESSION['c']=='A18'){$c="A18";
			}elseif($_SESSION['c']=='GRUPO'){$c="GRUPO";
			}	
	
	if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	#$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE $c = ".$_SESSION['user_grupo']." GROUP BY `$pregunta`;";
				$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_nucleo` WHERE $c = ".$_SESSION['user_grupo']." GROUP BY `$pregunta`;";	 
		}elseif($_SESSION['user_rol']<=2){ 
			#$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 GROUP BY `$pregunta` ;";
			$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_nucleo` GROUP BY `$pregunta` ;"; 
		}		


	$rs = mysql_query($sql) or die ("Error de consulta en la selección");
	$totalrs_a= mysql_num_rows ($rs); 
	$result = mysql_query($sql);
?>
<table class="table table-condensed table-responsive text-center">
  <thead>
  <tr>     
    <th class="text-left">Respuesta</th>
    <th class="text-center">Cuantos</th>    
  </tr>
  </thead>
<?PHP
if($totalrs_a != 0 ){

while ($row = mysql_fetch_assoc($result)){	?>

  <tr>     
    <td class="text-left"><?PHP echo $row[$pregunta].' - '.self::trae_respuesta($pregunta, $row[$pregunta]);?></td>
    <td class="text-center"><?php echo $row['TOTAL'];?></td>    
  </tr>

<?php }

}else{ ?>
	   <tr>
       <td colspan=2 align="center">Sin Datos</td>	   	   
       </tr>
<?php } ?>
</TABLE>
<?php

	}

###### Graficar Datos de la variable.
	public function grafica_variable_tabla_integrantes($pregunta)
	{
	if(isset($_SESSION['c']) and $_SESSION['c']=='A17'){$c="A17";
			}elseif($_SESSION['c']=='A18'){$c="A18";
			}elseif($_SESSION['c']=='GRUPO'){$c="GRUPO";
			}	
	
	if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE $c = ".$_SESSION['user_grupo']." GROUP BY `$pregunta`;";
				#$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_nucleo` WHERE $c = ".$_SESSION['user_grupo']." GROUP BY `$pregunta`;";	 
		}elseif($_SESSION['user_rol']<=2){ 
			$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 GROUP BY `$pregunta` ;";
			#$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_nucleo` GROUP BY `$pregunta` ;"; 
		}		


	$rs = mysql_query($sql) or die ("Error de consulta en la selección");
	$totalrs_a= mysql_num_rows ($rs); 
	$result = mysql_query($sql);
?>
<table class="table table-condensed table-responsive text-center">
  <thead>
  <tr>     
    <th class="text-left">Respuesta</th>
    <th class="text-center">Cuantos</th>    
  </tr>
  </thead>
<?PHP
if($totalrs_a != 0 ){

while ($row = mysql_fetch_assoc($result)){	?>

  <tr>     
    <td class="text-left"><?PHP echo $row[$pregunta].' - '.self::trae_respuesta($pregunta, $row[$pregunta]);?></td>
    <td class="text-center"><?php echo $row['TOTAL'];?></td>    
  </tr>

<?php }

}else{ ?>
	   <tr>
       <td colspan=2 align="center">Sin Datos</td>	   	   
       </tr>
<?php } ?>
</TABLE>
<?php

	}


public function grafica_variable($pregunta,$tipografico)
{?>
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title"><?PHP echo self::trae_pregunta_g($pregunta);  ?></h3>
                 </div>
            <div class="panel-body">
<?PHP
	if(isset($_SESSION['c']) and $_SESSION['c']=='A17'){$c="A17";
			}elseif($_SESSION['c']=='A18'){$c="A18";
			}elseif($_SESSION['c']=='GRUPO'){$c="GRUPO";
			}	
	
	if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	#$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE $c = ".$_SESSION['user_grupo']." GROUP BY `$pregunta`;";
				$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_nucleo` WHERE $c = ".$_SESSION['user_grupo']." GROUP BY `$pregunta`;";	 
		}elseif($_SESSION['user_rol']<=2){ 
			#$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 GROUP BY `$pregunta` ;";
			$sql="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_nucleo` GROUP BY `$pregunta`;";
		}		
$result = mysql_query($sql,self::con());
$cuantos= mysql_num_rows($result);
	?>
    <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['<?PHP echo self::trae_pregunta_g($pregunta); ?>', 'Respuesta'],
				  <?PHP while ($row = mysql_fetch_assoc($result)){?>  
                  ['<?PHP echo $row[$pregunta].' - '.self::trae_respuesta($pregunta, $row[$pregunta]);?>', <?PHP echo $row['TOTAL']; ?>],
                  
				<?PHP }?>
				 
                ]);
        		
				<?PHP if($tipografico==1){?>
				
                var options = {
                  title: 'Pregunta: <?PHP echo $pregunta; ?>',
                  is3D: true,
                };
				var chart = new google.visualization.PieChart(document.getElementById('piechart_<?PHP echo $tipografico.$pregunta; ?>'));
                chart.draw(data, options);				
				<?PHP }?>
			    <?PHP if($tipografico==2){?>
			  
			  var options = {
				title: "Pregunta: <?PHP echo $pregunta; ?>",
				bar: {groupWidth: '95%'},
				legend: 'none',
			  };				
					
			  var chart_div = document.getElementById('piechart_<?PHP echo $tipografico.$pregunta; ?>');
			  var chart = new google.visualization.ColumnChart(chart_div);
		
			  // Wait for the chart to finish drawing before calling the getImageURI() method.
			  google.visualization.events.addListener(chart, 'ready', function () {
				chart_div.innerHTML = '<img src="' + chart.getImageURI() + '">';
				console.log(chart_div.innerHTML);
			  });
		
			  chart.draw(data, options);        
              
			  <?PHP }?> 
              }
            </script>
    

 
                <div id="piechart_<?PHP echo $tipografico.$pregunta; ?>" style="width:auto; height:400px;"></div>                                       
                </div>
             <?PHP $dato= self::grafica_variable_tabla_nucleo($pregunta);?>   
                
      		</div>
      </div>     
	
    
    

<?PHP }


public function grafica_variable_integrante($pregunta,$tipografico)
{?>
      <div class="row">
            <div class="panel panel-success">
                 <div class="panel-heading">
                  <h3 class="panel-title"><?PHP echo self::trae_pregunta_g($pregunta);  ?></h3>
                 </div>
            <div class="panel-body">
<?PHP
	if(isset($_SESSION['c']) and $_SESSION['c']=='A17'){$c="A17";
			}elseif($_SESSION['c']=='A18'){$c="A18";
			}elseif($_SESSION['c']=='GRUPO'){$c="GRUPO";
			}	
	
	if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE $c = ".$_SESSION['user_grupo']." GROUP BY `$pregunta`;";
				
		}elseif($_SESSION['user_rol']<=2){ 
			$sql ="SELECT $pregunta, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 GROUP BY `$pregunta` ;";
			
		}		
$result = mysql_query($sql,self::con());
$cuantos= mysql_num_rows($result);
	?>
    <script type="text/javascript">
              google.charts.load("current", {packages:["corechart"]});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['<?PHP echo self::trae_pregunta_g($pregunta); ?>', 'Respuesta'],
				  <?PHP while ($row = mysql_fetch_assoc($result)){?>  
                  ['<?PHP echo $row[$pregunta].' - '.self::trae_respuesta($pregunta, $row[$pregunta]);?>', <?PHP echo $row['TOTAL']; ?>],
                  
				<?PHP }?>
				 
                ]);
        		
				<?PHP if($tipografico==1){?>
				
                var options = {
                  title: 'Pregunta: <?PHP echo $pregunta; ?>',
                  is3D: true,
                };
				var chart = new google.visualization.PieChart(document.getElementById('piechart_<?PHP echo $tipografico.$pregunta; ?>'));
                chart.draw(data, options);				
				<?PHP }?>
			    <?PHP if($tipografico==2){?>
			  
			  var options = {
				title: "Pregunta: <?PHP echo $pregunta; ?>",
				bar: {groupWidth: '95%'},
				legend: 'none',
			  };				
					
			  var chart_div = document.getElementById('piechart_<?PHP echo $tipografico.$pregunta; ?>');
			  var chart = new google.visualization.ColumnChart(chart_div);
		
			  // Wait for the chart to finish drawing before calling the getImageURI() method.
			  google.visualization.events.addListener(chart, 'ready', function () {
				chart_div.innerHTML = '<img src="' + chart.getImageURI() + '">';
				console.log(chart_div.innerHTML);
			  });
		
			  chart.draw(data, options);        
              
			  <?PHP }?> 
              }
            </script>
    

 
                <div id="piechart_<?PHP echo $tipografico.$pregunta; ?>" style="width:auto; height:400px;"></div>                                       
                </div>
             <?PHP $dato= self::grafica_variable_tabla_integrantes($pregunta);?>   
                
      		</div>
      </div>     
	
    
    

<?PHP }


###### Edad Hombre
	public function calcular_edad_hombre()
	{
	if(isset($_SESSION['c']) and $_SESSION['c']=='A17'){$c="A17";
			}elseif($_SESSION['c']=='A18'){$c="A18";
			}elseif($_SESSION['c']=='GRUPO'){$c="GRUPO";
			}	
	
	if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql ="SELECT YEAR(CURDATE())-YEAR(D11) AS `EDAD_ACTUAL`, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE $c = ".$_SESSION['user_grupo']." AND D9 =1 GROUP BY `EDAD_ACTUAL` ;";	 
		}elseif($_SESSION['user_rol']<=2){ 
			$sql ="SELECT YEAR(CURDATE())-YEAR(D11) AS `EDAD_ACTUAL`, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE D9 =1 GROUP BY `EDAD_ACTUAL` ;"; 
		}
			
				
		#$sql ="SELECT YEAR(CURDATE())-YEAR(D11) AS `EDAD_ACTUAL`, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE D9 =1 AND GRUPO =$g GROUP BY `EDAD_ACTUAL` ;";		

		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_array($res))
		{
			$this->dato[]=$reg;
		}
			return $this->dato;
	} ### Final Paginado Novedades
	
###### Edad Hombre
	public function calcular_edad_mujer()
	{

	if(isset($_SESSION['c']) and $_SESSION['c']=='A17'){$c="A17";
			}elseif($_SESSION['c']=='A18'){$c="A18";
			}elseif($_SESSION['c']=='GRUPO'){$c="GRUPO";
			}	
	
	if(($_SESSION['user_rol']>2) or ($_SESSION['user_temporal']==1)){ 
			 	$sql ="SELECT YEAR(CURDATE())-YEAR(D11) AS `EDAD_ACTUAL`, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE $c = ".$_SESSION['user_grupo']." AND D9 =2 GROUP BY `EDAD_ACTUAL` ;";	 
		}elseif($_SESSION['user_rol']<=2){ 
			$sql ="SELECT YEAR(CURDATE())-YEAR(D11) AS `EDAD_ACTUAL`, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE D9 =2 GROUP BY `EDAD_ACTUAL` ;"; 
		}		
		
		#$sql ="SELECT YEAR(CURDATE())-YEAR(D11) AS `EDAD_ACTUAL`, COUNT(*) as TOTAL FROM `ce_integrantes` INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 WHERE D9 =2 AND GRUPO =$g GROUP BY `EDAD_ACTUAL` ;";		

		$res=mysql_query($sql,cTrabajo::con());
		while ($reg=mysql_fetch_array($res))
		{
			$this->celda[]=$reg;
		}
			return $this->celda;
	} ### Final Paginado Novedades
	
		
	
}### FINAL  CLASE 
