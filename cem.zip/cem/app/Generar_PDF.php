<?php
date_default_timezone_set('America/Bogota');
setlocale(LC_ALL, 'Spanish_Spain');
ini_set("memory_limit","20M");

require_once('./tcpdf/config/lang/spa.php');
require_once('./tcpdf/tcpdf.php');


// Extend the TCPDF class to create custom Header and Footer
class MYPDF extends TCPDF {

    //Page header
    public function Header() {
       
        $image_file = K_PATH_IMAGES.'pdf_header.png';
        $this->Image($image_file, 10, 5, 160, 20, 'png', '', 'T', false, 300, 'C', false, false, 0, false, false, false);
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
		
		$this->setFooterMargin(10);

       $this->Cell(0, 10, 'CEM / Página '.$this->getAliasNumPage().' / '.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
		$image_file = K_PATH_IMAGES.'pdf_footer.png';
        $this->Image($image_file, 10, 270, 160, 20, 'png', '', 'T', false, 300, 'C', false, false, 0, false, false, false);		

    }
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Informacion del ARCHIVO
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Asuntos Etnicos');
$pdf->SetTitle('Generado por Caracterización Étnica Municipal');
$pdf->SetSubject('Gestion Asuntos Etnicos Alcaldia de Saravena');
$pdf->SetKeywords('PDF, Saravena, Objeto, Carlos Martinez, Caracterizacion');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set font
$pdf->SetFont('Helvetica', '', 12);

// add a page
$pdf->AddPage();

// Titulo Documento
$pdf->SetFont('Helvetica', '', 12);
$pdf->Write(0, 'Resumen de Ficha Técnica de Caracterización Étnica Municipal', '', 0, 'C', true, 0, false, false, 0);

## Buscamos contenido en BD
// Datos desde la Clase ver
include("class/class.php");	

$V_Clase= new cTrabajo();

if($_GET['mod'] ==51 and $_GET['opcion'] ==5){## Descargar fICHA Individual
##Muestra Pdf CDP	
$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_id($_GET['id']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Ficha Familia Individual PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['id']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad
}elseif($_GET['mod'] ==51 and $_GET['opcion'] ==6){ ## Descargar fICHA Familia

$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_ficha($_GET['token']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Ficha Familia PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['token']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad

}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==8){ ## Certificado de Registro
$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_id($_GET['id']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Certificado Registro Censo PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['id']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad

}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==10){ ## Certificado de Libreta Militar
$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_id($_GET['id']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Certificado Libreta Militar PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['id']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad

}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==11){ ## Certificado de Afiliación Salud
$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_id($_GET['id']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Certificado Afiliación Salud PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['id']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad

}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==12){ ## Certificado de Duplicado DOcumento
$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_id($_GET['id']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Certificado Duplicado Documento PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['id']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==13){ ## Certificado Laboral
$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_id($_GET['id']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Certificado Laboral PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['id']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad

}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==14){ ## Certificado de Servicios de Salud
$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_id($_GET['id']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Certificado Servicios de Salud PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['id']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad

}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==15){ ## Certificado de Matrimonio ó Union Civil
$dato=$V_Clase->v_ficha($_GET['token']);
$dain=$V_Clase->v_integrantes_id($_GET['id']);	
	if($dato[0]['GRUPO']==2){ $GRUPO='INDIGENA'; }elseif($dato[0]['GRUPO']==1){ $GRUPO='AFROCOLOMBIANO'; } 
	$traza="Generado Certificado Matrimonio ó Union Civil PDF";
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_GET['token']); $token=base64_decode($_GET['id']);  $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad


}##Final Muestra Pdf 




### PRIMERA SALIDA HTML
// set font
$pdf->SetFont('Helvetica', '', 12);

##Muestra Pdf Ficha Individual
if($_GET['mod'] ==51 and $_GET['opcion'] ==5){

$html = '
<table border="1" cellspacing="1" cellpadding="6" width="100%">
  <tr>

    <td colspan="4" align="center">
		ENCUESTA: CARACTERIZACION DEMOGRAFICA Y SOCIOECONOMICA DE LA POBLACION 
		'.$GRUPO.' EN EL MUNICIPIO DE SARAVENA DEPARTAMENTO DE ARAUCA    
    </td>
  </tr>
  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">A. DATOS IDENTIFICACIÓN</td>
  </tr> 
  <tr>
    <td width="25%" class="h3">'.$V_Clase->trae_pregunta("A1").'</td>
    <td width="25%" class="h3 text-center">'.$dato[0]['A1'].'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("A4").' : '.$dato[0]['A4'].'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("A5").' : '.$dato[0]['A5'].'</td>
  </tr>
  <tr>
    <td>'.$V_Clase->trae_pregunta("A2").' : '.$dato[0]['A2'].' / '.$V_Clase->trae_departamento($dato[0]['A2']).'</td>
    <td>'.$V_Clase->trae_pregunta("A3").' : '.$dato[0]['A3'].' / '.$V_Clase->trae_municipio($dato[0]['A3'],$dato[0]['A2']).'</td>
 	<td>'.$V_Clase->trae_pregunta("A6").' : '.$dato[0]['A6'].'</td>
    <td>'.$V_Clase->trae_pregunta("A7").' : '.$dato[0]['A7'].'</td>
  </tr>

  <tr>
    <td colspan="4" class="text-left">Gobierno '.$GRUPO.' >     	
    	<b>A8:</b> '.$dato[0]['A8'].' <b>A9:</b> '.$dato[0]['A9'].' <b>A10:</b> '.$dato[0]['A10'].' 
    	<b>A11:</b> '.$dato[0]['A11'].' <b>A12:</b> '.$dato[0]['A12'].' <b>A13:</b> '.$dato[0]['A13'].' 
        <b>A14:</b> '.$dato[0]['A14'].' <b>A15:</b> '.$dato[0]['A15'].' <b>A16:</b> '.$dato[0]['A16'].' 
        <b>A17:</b> '.$dato[0]['A17'].' <b>A18:</b> '.$dato[0]['A18'].'</td>
  </tr>   
  <tr>
    <td colspan="4" class="text-left">Control de Trabajo >
    	<b>A19:</b> '.$dato[0]['A19'].' <b>A20:</b> '.$dato[0]['A20'].' <b>A21:</b> '. $dato[0]['A21'].' 
        <b>A22:</b> '.$dato[0]['A22'].' <b>A23:</b> '.$dato[0]['A23'].'
 </td>
  </tr>

  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">B. DATOS VIVIENDA</td>
  </tr> 

  <tr>
    <td colspan="2">Propiedad y Estado >
    <b>B1:</b>'.$dato[0]['B1'].' <b>B2:</b>'.$dato[0]['B2'].' <b>B3:</b>'.$dato[0]['B3'].'<b>B4:</b>'.$dato[0]['B4'].'
    <b>B5:</b>'.$dato[0]['B5'].' <b>B6:</b>'.$dato[0]['B6'].' <b>B7:</b>'.$dato[0]['B7'].'<b>B8:</b>'.$dato[0]['B8'].'
    </td>
    <td colspan="2">Servicios Publicos >
	<b>B8:</b>'.$dato[0]['B8'].' <b>B9:</b>'.$dato[0]['B9'].' B10:'.$dato[0]['B10'].' <b>B11:</b>'.$dato[0]['B11'].'
    <b>B12:</b>'.$dato[0]['B12'].' <b>B13:</b>'.$dato[0]['B13'].' <b>B14:</b>'.$dato[0]['B14'].' 
    </td>
  </tr>    
  <tr>
    <td colspan="4">Información Productiva > 
    <b>B15:</b> '.$dato[0]['B15'].' <b>B16:</b> '.$dato[0]['B16'].'   
    <b>B17:</b> '.$dato[0]['B17'].' <b>B18:</b> '.$dato[0]['B18'].'   
    <b>B19:</b> '.$dato[0]['B19'].' <b>B20:</b> '.$dato[0]['B20'].'   
    <b>B21:</b> '.$dato[0]['B21'].' <b>B22:</b> '.$dato[0]['B22'].'   
    <b>B23:</b> '.$dato[0]['B23'].' <b>B24:</b> '.$dato[0]['B24'].'   
    <b>B25:</b> '.$dato[0]['B25'].' <b>B26:</b> '.$dato[0]['B26'].' 
	</td>  
  </tr>

  
  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">C. FAMILIA</td>
  </tr> 
  <tr>
    <td>Alimentación > <b>C1:</b>'.$dato[0]['C1'].' <b>C2:</b>'.$dato[0]['C2'].' <b>C3:</b>'.$dato[0]['C3'].'</td>
    <td>Acceso a Servicios de Salud > <b>C4:</b>'.$dato[0]['C4'].' <b>C5:</b> '.$dato[0]['C5'].'</td>
    <td>Apropiación Tecnologia > <b>C6:</b>'.$dato[0]['C6'].' <b>C7:</b>'.$dato[0]['C7'].'<b>C8:</b> '.$dato[0]['C8'].'</td>
    <td>Victimas > <b>C9:</b>'.$dato[0]['C9'].' <b>C10:</b>'.$dato[0]['C10'].' <b>C11:</b>'.$dato[0]['C11'].'<b>C12:</b>'.$dato[0]['C12'].' <b>C13:</b>'.$dato[0]['C13'].'</td>
  </tr>

  
  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">D. INTEGRANTES</td>
  </tr>
  <tr>
    <td  colspan="4">
    <b>D1:</b> '.$dain[0]['D1'].' <b>D2:</b> '.$dain[0]['D2'].' 
    <b>D3:</b> '.$dain[0]['D3'].' <b>D4:</b> '.$dain[0]['D4'].'
    <b>D5:</b> '.$dain[0]['D5'].' <b>D6:</b> '.$dain[0]['D6'].'
    <b>D7:</b> '.$dain[0]['D7'].' <b>D8:</b> '.$dain[0]['D8'].' - '.$V_Clase->trae_respuesta('D8',$dain[0]['D8']).'
    <b>D9:</b> '.$dain[0]['D9'].' <b>D10:</b> '.$dain[0]['D10'].'
    <b>D11:</b> '.$dain[0]['D11'].' <b>D12:</b> '.$dain[0]['D12'].' 
    <b>D13:</b> '.$dain[0]['D13'].' <b>D14:</b> '.$dain[0]['D14'].'
    <b>D15:</b> '.$dain[0]['D15'].' <b>D16:</b> '.$dain[0]['D16'].'
    <b>D17:</b> '.$dain[0]['D17'].' <b>D18:</b> '.$dain[0]['D18'].'
    <b>D19:</b> '.$dain[0]['D19'].' <b>D20:</b> '.$dain[0]['D20'].'
    
    <b>D21:</b> '.$dain[0]['D21'].' <b>D22:</b> '.$dain[0]['D22'].' 
    <b>D23:</b> '.$dain[0]['D23'].' <b>D24:</b> '.$dain[0]['D24'].'
    <b>D25:</b> '.$dain[0]['D25'].' <b>D26:</b> '.$dain[0]['D26'].'
    <b>D27:</b> '.$dain[0]['D27'].' <b>D28:</b> '.$dain[0]['D28'].'
    <b>D29:</b> '.$dain[0]['D29'].' <b>D30:</b> '.$dain[0]['D30'].'
    <b>D31:</b> '.$dain[0]['D31'].' <b>D32:</b> '.$dain[0]['D32'].'
    <b>D33:</b> '.$dain[0]['D33'].' <b>D34:</b> '.$dain[0]['D34'].'
    <b>D35:</b> '.$dain[0]['D35'].'   
    </td>
  </tr>
       
</table>

';

##Muestra Pdf Ficha Individual
}elseif($_GET['mod'] ==51 and $_GET['opcion'] ==6){
$html = '
<table border="1" cellspacing="1" cellpadding="6" width="100%">
  <tr>

    <td colspan="4" align="center">
		ENCUESTA: CARACTERIZACION DEMOGRAFICA Y SOCIOECONOMICA DE LA POBLACION 
		'.$GRUPO.' EN EL MUNICIPIO DE SARAVENA DEPARTAMENTO DE ARAUCA    
    </td>
  </tr>
  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">A. DATOS IDENTIFICACIÓN</td>
  </tr> 
  <tr>
    <td width="25%" class="h3">'.$V_Clase->trae_pregunta("A1").'</td>
    <td width="25%" class="h3 text-center">'.$dato[0]['A1'].'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("A4").' : '.$dato[0]['A4'].'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("A5").' : '.$dato[0]['A5'].'</td>
  </tr>
  <tr>
    <td>'.$V_Clase->trae_pregunta("A2").' : '.$dato[0]['A2'].' / '.$V_Clase->trae_departamento($dato[0]['A2']).'</td>
    <td>'.$V_Clase->trae_pregunta("A3").' : '.$dato[0]['A3'].' / '.$V_Clase->trae_municipio($dato[0]['A3'],$dato[0]['A2']).'</td>
 	<td>'.$V_Clase->trae_pregunta("A6").' : '.$dato[0]['A6'].'</td>
    <td>'.$V_Clase->trae_pregunta("A7").' : '.$dato[0]['A7'].'</td>
  </tr>

  <tr>
    <td colspan="4" class="text-left">Gobierno '.$GRUPO.' >     	
    	<b>A8:</b> '.$dato[0]['A8'].' <b>A9:</b> '.$dato[0]['A9'].' <b>A10:</b> '.$dato[0]['A10'].' 
    	<b>A11:</b> '.$dato[0]['A11'].' <b>A12:</b> '.$dato[0]['A12'].' <b>A13:</b> '.$dato[0]['A13'].' 
        <b>A14:</b> '.$dato[0]['A14'].' <b>A15:</b> '.$dato[0]['A15'].' <b>A16:</b> '.$dato[0]['A16'].' 
        <b>A17:</b> '.$dato[0]['A17'].' <b>A18:</b> '.$dato[0]['A18'].'</td>
  </tr>   
  <tr>
    <td colspan="4" class="text-left">Control de Trabajo >
    	<b>A19:</b> '.$dato[0]['A19'].' <b>A20:</b> '.$dato[0]['A20'].' <b>A21:</b> '. $dato[0]['A21'].' 
        <b>A22:</b> '.$dato[0]['A22'].' <b>A23:</b> '.$dato[0]['A23'].'
 </td>
  </tr>

  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">B. DATOS VIVIENDA</td>
  </tr> 

  <tr>
    <td colspan="2">Propiedad y Estado >
    <b>B1:</b>'.$dato[0]['B1'].' <b>B2:</b>'.$dato[0]['B2'].' <b>B3:</b>'.$dato[0]['B3'].'<b>B4:</b>'.$dato[0]['B4'].'
    <b>B5:</b>'.$dato[0]['B5'].' <b>B6:</b>'.$dato[0]['B6'].' <b>B7:</b>'.$dato[0]['B7'].'<b>B8:</b>'.$dato[0]['B8'].'
    </td>
    <td colspan="2">Servicios Publicos >
	<b>B8:</b>'.$dato[0]['B8'].' <b>B9:</b>'.$dato[0]['B9'].' B10:'.$dato[0]['B10'].' <b>B11:</b>'.$dato[0]['B11'].'
    <b>B12:</b>'.$dato[0]['B12'].' <b>B13:</b>'.$dato[0]['B13'].' <b>B14:</b>'.$dato[0]['B14'].' 
    </td>
  </tr>    
  <tr>
    <td colspan="4">Información Productiva > 
    <b>B15:</b> '.$dato[0]['B15'].' <b>B16:</b> '.$dato[0]['B16'].'   
    <b>B17:</b> '.$dato[0]['B17'].' <b>B18:</b> '.$dato[0]['B18'].'   
    <b>B19:</b> '.$dato[0]['B19'].' <b>B20:</b> '.$dato[0]['B20'].'   
    <b>B21:</b> '.$dato[0]['B21'].' <b>B22:</b> '.$dato[0]['B22'].'   
    <b>B23:</b> '.$dato[0]['B23'].' <b>B24:</b> '.$dato[0]['B24'].'   
    <b>B25:</b> '.$dato[0]['B25'].' <b>B26:</b> '.$dato[0]['B26'].' 
	</td>  
  </tr>

  
  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">C. FAMILIA</td>
  </tr> 
  <tr>
    <td>Alimentación > <b>C1:</b>'.$dato[0]['C1'].' <b>C2:</b>'.$dato[0]['C2'].' <b>C3:</b>'.$dato[0]['C3'].'</td>
    <td>Acceso a Servicios de Salud > <b>C4:</b>'.$dato[0]['C4'].' <b>C5:</b> '.$dato[0]['C5'].'</td>
    <td>Apropiación Tecnologia > <b>C6:</b>'.$dato[0]['C6'].' <b>C7:</b>'.$dato[0]['C7'].'<b>C8:</b> '.$dato[0]['C8'].'</td>
    <td>Victimas > <b>C9:</b>'.$dato[0]['C9'].' <b>C10:</b>'.$dato[0]['C10'].' <b>C11:</b>'.$dato[0]['C11'].'<b>C12:</b>'.$dato[0]['C12'].' <b>C13:</b>'.$dato[0]['C13'].'</td>
  </tr>
       
</table>
';

##Muestra Pdf Ficha - Certificado de Registro
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==8){
$html = '
Saravena, '.utf8_encode(strftime("%B %d del %Y", strtotime(date('Y-m-d')))).'

<br /><br /><br /><br />


La Oficina de Asuntos Étnicos del Municipio de Saravena,

<br /><br />

<table border="1" cellspacing="1" cellpadding="6" width="100%">
  <tr>

    <td colspan="4" align="center">
		CERTIFICADO DE CARACTERIZACION DEMOGRAFICA Y SOCIOECONOMICA DE LA POBLACION 
		'.$GRUPO.' EN EL MUNICIPIO DE SARAVENA DEPARTAMENTO DE ARAUCA    
    </td>
  </tr>
  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">A. DATOS IDENTIFICACIÓN</td>
  </tr> 
  <tr>
    <td width="25%" class="h3">'.$V_Clase->trae_pregunta("A1").'</td>
    <td width="25%" class="h3 text-center">'.$dato[0]['A1'].'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("A4").' : '.$dato[0]['A4'].'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("A5").' : '.$dato[0]['A5'].'</td>
  </tr>
  <tr>
    <td>'.$V_Clase->trae_pregunta("A2").' : '.$dato[0]['A2'].' / '.$V_Clase->trae_departamento($dato[0]['A2']).'</td>
    <td>'.$V_Clase->trae_pregunta("A3").' : '.$dato[0]['A3'].' / '.$V_Clase->trae_municipio($dato[0]['A3'],$dato[0]['A2']).'</td>
 	<td>'.$V_Clase->trae_pregunta("A6").' : '.$dato[0]['A6'].'</td>
    <td>'.$V_Clase->trae_pregunta("A7").' : '.$dato[0]['A7'].'</td>
  </tr>

  <tr>
    <td colspan="4" class="text-center text-uppercase h4" align="center" bgcolor="#CCCCCC">D. INTEGRANTES</td>
  </tr>
  <tr>

    <td colspan="2">'.$V_Clase->trae_pregunta("D6").'</td>
    <td>'.$V_Clase->trae_pregunta("D7").'</td>
    <td>'.$V_Clase->trae_pregunta("D8").'</td>
  </tr>
  <tr>
    <td colspan="2">'.$dain[0]['D6'].' - '.$V_Clase->trae_respuesta('D6',$dain[0]['D6']).'</td>
    <td>'.$dain[0]['D7'].'</td>
    <td>'.$dain[0]['D8'].' - '.$V_Clase->trae_respuesta('D8',$dain[0]['D8']).'</td>
  </tr>
  <tr>
    <td width="25%">'.$V_Clase->trae_pregunta("D1").'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("D2").'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("D3").'</td>
    <td width="25%">'.$V_Clase->trae_pregunta("D4").'</td>
  </tr>
  <tr>
    <td>'.$dain[0]['D1'].'</td>
    <td>'.$dain[0]['D2'].'</td>
    <td>'.$dain[0]['D3'].'</td>
    <td>'.$dain[0]['D4'].'</td>
  </tr>         
</table>

<p align="justify">
Se expide para fines del interesado, Dado en Saravena, Arauca el '.utf8_encode(strftime("%B %d del %Y", strtotime(date('Y-m-d')))).'.
</p>
<P></P><P></P>

 <img src="./tcpdf/images/firmacamc.jpg" border="0" height="124" width="278" align="bottom" /><br />
<b>CARLOS ARTURO MARTINEZ CIBARIZA </b><br/>
Técnico Administrativo de Asuntos Étnicos

<P>Documento Generado del CEM - Caracterización Étnica Municipal</P>
';

##Muestra Pdf Ficha - Certificado de Libreta Militar
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==10){
$html = '
<p align="center">
<h3>EL SUSCRITO FUNCIONARIO DE LA OFICINA DE ASUNTOS ETNICOS DEL MUNICIPIO DE SARAVENA</h3>
</p>
<p align="center">
<h4>CERTIFICA:</h4>
</p>

<p align="justify">Que '.$dain[0]['D1'].' '.$dain[0]['D2'].' '.$dain[0]['D3'].' '.$dain[0]['D4'].' identificado con '.$V_Clase->trae_respuesta('D6',$dain[0]['D6']).' Nº '.$dain[0]['D7'].', es indígena del Pueblo U’WA, '.$V_Clase->trae_respuesta('A18',$dato[0]['A18']).', del '.$V_Clase->trae_respuesta('A17',$dato[0]['A17']).', reconocido por el Ministerio del interior mediante la Resolución Nº 0127 del 23 de diciembre de 2015, es miembro activo como consta en el censo actual que posee esta entidad, reportado por el cabildo.</p>

<p align="justify">Que la ley 48 de 1993 en su artículo 27. Los indígenas que residan en su territorio y conserven su integridad cultural, social y económica. EXENCIONES EN TODO TIEMPO.  Artículo, CONDICIONALMENTE EXEQUIBLE,  están exentos de prestar el servicio militar en todo tiempo. </p>

<p align="justify">Que la sentencia Nº C-058/94 diferencia a los indígenas de los demás ciudadanos respecto a la prestación del servicio militar, a fin de proteger la diversidad étnica y cultural de la Nación colombiana. Los indígenas constituyen grupos que debido a los peligros que existen, para la preservación de su existencia e identidad cultural, se encuentran en situación de debilidad manifiesta  que justifica una especial protección del Estado.</p>
<br >Se expide para fines del interesado el '.utf8_encode(strftime("%B %d del %Y", strtotime(date('Y-m-d')))).'.

<P></P>

<img src="./tcpdf/images/firmacamc.jpg" border="0" height="124" width="278" align="bottom" /><br />
<b>CARLOS ARTURO MARTINEZ CIBARIZA </b><br/>
Técnico Administrativo de Asuntos Étnicos

<P>Documento Generado del CEM - Caracterización Étnica Municipal</P>
';

##Muestra Pdf Ficha - Certificado de Afiliacion en Salud
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==11){
$html = '
<p align="center">
<h3>EL SUSCRITO FUNCIONARIO DE LA OFICINA DE ASUNTOS ETNICOS DEL MUNICIPIO DE SARAVENA</h3>
</p>
<p align="center">
<h4>CERTIFICA:</h4>
</p>

<p align="justify">Que '.$dain[0]['D1'].' '.$dain[0]['D2'].' '.$dain[0]['D3'].' '.$dain[0]['D4'].' identificado con '.$V_Clase->trae_respuesta('D6',$dain[0]['D6']).' Nº '.$dain[0]['D7'].', es indígena del Pueblo U’WA, '.$V_Clase->trae_respuesta('A18',$dato[0]['A18']).', del '.$V_Clase->trae_respuesta('A17',$dato[0]['A17']).' del Municipio de Saravena.</p>

<p align="justify">Se encuentra activo(a) en la base de datos censal, reportado por el cabildo indígena.</p>

<p align="justify">Se expide para trámites de afiliación en salud, el día '.utf8_encode(strftime("%d %B del %Y", strtotime(date('Y-m-d')))).'.

<P></P><P></P>
<img src="./tcpdf/images/firmacamc.jpg" border="0" height="124" width="278" align="bottom" /><br />

<b>CARLOS ARTURO MARTINEZ CIBARIZA </b><br/>
Técnico Administrativo de Asuntos Étnicos


<P>Documento Generado del CEM - Caracterización Étnica Municipal</P>
';

##Muestra Pdf Ficha - Certificado de Duplicado Documento
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==12){
$html = '
<p align="center">
<h3>EL SUSCRITO FUNCIONARIO DE LA OFICINA DE ASUNTOS ETNICOS DEL MUNICIPIO DE SARAVENA</h3>
</p>
<p align="center">
<h4>CERTIFICA:</h4>
</p>

<p align="justify">Que '.$dain[0]['D1'].' '.$dain[0]['D2'].' '.$dain[0]['D3'].' '.$dain[0]['D4'].' identificado con '.$V_Clase->trae_respuesta('D6',$dain[0]['D6']).' Nº '.$dain[0]['D7'].', es indígena del Pueblo U’WA, '.$V_Clase->trae_respuesta('A18',$dato[0]['A18']).', del '.$V_Clase->trae_respuesta('A17',$dato[0]['A17']).' del Municipio de Saravena, se encuentra activo(a) en la Base de Datos censal de la comunidad, reportada por el cabildo a esta entidad.</p>

<p align="justify">Según el acuerdo  77 de 1997 del CNSSS en el artículo 4 dice las comunidades indígenas no están obligadas aplicar el SISBEN.</p>

<p align="justify">Se expide para fines de trámite de Duplicado de '.$V_Clase->trae_respuesta('D6',$dain[0]['D6']).' el día '.utf8_encode(strftime("%d %B del %Y", strtotime(date('Y-m-d')))).'.


<P></P><P></P>
<img src="./tcpdf/images/firmacamc.jpg" border="0" height="124" width="278" align="bottom" /><br />

<b>CARLOS ARTURO MARTINEZ CIBARIZA </b><br/>
Técnico Administrativo de Asuntos Étnicos

<P>Documento Generado del CEM - Caracterización Étnica Municipal</P>
';

##Muestra Pdf Ficha - Certificado de Laboral
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==13){
$html = '
<p align="center">
<h3>EL SUSCRITO FUNCIONARIO DE LA OFICINA DE ASUNTOS ETNICOS DEL MUNICIPIO DE SARAVENA</h3>
</p>
<p align="center">
<h4>CERTIFICA:</h4>
</p>

<p align="justify">Que '.$dain[0]['D1'].' '.$dain[0]['D2'].' '.$dain[0]['D3'].' '.$dain[0]['D4'].' identificado con '.$V_Clase->trae_respuesta('D6',$dain[0]['D6']).' Nº '.$dain[0]['D7'].', es indígena del Pueblo U’WA, '.$V_Clase->trae_respuesta('A18',$dato[0]['A18']).', del '.$V_Clase->trae_respuesta('A17',$dato[0]['A17']).' del Municipio de Saravena, se encuentra activo(a) según censo reportado a esta entidad por el cabildo indígena.</p>

<p align="justify">Se expide para fines laborales, el día '.utf8_encode(strftime("%B %d del %Y", strtotime(date('Y-m-d')))).'.


<P></P><P></P>
<img src="./tcpdf/images/firmacamc.jpg" border="0" height="124" width="278" align="bottom" /><br />

<b>CARLOS ARTURO MARTINEZ CIBARIZA </b><br/>
Técnico Administrativo de Asuntos Étnicos


<P>Documento Generado del CEM - Caracterización Étnica Municipal</P>
';

##Muestra Pdf Ficha - Certificado de Servicios de Salud
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==14){
$html = '
<p align="center">
<h3>EL SUSCRITO FUNCIONARIO DE LA OFICINA DE ASUNTOS ETNICOS DEL MUNICIPIO DE SARAVENA</h3>
</p>
<p align="center">
<h4>CERTIFICA:</h4>
</p>

<p align="justify">Que '.$dain[0]['D1'].' '.$dain[0]['D2'].' '.$dain[0]['D3'].' '.$dain[0]['D4'].' identificado con '.$V_Clase->trae_respuesta('D6',$dain[0]['D6']).' Nº '.$dain[0]['D7'].', es indígena del Pueblo U’WA, '.$V_Clase->trae_respuesta('A18',$dato[0]['A18']).', del '.$V_Clase->trae_respuesta('A17',$dato[0]['A17']).' del Municipio de Saravena.</p>

<p align="justify">Según el acuerdo 77 de 1997 del CNSSS en el artículo 4 dice las comunidades indígenas no están obligadas aplicar el SISBEN.</p>

<p align="justify">Se expide para trámite de servicios hospitalarios, el día '.utf8_encode(strftime("%d %B del %Y", strtotime(date('Y-m-d')))).'.

<P></P><P></P>
<img src="./tcpdf/images/firmacamc.jpg" border="0" height="124" width="278" align="bottom" /><br />

<b>CARLOS ARTURO MARTINEZ CIBARIZA </b><br/>
Técnico Administrativo de Asuntos Étnicos


<P>Documento Generado del CEM - Caracterización Étnica Municipal</P>
';

##Muestra Pdf Ficha - Certificado de Afiliacion en Salud
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==15){
$html = '
<p align="center">
<h3>EL SUSCRITO FUNCIONARIO DE LA OFICINA DE ASUNTOS ETNICOS DEL MUNICIPIO DE SARAVENA</h3>
</p>
<p align="center">
<h4>CERTIFICA:</h4>
</p>

<p align="justify">Que '.$dain[0]['D1'].' '.$dain[0]['D2'].' '.$dain[0]['D3'].' '.$dain[0]['D4'].' identificado con '.$V_Clase->trae_respuesta('D6',$dain[0]['D6']).' Nº '.$dain[0]['D7'].', es indígena del Pueblo U’WA, '.$V_Clase->trae_respuesta('A18',$dato[0]['A18']).', del '.$V_Clase->trae_respuesta('A17',$dato[0]['A17']).', convive en matrimonio tradicional de acuerdo a su cultura con MARGARITA UNCARIA BOCOTA con documento de identidad numero 1115720916, indígena U’WA de la misma comunidad del Municipio de Saravena.</p>

<p align="justify">Se encuentra activo(a) en la base de datos censal, reportado por el cabildo indígena.</p>

<p align="justify">Se expide para fines del interesado, el día '.utf8_encode(strftime("%d %B del %Y", strtotime(date('Y-m-d')))).'.

<P></P><P></P>
<img src="./tcpdf/images/firmacamc.jpg" border="0" height="124" width="278" align="bottom" /><br />

<b>CARLOS ARTURO MARTINEZ CIBARIZA </b><br/>
Técnico Administrativo de Asuntos Étnicos


<P>Documento Generado del CEM - Caracterización Étnica Municipal</P>
';


}##Muestra Pdf 

// Salida de Contenido HTML
$pdf->writeHTML($html, true, false, true, false, '');
# Final Salida HTML

if($_GET['mod'] ==51 and $_GET['opcion'] ==6){

	for ($i=0;$i<sizeof($dain);$i++)
	{
		$html = '
    <div align="justify">
    <b>D1:</b> '.$dain[$i]['D1'].' <b>D2:</b> '.$dain[$i]['D2'].' 
    <b>D3:</b> '.$dain[$i]['D3'].' <b>D4:</b> '.$dain[$i]['D4'].'
    <b>D5:</b> '.$dain[$i]['D5'].' <b>D6:</b> '.$dain[$i]['D6'].'
    <b>D7:</b> '.$dain[$i]['D7'].' <b>D8:</b> '.$dain[$i]['D8'].' - '.$V_Clase->trae_respuesta('D8',$dain[$i]['D8']).'
    <b>D9:</b> '.$dain[$i]['D9'].' <b>D10:</b> '.$dain[$i]['D10'].'
    <b>D11:</b> '.$dain[$i]['D11'].' <b>D12:</b> '.$dain[$i]['D12'].' 
    <b>D13:</b> '.$dain[$i]['D13'].' <b>D14:</b> '.$dain[$i]['D14'].'
    <b>D15:</b> '.$dain[$i]['D15'].' <b>D16:</b> '.$dain[$i]['D16'].'
    <b>D17:</b> '.$dain[$i]['D17'].' <b>D18:</b> '.$dain[$i]['D18'].'
    <b>D19:</b> '.$dain[$i]['D19'].' <b>D20:</b> '.$dain[$i]['D20'].'
    
    <b>D21:</b> '.$dain[$i]['D21'].' <b>D22:</b> '.$dain[$i]['D22'].' 
    <b>D23:</b> '.$dain[$i]['D23'].' <b>D24:</b> '.$dain[$i]['D24'].'
    <b>D25:</b> '.$dain[$i]['D25'].' <b>D26:</b> '.$dain[$i]['D26'].'
    <b>D27:</b> '.$dain[$i]['D27'].' <b>D28:</b> '.$dain[$i]['D28'].'
    <b>D29:</b> '.$dain[$i]['D29'].' <b>D30:</b> '.$dain[$i]['D30'].'
    <b>D31:</b> '.$dain[$i]['D31'].' <b>D32:</b> '.$dain[$i]['D32'].'
    <b>D33:</b> '.$dain[$i]['D33'].' <b>D34:</b> '.$dain[$i]['D34'].'
    <b>D35:</b> '.$dain[$i]['D35'].'   
    </div>
	<hr >
		';
		// Salida de Contenido HTML
		$pdf->writeHTML($html, true, false, true, false, '');	
	}
}


		
$pdf->SetFont('Helvetica', '', 12);






#$pdf->writeHTML($html, true, false, true, false, '');
// set some text to print
$txt = <<<EOD


TCPDF Example 003

Custom page header and footer are defined by extending the TCPDF class and overriding the Header() and Footer() methods.
EOD;

// print a block of text using Write()
#$pdf->Write($h=0, $txt, $link='', $fill=0, $align='C', $ln=true, $stretch=0, $firstline=false, $firstblock=false, $maxh=0);

// ---------------------------------------------------------

//Close and output PDF document 
if($_GET['mod'] ==51 and $_GET['opcion'] ==5){##Muestra Pdf FICHA INDIVIDUAL
$pdf->Output('FICHA_FAMILIA_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');
}elseif($_GET['mod'] ==51 and $_GET['opcion'] ==6){##Muestra Pdf FICHA FAMILIA		
$pdf->Output('FICHA_FAMILIA_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==8){##Muestra Pdf CERTIFICADO	
$pdf->Output('CERT_INTEGRANTE_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');

}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==10){##Muestra Pdf Certi Libreta Militar	
$pdf->Output('CERT_INTE_LIMIL_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==11){##Muestra Pdf Certi Afiliacion Salud	
$pdf->Output('CERT_INTE_AFSAL_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==12){##Muestra Pdf Certi Duplicado Documento	
$pdf->Output('CERT_INTE_DUDOC_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==13){##Muestra Pdf Certi Laboral	
$pdf->Output('CERT_INTE_LABOR_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==14){##Muestra Pdf Certi Servicios Salud	
$pdf->Output('CERT_INTE_SESAL_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');
}elseif($_GET['mod'] ==53 and $_GET['opcion'] ==15){##Muestra Pdf Certi Matrimonio Union
$pdf->Output('CERT_INTE_MAUC_'.date('YmdHis').'_'.$dato[0]['A1'].'.pdf', 'I');


}

//============================================================+
// END OF FILE                                                
//============================================================+