<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
 ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">

<link rel="stylesheet" href="css/estilos.css">
<title>Caracterización Étnica Municipal</title>
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP 
	$V_Clase->gra_menu_general();
?>


    <section class="main row">
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title">Ejecutar Operaciones</h3>
          </div>
          <div class="panel-body"> 
          <!-- Inicio de Operaciones-->
          
          Contenido
          <?PHP 
		if(isset($_POST["GuardarA"])){# echo "Ficha A";

	if(empty($_POST["A5"]) or empty($_POST["A6"]) or empty($_POST["A7"]) or empty($_POST["A20"]) or $_POST["A8"]==0 or $_POST["A9"]==0 or $_POST["A10"]==0 or $_POST["A11"]==0 or $_POST["A12"]==0 or $_POST["A16"]==0 or $_POST["A17"]==0 or $_POST["A21"]==0 or $_POST["A23"]==0)  
	{
		echo '<div class="text-danger text-center bg-danger h3">¡Datos Incompletos, Responda Todas las Preguntas!!</div>';	
		echo '<meta http-equiv="refresh" content="2;URL='.$_SERVER['HTTP_REFERER'].'">';exit;
	}### Final Validacion SERVER

		
	   $sql = "INSERT INTO ce_nucleo VALUES 
				(Null, '".$_POST["dep"]."', '".$_POST["mun"]."', '".$_POST["A4"]."', '".strtoupper($_POST["A5"])."',
				 	   '".strtoupper($_POST["A6"])."', '".$_POST["A7"]."', '".$_POST["A8"]."', '".$_POST["A9"]."',
					   '".$_POST["A10"]."', '".$_POST["A11"]."', '".$_POST["A12"]."', '".$_POST["A13"]."',
					   '".$_POST["A14"]."', '".$_POST["A15"]."', '".$_POST["A16"]."', '".$_POST["A17"]."', 	
					   '".$_POST["A18"]."', '".$_POST["A19"]."', '".$_POST["A20"]."', '".$_POST["A21"]."',
					   '".$_POST["A22"]."', '".$_POST["A23"]."', Null, Null, Null, Null,
					   Null, Null, Null, Null, Null, Null, Null, Null, Null,
					   Null, Null, Null, Null, Null, Null, Null, Null, Null,
					   Null, Null, Null, Null, Null, Null, Null, Null, Null,
					   Null, Null, Null, Null, Null, Null, Null, Null,
					   '".$_POST["g"]."', 1, 'SIN_ARCHIVO.pdf', Now()) ;"; 
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 01: Guardar Ficha Componente A");
	$id= mysql_insert_id();		
	## Inicio de Ingreso de Novedad
	$ficha=$id; $token=Null; $traza="Carga de Datos: A Ficha "; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad
		
		echo '<div class="text-success text-center bg-success h3">Datos Guardados, A. Ficha Numero: '.$id.', Sera Redireccionado a B. Vivienda</div>';	#5
		echo '<meta http-equiv="refresh" content="3;URL=./CargarDatos.php?mod=50&opcion=3&token='.base64_encode($id).'&g='.$_POST["g"].'#tabs-2">';	


		}elseif(isset($_POST["ModificarA"])){# Entrar a Modificar Ficha, Componente A

	if(empty($_POST["A5"]) or empty($_POST["A6"]) or empty($_POST["A7"]) or empty($_POST["A20"]) or $_POST["A8"]==0 or $_POST["A9"]==0 or $_POST["A10"]==0 or $_POST["A11"]==0 or $_POST["A12"]==0 or $_POST["A16"]==0 or $_POST["A17"]==0 or $_POST["A21"]==0 or $_POST["A23"]==0)  
	{
		echo '<div class="text-danger text-center bg-danger h3">¡Datos Incompletos, Responda Todas las Preguntas!!</div>';	
		echo '<meta http-equiv="refresh" content="2;URL='.$_SERVER['HTTP_REFERER'].'">';exit;
	}### Final Validacion SERVER

		  $sql = "UPDATE ce_nucleo SET
									   A2='".$_POST["dep"]."', A3='".$_POST["mun"]."',  A4='".$_POST["A4"]."', 
				A5='".$_POST["A5"]."', A6='".$_POST["A6"]."', A7='".$_POST["A7"]."',  A8='".$_POST["A8"]."',
				A9='".$_POST["A9"]."', A10='".$_POST["A10"]."', A11='".$_POST["A11"]."',  A12='".$_POST["A12"]."',
				A13='".$_POST["A13"]."', A14='".$_POST["A14"]."', A15='".$_POST["A15"]."',  A16='".$_POST["A16"]."',
				A17='".$_POST["A17"]."', A18='".$_POST["A18"]."'
				WHERE 
				A1 ='".base64_decode($_POST["token"])."';";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 010: Modificar Ficha Componente A");
	
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=Null; $traza="Modificar de Datos: A Ficha"; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		
		
		echo '<div class="text-success text-center bg-success h3">Datos Guardados, A. Ficha, Sera Redireccionado a Ver  la Ficha</div>';	#5
		echo '<meta http-equiv="refresh" content="3;URL=./VerDatos.php?mod=51&opcion=1&token='.$_POST["token"].'">';

		}elseif(isset($_POST["GuardarB"]) or isset($_POST["ModificarB"])){# echo "Registrar o Modificar Ficha B";			

	if($_POST["B1"]==0 or $_POST["B15"]==0 or $_POST["B25"]==0 or $_POST["B26"]==0)  
	{
		echo '<div class="text-danger text-center bg-danger h3">¡Datos Incompletos, Responda Todas las Preguntas!!</div>';	
		echo '<meta http-equiv="refresh" content="2;URL='.$_SERVER['HTTP_REFERER'].'#tabs-2">';exit;
	}### Final Validacion SERVER
		
		 $sql = "UPDATE ce_nucleo SET
				B1='".$_POST["B1"]."', B2='".$_POST["B2"]."', B3='".$_POST["B3"]."',  B4='".$_POST["B4"]."', 
				B5='".$_POST["B5"]."', B6='".$_POST["B6"]."', B7='".$_POST["B7"]."',  B8='".$_POST["B8"]."',
				B9='".$_POST["B9"]."', B10='".$_POST["B10"]."', B11='".$_POST["B11"]."',  B12='".$_POST["B12"]."',
				B13='".$_POST["B13"]."', B14='".$_POST["B14"]."', B15='".$_POST["B15"]."',  B16='".$_POST["B16"]."',
				B17='".$_POST["B17"]."', B18='".$_POST["B18"]."', B18='".$_POST["B18"]."',  B19='".$_POST["B19"]."',
				B20='".$_POST["B20"]."', B21='".$_POST["B21"]."', B22='".$_POST["B22"]."',  B23='".$_POST["B23"]."',
				B24='".$_POST["B24"]."', B25='".$_POST["B25"]."', B26='".$_POST["B26"]."'
				WHERE 
				A1 ='".base64_decode($_POST["token"])."';";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 02: Guardar Ficha Componente B");
		
			if(isset($_POST["GuardarB"])){
			echo '<div class="text-success text-center bg-success h3">Datos Guardados, B. Vivienda, Sera Redireccionado a C.Familia</div>';	#5
			echo '<meta http-equiv="refresh" content="3;URL=./CargarDatos.php?mod=50&opcion=4&g='.$_POST["g"].'&token='.$_POST["token"].'#tabs-3">';	
			$nov="Carga de Datos: B Vivienda";
			}elseif(isset($_POST["ModificarB"])){
			echo '<div class="text-success text-center bg-success h3">Datos Modificados, B. Vivienda, Sera Redireccionado a Ver  la Ficha</div>';	#5
			echo '<meta http-equiv="refresh" content="3;URL=./VerDatos.php?mod=51&opcion=1&token='.$_POST["token"].'">';			
			$nov="Modificar de Datos: B Vivienda";		
			}	
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=Null; $traza=$nov; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		


		}elseif(isset($_POST["GuardarC"]) or isset($_POST["ModificarC"])){# echo "Ficha C";

	if($_POST["C1"]==0 or $_POST["C2"]==0 or $_POST["C3"]==0 or $_POST["C4"]==0 or $_POST["C5"]==0 or $_POST["C6"]==0 or $_POST["C7"]==0 or $_POST["C8"]==0 or $_POST["C9"]==0 or $_POST["C10"]==0 or $_POST["C13"]==0)  
	{
		echo '<div class="text-danger text-center bg-danger h3">¡Datos Incompletos, Responda Todas las Preguntas!!</div>';	
		echo '<meta http-equiv="refresh" content="2;URL='.$_SERVER['HTTP_REFERER'].'#tabs-3">';exit;
	}### Final Validacion SERVER
		
		 $sql = "UPDATE ce_nucleo SET
				C1='".$_POST["C1"]."', C2='".$_POST["C2"]."', C3='".$_POST["C3"]."',  C4='".$_POST["C4"]."', 
				C5='".$_POST["C5"]."', C6='".$_POST["C6"]."', C7='".$_POST["C7"]."',  C8='".$_POST["C8"]."',
				C9='".$_POST["C9"]."', C10='".$_POST["C10"]."', C11='".$_POST["C11"]."',  C12='".$_POST["C12"]."', 		
				C13='".$_POST["C13"]."' 
				WHERE 
				A1 ='".base64_decode($_POST["token"])."';";
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 04: Guardar Ficha Componente C");

			if(isset($_POST["GuardarC"])){
				echo '<div class="text-success text-center bg-success h3">Datos Guardados, C. Familia, Sera Redireccionado a D. Integrantes, Debe ingresar '.$_POST["C13"].' Integrantes de la Familia.</div>';	#5
				echo '<meta http-equiv="refresh" content="3;URL=./CargarDatos.php?mod=50&opcion=5&g='.$_POST["g"].'&token='.$_POST["token"].'#tabs-4">';
			$nov="Carga de Datos: C Familia";
			}elseif(isset($_POST["ModificarC"])){
			echo '<div class="text-success text-center bg-success h3">Datos Modificados, C. Familia, Sera Redireccionado a Ver  la Ficha</div>';	#5
			echo '<meta http-equiv="refresh" content="3;URL=./VerDatos.php?mod=51&opcion=1&token='.$_POST["token"].'">';			
			$nov="Modificar de Datos: C Familia";		
			}	
		
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=Null; $traza=$nov; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		
		
	


		}elseif(isset($_POST["GuardarD"])){# echo "Ficha C";
		

	if(empty($_POST["D1"]) or empty($_POST["D3"]) or empty($_POST["D7"]) or empty($_POST["D11"]) or $_POST["D8"]==0 or $_POST["D6"]==0 or $_POST["D9"]==0 or $_POST["D10"]==0 or $_POST["D15"]==0 or $_POST["D16"]==0 or $_POST["D17"]==0 or $_POST["D19"]==0 or $_POST["D23"]==0 or $_POST["D32"]==0 or $_POST["D24"]==0 or $_POST["D26"]==0 or $_POST["D28"]==0 or $_POST["D30"]==0)  
	{
		echo '<div class="text-danger text-center bg-danger h3">¡Datos Incompletos, Responda Todas las Preguntas!!</div>';	
		echo '<meta http-equiv="refresh" content="2;URL='.$_SERVER['HTTP_REFERER'].'#tabs-4">';exit;
	}### Final Validacion SERVER
		
		
		$usuario= $V_Clase->v_integrante($_POST["D7"]);
### Inicio en Caso de Registrar que no exista la persona
		if(sizeof($usuario)!=0)
		{
		echo '<div class="alert-danger text-center h4"><span class="glyphicon glyphicon-alert"></span> ¡Ya Existe Usuario en Ficha Número -- '.$usuario[0]['A1'].' -- , Será redireccionado en 5 Segundos!</div>';	
			echo '<meta http-equiv="refresh" content="6;URL=./VerDatos.php?mod=51&opcion=2&token='.base64_encode($usuario[0]['A1']).'&id='.base64_encode($usuario[0]['ID']).'#i">';			
		}else{
		  $sql = "INSERT INTO ce_integrantes VALUES 
				(Null, '".base64_decode($_POST["token"])."', 
				'".strtoupper($_POST["D1"])."', '".strtoupper($_POST["D2"])."', '".strtoupper($_POST["D3"])."', 
				'".strtoupper($_POST["D4"])."', '".strtoupper($_POST["D5"])."', '".$_POST["D6"]."', 
				'".$_POST["D7"]."', '".$_POST["D8"]."',
				'".$_POST["D9"]."', '".$_POST["D10"]."', '".$_POST["D11"]."', '".$_POST["pais"]."',
				'".$_POST["dep_un"]."', '".$_POST["mun_un"]."', '".$_POST["D15"]."', '".$_POST["D16"]."', 	
				'".$_POST["D17"]."', '".$_POST["D18"]."', '".$_POST["D19"]."', '".$_POST["D20"]."',
				'".$_POST["D21"]."', '".$_POST["D22"]."', '".$_POST["D23"]."', '".$_POST["D24"]."',	   
				'".$_POST["D25"]."', '".$_POST["D26"]."', '".$_POST["D27"]."', '".$_POST["D28"]."', 	
				'".$_POST["D29"]."', '".$_POST["D30"]."', '".$_POST["D31"]."', '".$_POST["D32"]."',
				'".$_POST["D33"]."', '".$_POST["D34"]."', '".$_POST["D35"]."', 1, 'SIN_ARCHIVO_DI.pdf', Now()) ;"; 
				
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 05: Guardar Integrantes Componente D");
	$id= mysql_insert_id();	
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=$id; $traza="Carga de Datos: D Integrantes"; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		
$cuantos=$V_Clase->trae_cuantos_integrantes(base64_decode($_POST["token"]));
$registados=$V_Clase->trae_cuantos_integrantes_registrados(base64_decode($_POST["token"]));

if($registados<$cuantos){
		echo '<div class="text-success text-center bg-success h3">Datos Guardados, D. Integrantes, Sera Redireccionado a Terminar los '.$V_Clase->trae_cuantos_integrantes(base64_decode($_POST["token"])).' Integrantes</div>';	#5
		echo '<meta http-equiv="refresh" content="3;URL=./CargarDatos.php?mod=50&opcion=5&g='.$_POST["g"].'&token='.$_POST["token"].'#tabs-4">';	
		
}elseif($registados==$cuantos){

	$sql = "UPDATE ce_nucleo SET ESTADO='2' WHERE A1 ='".base64_decode($_POST["token"])."';";
	$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 012: Cambiar Estado a Terminado");	
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=Null; $traza="Ficha Finalizada Correctamente"; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		
	
echo '<div class="text-success text-center bg-success h3">Datos Guardados, D. Integrantes, Ha terminado de registrar los Integrantes, sera Redireccionado a Ver la Ficha Completa</div>';	#5
		echo '<meta http-equiv="refresh" content="3;URL=./VerDatos.php?mod=51&opcion=1&token='.$_POST["token"].'">';	

}elseif($registados>$cuantos){

	$sql = "UPDATE ce_nucleo SET ESTADO='2', C13 ='".$registados."' WHERE A1 ='".base64_decode($_POST["token"])."';";
	$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 012: Cambiar Estado a Terminado");	
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=Null; $traza="Integrante Agregado Correctamente"; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad
	
echo '<div class="text-success text-center bg-success h3">Datos Guardados, D. Integrantes, Ha Agregado a Integrante Nuevo, sera Redireccionado a Ver la Ficha Completa</div>';	#5
		echo '<meta http-equiv="refresh" content="3;URL=./VerDatos.php?mod=51&opcion=1&token='.$_POST["token"].'">';	
				
	}
#### Final D

}### Final en Caso de Registrar que no exista la persona

#### Inicio Modificar D
		}elseif(isset($_POST["ModificarD"])){

	if(empty($_POST["D1"]) or empty($_POST["D3"]) or empty($_POST["D7"]) or empty($_POST["D11"]) or $_POST["D8"]==0 or $_POST["D6"]==0 or $_POST["D9"]==0 or $_POST["D10"]==0 or $_POST["D15"]==0 or $_POST["D16"]==0 or $_POST["D17"]==0 or $_POST["D19"]==0 or $_POST["D23"]==0 or $_POST["D32"]==0 or $_POST["D24"]==0 or $_POST["D26"]==0 or $_POST["D28"]==0 or $_POST["D30"]==0)  
	{
		echo '<div class="text-danger text-center bg-danger h3">¡Datos Incompletos, Responda Todas las Preguntas!!</div>';	
		echo '<meta http-equiv="refresh" content="2;URL='.$_SERVER['HTTP_REFERER'].'#tabs-4">';exit;
	}### Final Validacion SERVER
		

		  $sql = "UPDATE ce_integrantes SET 
				
			D1='".strtoupper($_POST["D1"])."', D2='".strtoupper($_POST["D2"])."', D3='".strtoupper($_POST["D3"])."', 
			D4='".strtoupper($_POST["D4"])."', D5='".strtoupper($_POST["D5"])."', D6='".$_POST["D6"]."', 
			D7='".$_POST["D7"]."', D8='".$_POST["D8"]."',
			D9='".$_POST["D9"]."', D10='".$_POST["D10"]."', D11='".$_POST["D11"]."', D12='".$_POST["pais"]."',
			D13='".$_POST["dep_un"]."', D14='".$_POST["mun_un"]."', D15='".$_POST["D15"]."', D16='".$_POST["D16"]."',
			D17='".$_POST["D17"]."', D18='".$_POST["D18"]."', D19='".$_POST["D19"]."', D20='".$_POST["D20"]."',
			D21='".$_POST["D21"]."', D22='".$_POST["D22"]."', D23='".$_POST["D23"]."', D24='".$_POST["D24"]."',	   
			D25='".$_POST["D25"]."', D26='".$_POST["D26"]."', D27='".$_POST["D27"]."', D28='".$_POST["D28"]."', 	
			D29='".$_POST["D29"]."', D30='".$_POST["D30"]."', D31='".$_POST["D31"]."', D32='".$_POST["D32"]."',
			D33='".$_POST["D33"]."', D34='".$_POST["D34"]."', D35='".$_POST["D35"]."' WHERE ID=".base64_decode($_POST["id"])." ;"; 
				
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 15: Guardar Integrantes Componente D");
	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=base64_decode($_POST["id"]); $traza="Modificar Datos: D Integrante"; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		

		echo '<div class="text-success text-center bg-success h3">Datos Modificados, D. Integrantes, Sera Redireccionado a ver Ficha</div>';	#5
		echo '<meta http-equiv="refresh" content="3;URL=./VerDatos.php?mod=51&opcion=1&token='.$_POST["token"].'">';	
################################# Mover Integrantes
		}elseif(isset($_POST["MoverIntegrante"])){

		$sql = "UPDATE ce_integrantes SET A1='".$_POST["nficha"]."' WHERE ID=".base64_decode($_POST["id"])." ;"; 
		$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 15: Guardar Integrantes Componente D");
	## Inicio de Ingreso de Novedad
	$ficha=$_POST["nficha"]; $token=base64_decode($_POST["id"]); $traza="Integrante Movido de Ficha"; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);


		echo '<div class="text-success text-center bg-success h3">Datos Modificados, D. Integrantes, Fue Movido de Ficha, Sera Redireccionado a ver la Nueva Ficha</div>';	#5
		echo '<meta http-equiv="refresh" content="3;URL=./VerDatos.php?mod=51&opcion=1&token='.base64_encode($_POST["nficha"]).'">';	


		}elseif(isset($_POST["CargarFicha"])){
// Sirve Obtener el nombre y Area a quien envian el radicado
		  $tamano  = 	$_FILES["archivo"]['size'];
          $tipo    =	$_FILES["archivo"]['type'];
          $archivo = 	$_FILES["archivo"]['name'];
		  $temp    =	$_FILES["archivo"]['tmp_name'];
		  
$kilobytes=$tamano/1024;	$kilobytes=round($kilobytes);
if ($kilobytes > 5120)
{
	 $si_radicar=0; echo '<div class="text-danger text-center bg-danger h3">Muy grande el archivo + 5 MB</div>';
  	 echo '<meta http-equiv="refresh" content="1;URL='.$_SERVER['HTTP_REFERER'].'">';exit;
}else{

########### Asignacion de Extension ############################################
if ($tipo=="application/pdf")
{
//**************************************************************************
	switch ($tipo)
	{
		case 'application/pdf': 				$ext=".pdf";					break;
	}

	$nombre_file = 'FICHA_'.$fecha_file.$pre_file.$ext;	
	copy($temp,"files/$nombre_file");
	$si_radicar=1;
}else{
	$si_radicar=0;
	echo '<div class="text-danger text-center bg-danger h3">Archivo No Valido</div>';	
	echo '<meta http-equiv="refresh" content="1;URL='.$_SERVER['HTTP_REFERER'].'">';exit;
}# Si el archivo No es Valido	
	
}# Final Si el Archivo Mayor de 5 MEGAS


	## Modificacion del Archivo
	$sql = "UPDATE ce_nucleo SET ARCHIVO='$nombre_file' WHERE A1 ='".base64_decode($_POST["token"])."';";
	$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 013: Cargar Ficha Escaneda");	
	echo '<div class="text-success text-center bg-success h3">Archivo Ficha Escaneada Cargada Correctamente</div>';
	echo '<meta http-equiv="refresh" content="1;URL=Reportes.php?mod=52&opcion=1">';


	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=Null; $traza="Archivo Ficha Escaneada Cargada Correctamente"; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		
			 			 

		}elseif(isset($_POST["CargarDI"])){
// Sirve Obtener el nombre y Area a quien envian el radicado
		  $tamano  = 	$_FILES["archivo"]['size'];
          $tipo    =	$_FILES["archivo"]['type'];
          $archivo = 	$_FILES["archivo"]['name'];
		  $temp    =	$_FILES["archivo"]['tmp_name'];
		  
$kilobytes=$tamano/1024;	$kilobytes=round($kilobytes);
if ($kilobytes > 5120)
{
	 $si_radicar=0; echo '<div class="text-danger text-center bg-danger h3">Muy grande el archivo + 5 MB</div>';
  	 echo '<meta http-equiv="refresh" content="1;URL='.$_SERVER['HTTP_REFERER'].'">';exit;
}else{

########### Asignacion de Extension ############################################
if ($tipo=="application/pdf")
{
//**************************************************************************
	switch ($tipo)
	{
		case 'application/pdf': 				$ext=".pdf";					break;
	}

	$nombre_file = 'DI_'.$fecha_file.$pre_file.$ext;	
	copy($temp,"files/$nombre_file");
	$si_radicar=1;
}else{
	$si_radicar=0;
	echo '<div class="text-danger text-center bg-danger h3">Archivo No Valido</div>';	
	echo '<meta http-equiv="refresh" content="1;URL='.$_SERVER['HTTP_REFERER'].'">';exit;
}# Si el archivo No es Valido	
	
}# Final Si el Archivo Mayor de 5 MEGAS

	## Modificacion del Archivo
	$sql = "UPDATE ce_integrantes SET ARCHIVO_DI='$nombre_file' WHERE ID ='".base64_decode($_POST["id"])."';";
	$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 014: Cargar Documento Identidad Escanedo");	
	echo '<div class="text-success text-center bg-success h3">Archivo Documento Identidad Cargado Correctamente</div>';
	echo '<meta http-equiv="refresh" content="1;URL=Reportes.php?mod=52&opcion=2">';

	## Inicio de Ingreso de Novedad
	$ficha=base64_decode($_POST["token"]); $token=base64_decode($_POST["id"]); $traza="Archivo Documento Identidad Cargado Correctamente"; $apoyo=Null;
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		

################################## ################################## ################################## 
		
		}elseif(isset($_POST["regUsuario"])){									
				#echo substr($_POST["ced"],-4); exit;
				$sql = "insert into seg_usuarios values 
						('".$_POST["ced"]."',  
						'".strtoupper($_POST["nc"])."', 
						'".strtoupper($_POST["em"])."',
						'".$_POST["tel"]."',
						'".$_POST["rol"]."',
						'".$_POST["dep"]."',
						'".$_POST["mun"]."',
						md5('".substr($_POST["ced"],-4)."'),
						'".$_POST["A17"]."'
						)"; 
				$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Mensaje del Sistema: Ya se encuentra registrado el Usuario");	

	## Inicio de Ingreso de Novedad
	$ficha=Null; $token=Null; $traza="Usuario Registrado Correctamente"; $apoyo=$_POST["ced"];
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad					
								
				echo '<div class="bg-success"><span class="glyphicon glyphicon-ok"></span> Datos Guardados</div>';	
				echo '<meta http-equiv="refresh" content="5;URL=./CentroControl.php?mod=54&opcion=1">';
################################## ################################## ################################## 
		}elseif(isset($_POST["modUsuario"])){	
				
				$sql = "UPDATE  seg_usuarios SET 
					usua_nombre_completo = '".strtoupper($_POST["nc"])."', 
					usua_correo = '".strtoupper($_POST["em"])."',
					usua_telefono = '".$_POST["tel"]."',
					usua_rol = '".$_POST["rol"]."',
					usua_gp = '".$_POST["A17"]."'					
					WHERE  usua_cedula ='".$_POST["ced"]."' LIMIT 1 ;"; 
				$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 14: Modificar Usuario");					

	## Inicio de Ingreso de Novedad
	$ficha=Null; $token=Null; $traza="Usuario Modificado Correctamente"; $apoyo=$_POST["ced"];
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad		

				echo '<div class="bg-success"><span class="glyphicon glyphicon-ok"></span> Datos Modificados</div>';	
				echo '<meta http-equiv="refresh" content="5;URL=./CentroControl.php?mod=54&opcion=1">';
################################## ############################################
		}elseif(isset($_POST['regConfiguracion'])){				
				
				$sql = "insert into par_configuracion values 
						(Null, '".$_POST["dep"]."',  
						'".$_POST["mun"]."', 
						'".$_POST["entidad"]."')"; 
				$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 15: Insertar Configuracion");					
				echo '<div class="bg-success"><span class="glyphicon glyphicon-ok"></span> Datos Guardados</div>';	
				echo '<meta http-equiv="refresh" content="5;URL=./index.php?mod=54&opcion=13">';
				
################################## ############################################
		}elseif(isset($_POST['modConfiguracion'])){				
				
				$sql = "UPDATE  par_configuracion SET 
					`con_departamento` =  '".$_POST["dep"]."', 
					`con_municipio` =  '".$_POST["mun"]."',
					`con_entidad` =  '".$_POST["entidad"]."' 
					WHERE  con_id ='".$_POST["id"]."' LIMIT 1 ;"; 
				$ejecutar = mysql_query($sql,cTrabajo::con()) or die ("Error 16: Modificar Configuracion");					

				echo '<div class="bg-success"><span class="glyphicon glyphicon-ok"></span> Datos Modificados</div>';	
				echo '<meta http-equiv="refresh" content="5;URL=./index.php?mod=54&opcion=13">';
			

################################## ############################################
		}elseif(isset($_POST['CambiarClave'])){				

   $sql ="SELECT usua_clave FROM seg_usuarios WHERE usua_cedula =".$_POST['token'];
	$rs = mysql_query($sql,cTrabajo::con()) or die ("Error de consulta en la selección");
	$totalrs= mysql_num_rows ($rs); 
	$result = mysql_query($sql);
	
	while ($row = mysql_fetch_array($result)){
			$clave=$row['usua_clave'];

	}

md5($_POST["act"]);		$_POST["ncla"]; 		$_POST["ccla"];

if($_POST["ncla"] != $_POST["ccla"]){
echo '<div class="text-danger text-center bg-danger h3">Debes colocar la misma contraseña!</div>';
echo '<meta http-equiv="refresh" content="5;URL='.$_SERVER['HTTP_REFERER'].'#tabs-clave">';
}else{
   
// Fin de mientras asigna varibles
	if (md5($_POST["act"]) == $clave){ 
	//Cuando todo esta bien
	$ssql = "UPDATE seg_usuarios SET usua_clave=md5('".$_POST['ncla']."') Where usua_cedula=".$_POST['token'];		
	
	$ejecutar = mysql_query($ssql,cTrabajo::con()) or die ("Error 16: Modificar Configuracion");
	## Inicio de Ingreso de Novedad
	$ficha=Null; $token=Null; $traza="Usuario Cambio de contraseña Correctamente"; $apoyo=$_POST["token"];
	$V_Clase->IngNov($ficha,$token,$traza,$apoyo,$_SESSION['user_nombres']);
	## Final de Ingreso de Novedad	

echo '<div class="bg-success"><span class="glyphicon glyphicon-ok"></span> Cambio de contraseña correcto!</div>';	
echo '<meta http-equiv="refresh" content="5;URL=./CentroControl.php?mod=54&opcion=4&token='.$_POST['token'].'">';

}

}



									

				
			
			  
		  }
			  ?>
          <!-- Final de Operaciones-->  
          </div>
        </div> 
        </article>
    </section>
    
</div>
<?PHP $V_Clase->gra_pie_pagina();?>


<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/funciones.js"></script>
<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
