<?php require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();
// comprobar variables de sesión

if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
 ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">

<link rel="stylesheet" href="css/estilos.css">
<title>Caracterización Étnica Municipal</title>


<style type="text/css">
	li.ui-menu-item { font-size:12px !important; }
	</style> 
</head>

<body>

<?php include_once("analyticstracking.php") ?>
<div class="container-fluid">
<?PHP $V_Clase->gra_menu_general();	?>


    <section class="main row">

<?PHP if(($_GET['mod']==50 and $_GET['opcion']==1) or ($_GET['mod']==50 and $_GET['opcion']==2) 
		or ($_GET['mod']==50 and $_GET['opcion']==3) or ($_GET['mod']==50 and $_GET['opcion']==4) 
		or ($_GET['mod']==50 and $_GET['opcion']==5) or ($_GET['mod']==50 and $_GET['opcion']==7) 
		or ($_GET['mod']==50 and $_GET['opcion']==8) or ($_GET['mod']==50 and $_GET['opcion']==9)
		or ($_GET['mod']==50 and $_GET['opcion']==10) ){##Inicio
		
		if($_GET['opcion']==7 or $_GET['opcion']==8 or $_GET['opcion']==9 or $_GET['opcion']==10){
				$dato=$V_Clase->v_ficha($_GET['token']);
				if($_GET['opcion']==10){ $dain=$V_Clase->v_integrantes_id($_GET['id']); }
		}
		?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 
<div class="h3 text-center">Cargar Datos Ficha Técnica 
		<?PHP if($_GET['g']==2){?>Indigena<?PHP }elseif($_GET['g']==1){?>Afrocolombiano<?PHP } ?>
        <?PHP if(isset($_GET['token'])){echo 'Numero: '.base64_decode($_GET['token']);}?>
    </div>
<div id="tabs">
  <ul>
    <li><a href="#tabs-1">A. Ficha</a></li>
    <li><a href="#tabs-2">B. Vivienda</a></li>
    <li><a href="#tabs-3">C. Familia</a></li>
    <li><a href="#tabs-4">D. Integrantes</a></li>    
  </ul>
 
  <div id="tabs-1">
	<div class="row text-left h4 bg-primary">Identificación Ficha</div>
    <form action="Ejecutar.php" name="form" method="post" enctype="multipart/form-data">
    <div class="row">    
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A1"); ?> 
			<?PHP if($_GET['opcion']==7){ echo ': <div class="h4">'.$dato[0]['A1'].'</div>' ;}?>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A2");?>
            <?PHP if($_GET['opcion']==7){
			$cargar=$dato[0]['A2'];}elseif($_GET['opcion']==2){ $cargar=$conf[0]['con_departamento'];}else{$cargar=0;} 
				   $V_Clase->comboDepartamento($cargar); ?>
        </div>
   
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("A3");?>
            <div id="div_municipio_edes" >
		    <?PHP if($_GET['opcion']==7){
                $cargar=$dato[0]['A2']; $mun=$dato[0]['A3'];$V_Clase->comboMunicipio($cargar,$mun);
            
                }elseif($_GET['opcion']==2){ $cargar=$conf[0]['con_departamento'];
					$V_Clase->comboMunicipio($cargar,$conf[0]['con_municipio']);
				}else{$carga=$conf[0]['con_departamento']; $mun=0;?>
                <select class="form-control" id="mun" name="mun">
                    <option value="0">Seleccione el Municipio</option>
                </select>							
            <?PHP }?>                                
            </div>      

        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">    	
            <?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A4'];}else{$cargar=0;} $V_Clase->trae_pregunta_completa("A4",$cargar);?>
        </div>
    </div>                 

    <div class="row"> 
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        	<?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A5'];}else{$cargar="";} $V_Clase->trae_pregunta_completa("A5",$cargar);?>
        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A6'];}else{$cargar="";} $V_Clase->trae_pregunta_completa("A6",$cargar);?>        
        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A7'];}else{$cargar="";} $V_Clase->trae_pregunta_completa("A7",$cargar);?>       
        </div> 
    </div> 
  
	  
    <div class="row text-left h4 bg-success">Gobierno AfroColombiano / Indigena</div>
	<div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A8");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A8'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A8",$cargar);?></div>  
    </div>
    <div class="row">     
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A9");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A9'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A9",$cargar);?></div>  
	</div>
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A10");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A10'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A10",$cargar);?></div>  
	</div>
	<div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A11");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A11'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A11",$cargar);?></div>  
    </div>
    <div class="row">     
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A12");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A12'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A12",$cargar);?></div>  
	</div>
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A13");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A13'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A13",$cargar);?></div>  
	</div>
    <?PHP if($_GET['g']==1){ # Afrocolombiano?>
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A14");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A14'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A14",$cargar);?></div> 
    </div> 
    <?PHP }else{?> <input type="hidden" value="" name="A14"><?PHP } ?>
    <?PHP if($_GET['g']==2){ # Indigena?>   
    <div class="row">     
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A15");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A15'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A15",$cargar);?></div>  
	</div>
    <?PHP }else{?> <input type="hidden" value="" name="A15"><?PHP } ?>
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A16");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A16'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A16",$cargar);?></div>  
    </div>
    <div class="row">     
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A17");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A17'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A17",$cargar);?></div>  
	</div>
    <?PHP if($_GET['g']==2){ # Indigena?>   
    <div class="row"> 
    	<div class="col-xs-6 text-right"><?PHP echo $V_Clase->trae_pregunta("A18");?></div>
		<div class="col-xs-4"><?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A18'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A18",$cargar);?></div>  
	</div>
    <?PHP }else{?> <input type="hidden" value="" name="A18"><?PHP } ?>
    <div class="row text-left h4 bg-primary">Control de Trabajo</div>

    <div class="row">
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A19");?>
	  	<?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A19'];}else{$cargar=$_SESSION["user_cedula"];} $V_Clase->trae_pregunta_respuesta("A19",$cargar);?>
      </div>
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A20");?>
	  	<?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A20'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A20",$cargar);?>
      </div>      
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A21");?>
	  	<?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A21'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A21",$cargar);?>
      </div>      
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A22");?>
	  	<?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A22'];}else{$cargar=date('Y-m-d');} $V_Clase->trae_pregunta_respuesta("A22",$cargar);?>
      </div>
    </div>

    <div class="row">
      <div class="col-md-3">
	  	<?PHP echo $V_Clase->trae_pregunta("A23");?>
	  	<?PHP if($_GET['opcion']==7){$cargar=$dato[0]['A23'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("A23",$cargar);?>
      </div>  
      <div class="col-md-6 text-danger">
	  	
	  	<?PHP if($_GET['opcion']==7){ echo 'Nota: No podras cambiar los datos: Control de Trabajo.';} ?>
      </div>         
    </div>
          
    <div class="row">
      <div class="col-md-12 text-center">
      <?PHP if($_GET['opcion']==7){?>
        <input type="hidden" name="token" value="<?PHP echo $_GET['token'];?>">
        <input type="submit" name="ModificarA" class="btn btn-success btn-lg" value="Modificar A. Ficha" >
      <?PHP }else{?>
		<input type="submit" name="GuardarA" class="btn btn-success btn-lg" value="Guardar A. Ficha" >  
	  <?PHP } ?>	  	
        <input type="hidden" name="mod" value="50">
        <input type="hidden" name="g" value="<?PHP echo $_GET['g']?>">       
      </div>           
    </div>
                    
   </form>                                                    
  </div><!-- Final Tab 1-->
  <div id="tabs-2">
      <form action="Ejecutar.php" name="form-2" method="post" enctype="multipart/form-data">
      <div class="row text-left h4 bg-primary">Propiedad y Estado</div>
      
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("B1");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B1'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B1",$cargar);?>
          </div>
          
<!--Inicio Mostrar-->
<div id="b2-b8" style="display:<?PHP if(base64_decode($_GET['opcion']) == 7){ echo 'block;';}else{ echo 'block;';}?>">
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B2");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B2'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B2",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B3");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B3'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B3",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B4");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B4'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B4",$cargar);?>
          </div>
	</div><!--Final Mostrar-->                    
        </div>  
        
        <div class="row" id="b2-b8-2" style="display:<?PHP if(base64_decode($_GET['opcion']) == 7){ echo 'block;';}else{ echo 'block;';}?>">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("B5");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B5'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B5",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B6");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B6'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B6",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B7");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B7'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B7",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B8");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B8'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B8",$cargar);?>
          </div>
        </div>              
      
      <div class="row text-left h4 bg-success">Servicios Publicos</div>
      
        <div class="row">
          <div class="col-md-4">
		  <?PHP echo $V_Clase->trae_pregunta("B9");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B9'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B9",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("B10");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B10'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B10",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("B11");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B11'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B11",$cargar);?>
          </div>
        </div>   
        
        <div class="row">
          <div class="col-md-4">
		  <?PHP echo $V_Clase->trae_pregunta("B12");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B12'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B12",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("B13");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B13'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B13",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("B14");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B14'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B14",$cargar);?>
          </div>
        </div>   
                      
      <div class="row text-left h4 bg-primary">Información Productiva</div>

        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("B15");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B15'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B15",$cargar);?>
          </div>
          <div class="col-md-3" id="B16">
          <?PHP echo $V_Clase->trae_pregunta("B16");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B16'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B16",$cargar);?>
          </div>
          <div class="col-md-3" id="B17">
          <?PHP echo $V_Clase->trae_pregunta("B17");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B17'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B17",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B18");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B18'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B18",$cargar);?>
          </div>
        </div> 
        
        <div class="row">
          <div class="col-md-3" id="B19">
		  <?PHP echo $V_Clase->trae_pregunta("B19");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B19'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B19",$cargar);?>
          </div>
          <div class="col-md-3" id="B20">
          <?PHP echo $V_Clase->trae_pregunta("B20");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B20'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B20",$cargar);?>
          </div>
          <div class="col-md-3" id="B21">
          <?PHP echo $V_Clase->trae_pregunta("B21");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B21'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B21",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("B22");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B22'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B22",$cargar);?>
          </div>
        </div> 
        
        <div class="row">
          <div class="col-md-3" id="B23">
		  <?PHP echo $V_Clase->trae_pregunta("B23");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B23'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B23",$cargar);?>
          </div>
          <div class="col-md-3" id="B24">
          <?PHP echo $V_Clase->trae_pregunta("B24");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B24'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B24",$cargar);?>
          </div>
          <div class="col-md-3" id="B25">
          <?PHP echo $V_Clase->trae_pregunta("B25");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B25'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B25",$cargar);?>
          </div>
          <div class="col-md-3" id="B26">
          <?PHP echo $V_Clase->trae_pregunta("B26");?><?PHP if($_GET['opcion']==8){$cargar=$dato[0]['B26'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("B26",$cargar);?>
          </div>
        </div>                   

        <div class="row">
          <div class="col-md-12 text-center">
          	<?PHP if($_GET['opcion']==8){?>
            <input type="submit" name="ModificarB" class="btn btn-success btn-lg" value="Modificar B. Vivienda" >
            <?PHP }else{?>
			<input type="submit" name="GuardarB" class="btn btn-success btn-lg" value="Guardar B. Vivienda" >
			<?PHP }?>            
            <input type="hidden" name="mod" value="50">
            <input type="hidden" name="g" value="<?PHP echo $_GET['g']?>">
            <input type="hidden" name="token" value="<?PHP echo $_GET['token']?>">       
          </div>           
        </div>
                    
   </form>   
 
  </div>
  <div id="tabs-3">
    <form action="Ejecutar.php" name="form-3" method="post" enctype="multipart/form-data">
	<div class="row text-left h4 bg-primary">Alimentación</div>
        <div class="row">
          <div class="col-md-4">
		  <?PHP echo $V_Clase->trae_pregunta("C1");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C1'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C1",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C2");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C2'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C2",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C3");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C3'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C3",$cargar);?>
          </div>         
        </div> 

	<div class="row text-left h4 bg-success">Acceso a Servicios de Salud</div>        
        <div class="row">
          <div class="col-md-6">
          <?PHP echo $V_Clase->trae_pregunta("C4");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C4'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C4",$cargar);?>
          </div>
          <div class="col-md-6">
		  <?PHP echo $V_Clase->trae_pregunta("C5");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C5'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C5",$cargar);?>
          </div>
        </div> 
    
	<div class="row text-left h4 bg-success">Apropiación Tecnologia</div>        
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C6");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C6'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C6",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C7");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C7'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C7",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("C8");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C8'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C8",$cargar);?>
          </div>
        </div>         

	<div class="row text-left h4 bg-primary">Victimas</div>        
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("C9");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C9'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C9",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("C10");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C10'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C10",$cargar);?>
          </div>
          <div class="col-md-3" id="C11">
          <?PHP echo $V_Clase->trae_pregunta("C11");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C11'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C11",$cargar);?>
          </div>
          <div class="col-md-3" id="C12">
          <?PHP echo $V_Clase->trae_pregunta("C12");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C12'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C12",$cargar);?>
          </div>
        </div>                 

	<div class="row text-left h4 bg-primary">Integrantes de la Familia</div>        
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("C13");?><?PHP if($_GET['opcion']==9){$cargar=$dato[0]['C13'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("C13",$cargar);?>
          </div>
        </div>                 

  
        <div class="row">
          <div class="col-md-12 text-center">
            <?PHP if($_GET['opcion']==9){?>
            <input type="submit" name="ModificarC" class="btn btn-success btn-lg" value="Modificar C. Familia" >
            <?PHP }else{?>
			<input type="submit" name="GuardarC" class="btn btn-success btn-lg" value="Guardar C. Familia" >
			<?PHP }?>            
            <input type="hidden" name="mod" value="50">
            <input type="hidden" name="g" value="<?PHP echo $_GET['g'];?>">
            <input type="hidden" name="token" value="<?PHP echo $_GET['token'];?>">       
          </div>           
        </div>
                    
   </form>     
  

  </div><!-- Final Tab 3 -->
    <div id="tabs-4" class="selector">
    <form action="Ejecutar.php" name="form4" method="post" enctype="multipart/form-data">
	<div class="row text-left h4 bg-primary">Personal</div>
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("D1");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D1'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D1",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D2");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D2'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D2",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D3");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D3'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D3",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D4");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D4'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D4",$cargar);?>
          </div>
        </div>                 

        <div class="row">
         <?PHP if($_GET['g']==2){ # Indigena?>   
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D5");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D5'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D5",$cargar);?>
          </div>  
         <?PHP }else{?> <input type="hidden" value="" name="D5"><?PHP } ?>

          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("D6");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D6'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D6",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D7");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D7'];}else{$cargar="";} #$V_Clase->trae_pregunta_respuesta("D7",$cargar);?>
          <input type="number" name="D7" id="D7" placeholder="D7" class="form-control input-sm" title="Seleccione ó Ingrese dato" value="<?PHP echo $cargar;?>" onBlur="refre_capa(document.form4.D7.value, 'div_valida', 'mod_com_ajax.php', '7')" >
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D8");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D8'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D8",$cargar);?>
          </div>
        </div>                 
		<div id="div_valida"></div>
        <div class="row">
          <div class="col-md-3">
		  <?PHP echo $V_Clase->trae_pregunta("D9");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D9'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D9",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D10");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D10'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D10",$cargar);?>
          </div>
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D11");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D11'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D11",$cargar);?>
          </div>
          
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D12");?>
		  <?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D12'];}else{$cargar=0;}  
				   $V_Clase->comboUnPais($cargar); ?>		  
          </div>
        </div>                 

        <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <?PHP echo $V_Clase->trae_pregunta("D13");?>           
            <div id="div_dep_edes" >
               <?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D13']; $pais=$dain[0]['D12'];
                       $V_Clase->comboUnDepartamentos($pais,$cargar);
                    }else{?>
                       <select class="form-control input-sm" id="dep_un" name="dep_un">
                         <option value="0">Seleccione el Departamento</option>
                       </select>	                                               
               <?PHP }?>
             </div>                        
        </div>
   
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <?PHP echo $V_Clase->trae_pregunta("D14");?>
            <div id="div_mun_un" >
               <?PHP if($_GET['opcion']==10){$departamento=$dain[0]['D13']; $pais=$dain[0]['D12']; $cargar=$dain[0]['D14'];
                       $V_Clase->comboUnMunicipio($pais,$departamento,$cargar);
                    }else{?>
                       <select class="form-control input-sm" id="mun_un" name="mun_un">
                         <option value="0">Seleccione el Municipio</option>
                       </select>	                                               
               <?PHP } ?>
             </div>  
        </div>
          
        </div>                 




	<div class="row text-left h4 bg-success">Enfoque</div>
        <div class="row">
          <div class="col-md-6">
          <?PHP echo $V_Clase->trae_pregunta("D15");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D15'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D15",$cargar);?>
          </div>
          <div class="col-md-6">
          <?PHP echo $V_Clase->trae_pregunta("D16");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D16'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D16",$cargar);?>
          </div>

        </div> 
    
	<div class="row text-left h4 bg-success">Educación</div>
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D17");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D17'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D17",$cargar);?>
          </div>
          <div class="col-md-4" id="D18">
          <?PHP echo $V_Clase->trae_pregunta("D18");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D18'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D18",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D19");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D19'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D19",$cargar);?>
          </div>
        </div> 
        
        <div class="row">
           <?PHP if($_GET['g']==2){ # Indigena?>   
              <div class="col-md-3">
              <?PHP echo $V_Clase->trae_pregunta("D20");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D20'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D20",$cargar);?>
              </div>
            <?PHP }else{?> <input type="hidden" value="" name="D20"><?PHP } ?>
    
           <?PHP if($_GET['g']==2){ # Indigena?>   
              <div class="col-md-3">
              <?PHP echo $V_Clase->trae_pregunta("D21");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D21'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D21",$cargar);?>
              </div>
            <?PHP }else{?> <input type="hidden" value="" name="D21"><?PHP } ?>

           <?PHP if($_GET['g']==2){ # Indigena?>   
              <div class="col-md-3">
              <?PHP echo $V_Clase->trae_pregunta("D22");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D22'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D22",$cargar);?>
              </div>
            <?PHP }else{?> <input type="hidden" value="" name="D22"><?PHP } ?>                
          
          <div class="col-md-3">
          <?PHP echo $V_Clase->trae_pregunta("D23");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D23'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D23",$cargar);?>
          </div>
        </div>         

    
	<div class="row text-left h4 bg-success">Salud y Discapacidad </div>
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D24");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D24'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D24",$cargar);?>
          </div>
          <div class="col-md-4" id="D25">
          <?PHP echo $V_Clase->trae_pregunta("D25");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D25'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D25",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D26");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D26'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D26",$cargar);?>
          </div>
        </div>  

        <div class="row">
          <div class="col-md-4" id="D27">
          <?PHP echo $V_Clase->trae_pregunta("D27");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D27'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D27",$cargar);?>
          </div>
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D28");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D28'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D28",$cargar);?>
          </div>
          <div class="col-md-4" id="D29">
          <?PHP echo $V_Clase->trae_pregunta("D29");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D29'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D29",$cargar);?>
          </div>
        </div>  
        
        <div class="row">
          <div class="col-md-6">
          <?PHP echo $V_Clase->trae_pregunta("D30");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D30'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D30",$cargar);?>
          </div>
          <div class="col-md-6" id="D31">
          <?PHP echo $V_Clase->trae_pregunta("D31");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D31'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D31",$cargar);?>
          </div>
        </div>          
    
	<div class="row text-left h4 bg-primary">Información Laboral</div>     
        <div class="row">
          <div class="col-md-4">
          <?PHP echo $V_Clase->trae_pregunta("D32");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D32'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D32",$cargar);?>
          </div>
          <div class="col-md-4" id="D33">
          <?PHP echo $V_Clase->trae_pregunta("D33");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D33'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D33",$cargar);?>
          </div>
          <div class="col-md-4" id="D34">
          <?PHP echo $V_Clase->trae_pregunta("D34");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D34'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D34",$cargar);?>
          </div>
          <div class="col-md-4" id="D35">
          <?PHP echo $V_Clase->trae_pregunta("D35");?><?PHP if($_GET['opcion']==10){$cargar=$dain[0]['D35'];}else{$cargar="";} $V_Clase->trae_pregunta_respuesta("D35",$cargar);?>
          </div>
        </div>                  
  	
        <div class="row">
          <div class="col-md-12 text-center">
          <?PHP if($_GET['opcion']==10){?>
		    <input type="submit" name="ModificarD" class="btn btn-success btn-lg" value="Modificar D. Integrante" > 
		    <input type="hidden" name="id" value="<?PHP echo $_GET['id']?>">
		  <?PHP }else{?> 
		    <input type="submit" name="GuardarD" class="btn btn-success btn-lg" value="Guardar D. Integrantes" >  
		  <?PHP }?>         
            <input type="hidden" name="mod" value="50">
            <input type="hidden" name="g" value="<?PHP echo $_GET['g']?>">
            <input type="hidden" name="token" value="<?PHP echo $_GET['token']?>">       
          </div>           
        </div>
                    
   </form>     		
  	</div><!-- Final Tab 3 -->  
</div>    
    
        </article>
        <?PHP }## Final de Ingresar?>     


<?PHP if($_GET['mod']==51 and $_GET['opcion']==15 ){	##Cargar Ficha?>

 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Cargar Archivo Escaneado de Ficha Técnica 
		<?PHP $dato=$V_Clase->v_ficha($_GET['token']);
		if($dato[0]['GRUPO']==2){?>Indigena<?PHP }elseif($dato[0]['GRUPO']==1){?>Afrocolombiano<?PHP } ?>
        <?PHP if(isset($_GET['token'])){echo 'Numero: '.base64_decode($_GET['token']);}?></h3>
              </div>
              <div class="panel-body">
               <form class="form-inline" name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                    <label class="sr-only" for="ced">Ingrese Documento Identidad</label>
                    <div class="input-group">
                      <div class="input-group-addon"><span class="glyphicon glyphicon-paperclip"></span></div>
                      <input type="file" id="fileToUpload" name="archivo" required class="form-control">
                      
                    </div>
                  </div>
                  <input type="submit" name="CargarFicha" class="btn btn-success btn-lg" value="Cargar Archivo" >
                  <p class="help-block">Seleccione un archivo.</p>            	
                  <input type="hidden" name="token" id="token" value="<?PHP echo $_GET['token'];?>">
                </form>   

              </div>
            </div>
        </article>        
<?PHP }## Final de Cargar Ficha?> 
<?PHP if($_GET['mod']==51 and $_GET['opcion']==16 ){##Cargar Documento Identidad?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Cargar Archivo Escaneado de Documento Identidad 
		<?PHP $dato=$V_Clase->v_integrantes_id($_GET['token']);?></h3>
              </div>
              <div class="panel-body">
               <form class="form-inline" name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                    <label class="sr-only" for="ced">Ingrese Documento Identidad</label>
                    <div class="input-group">
                      <div class="input-group-addon"><span class="glyphicon glyphicon-paperclip"></span></div>
                      <input type="file" id="fileToUpload" name="archivo" required class="form-control">
                      
                    </div>
                  </div>
                  <input type="submit" name="CargarDI" class="btn btn-success btn-lg" value="Cargar Archivo" >
                    <p class="help-block">Seleccione un archivo.</p>            	
                    <input type="hidden" name="token" id="token" value="<?PHP echo $_GET['token'];?>">
                    <input type="hidden" name="id" id="id" value="<?PHP echo $_GET['id'];?>">
                </form>   

              </div>
            </div>
        </article>        
      
<?PHP }## Final de Cargar Documento Identidad?> 

<?PHP if($_GET['mod']==50 and $_GET['opcion']==14 ){##Mover Integrante?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Mover Integrante a Otra Ficha 
		<?PHP $dato=$V_Clase->v_integrantes_id($_GET['id']);?></h3>
              </div>
              <div class="panel-body">
               <form class="form-inline" name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
               <div class="text-danger bg-danger h3">Actual Ficha: <?PHP echo $dato[0]['A1'];?> | Integrante: <?PHP echo $dato[0]['D1'].' '.$dato[0]['D2'].' '.$dato[0]['D3'].' '.$dato[0]['D4'];;?></div>
                  <div class="form-group">
                    <label class="" for="ficha"></label>
                    <div class="input-group">
                      
                      <input type="text" id="ficha" name="ficha" required class="form-control input-lg" placeholder="Numero Ficha"  onBlur="refre_capa_dos(document.form.ficha.value, 'div_cedula', 'mod_com_ajax.php', '6', document.form.token.value)">
                      
                    </div>
                  </div>
                  <input type="button" name="VerIntegrante" class="btn btn-primary btn-lg" value="Ver Integrante">
                    <p class="help-block">Asegure el Número de Ficha.</p>
                    <div id="div_cedula" class="text-success h3"></div>
                    
                                	
                    <input type="hidden" name="token" id="token" value="<?PHP echo $_GET['token'];?>">
                    <input type="hidden" name="id" id="id" value="<?PHP echo $_GET['id'];?>">
                    
                </form>   

              </div>
            </div>
        </article>        
      
<?PHP }## Final de Mover Integrante FICHAS?> 

<?PHP if($_GET['mod']==50 and $_GET['opcion']==15 ){##Mover Estado Fallecido?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Mover Integrante a Fallecido 
		<?PHP $dato=$V_Clase->v_integrantes_id($_GET['id']);?></h3>
              </div>
              <div class="panel-body">
               <form class="form-inline" name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
					<div class="bg-success text-success h3">Se ha movido a Fallecido el Integrante: 
					<?PHP echo $dato[0]['D1'].' '.$dato[0]['D2'].' '.$dato[0]['D3'].' '.$dato[0]['D4'];
					$V_Clase->v_integrantes_fallecido($_GET['id']);
					?>
                    </div>
                </form>   
              </div>
            </div>
        </article>              
<?PHP }## Final de Mover Estado Fallecido?> 
        
<?PHP if($_GET['mod']==50 and $_GET['opcion']==16 ){##Mover Estado Vivo?>
 		<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Mover Integrante a Fallecido 
		<?PHP $dato=$V_Clase->v_integrantes_id($_GET['id']);?></h3>
              </div>
              <div class="panel-body">
               <form class="form-inline" name="form" action="Ejecutar.php" method="post" enctype="multipart/form-data">
					<div class="bg-success text-success h3">Se ha movido a Vivo el Integrante: 
					<?PHP echo $dato[0]['D1'].' '.$dato[0]['D2'].' '.$dato[0]['D3'].' '.$dato[0]['D4'];
					$V_Clase->v_integrantes_vivo($_GET['id']);
					?>
                    </div>
                </form>   

              </div>
            </div>
        </article>        
      
<?PHP }## Final de Mover Estado Vivo?>         
                  
    </section>
    
</div>
<?PHP $V_Clase->gra_pie_pagina();?>


<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="js/funciones.js"></script>
  <script type="text/javascript">

/*
function upload_image(){//Funcion encargada de enviar el archivo via AJAX
		$(".upload-msg").text('Cargando...');
		var inputFileImage = document.getElementById("fileToUpload");
		var ficha = document.getElementById("token");
		var dato = ficha.value;
		
		var file = inputFileImage.files[0];
		var data = new FormData();
		data.append('fileToUpload',file);
							
	$.ajax({
			url: "upload.php",        // Url to which the request is send
			type: "POST",             // Type of request to be send, called as method
			data: data, 			  // Data sent to server, a set of key/value pairs (i.e. form fields and values)
			contentType: false,       // The content type used when sending data to the server.
			cache: false,             // To unable request pages to be cached
			processData:false,        // To send DOMDocument or non processed data file it is set to false
			success: function(data)   // A function to be called if request succeeds
			{
				$(".upload-msg").html(data);
				window.setTimeout(function() {
				$(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
				$(this).remove();
					});	}, 5000);
				}
			});
				
		}  // Hizo Falta Confirmar el TOKEN
  */
  
  
  
  $( function() {
	$( "#tabs" ).tabs();
	<?PHP if(($_GET['mod']==50 and $_GET['opcion']==2) or ($_GET['mod']==50 and $_GET['opcion']==7)){#tab-1?>
		$("#tabs").tabs({disabled: [1,2,3]}); // 0 Tab-1 1 Tab-2 2 Tab-3 3 Tab-4
	<?PHP }elseif(($_GET['mod']==50 and $_GET['opcion']==3) or ($_GET['mod']==50 and $_GET['opcion']==8)){#tab-2 ?>
		$("#tabs").tabs({disabled: [0,2,3]}); // 0 Tab-1 1 Tab-2 2 Tab-3 3 Tab-4
	<?PHP }elseif(($_GET['mod']==50 and $_GET['opcion']==4) or ($_GET['mod']==50 and $_GET['opcion']==9)){#tab-3 ?>
		$("#tabs").tabs({disabled: [0,1,3]}); // 0 Tab-1 1 Tab-2 2 Tab-3 3 Tab-4
	<?PHP }elseif(($_GET['mod']==50 and $_GET['opcion']==5) or ($_GET['mod']==50 and $_GET['opcion']==10)){#tab-4 ?>
		$("#tabs").tabs({disabled: [0,1,2]}); // 0 Tab-1 1 Tab-2 2 Tab-3 3 Tab-4
	<?PHP }?>
	
$('#B1').change(function(){
	if($(this).val()==8){
		$("#b2-b8").css("display", "none");
		$("#b2-b8-2").css("display", "none");
	}else if($(this).val()==9){
		$("#b2-b8").css("display", "none");
		$("#b2-b8-2").css("display", "none");
	}else{
		$("#b2-b8").css("display", "block");
		$("#b2-b8-2").css("display", "block");	
	}
})

$('#B15').change(function(){
	if($(this).val()==2){
		$("#B16").css("display", "none");
		
	}else{
		$("#B16").css("display", "block");		
	}
})	

$('#B18').change(function(){
	if($(this).val()==2){
		$("#B19").css("display", "none");
		$("#B20").css("display", "none");
		$("#B21").css("display", "none");
	}else{
		$("#B19").css("display", "block");
		$("#B20").css("display", "block");
		$("#B21").css("display", "block");		
	}
})	

$('#B22').change(function(){
	if($(this).val()==2){
		$("#B23").css("display", "none");
		$("#B24").css("display", "none");
	}else{
		$("#B23").css("display", "block");
		$("#B24").css("display", "block");	
	}
})	
	
$('#C10').change(function(){
	if($(this).val()==2){
		$("#C11").css("display", "none");
		$("#C12").css("display", "none");
	}else{
		$("#C11").css("display", "block");
		$("#C12").css("display", "block");	
	}
})					

$('#D17').change(function(){
	if($(this).val()==2){
		$("#D18").css("display", "none");		
	}else{
		$("#D18").css("display", "block");		
	}
})		

$('#D24').change(function(){
	if($(this).val()==3){
		$("#D25").css("display", "none");		
	}else{
		$("#D25").css("display", "block");		
	}
})	

$('#D26').change(function(){
	if($(this).val()==2){
		$("#D27").css("display", "none");		
	}else{
		$("#D27").css("display", "block");		
	}
})			

$('#D28').change(function(){
	if($(this).val()==2){
		$("#D29").css("display", "none");		
	}else{
		$("#D29").css("display", "block");		
	}
})	

$('#D30').change(function(){
	if($(this).val()==2){
		$("#D31").css("display", "none");		
	}else{
		$("#D31").css("display", "block");		
	}
})

$('#D32').change(function(){
	if($(this).val()==2){
		$("#D33").css("display", "none");
		$("#D34").css("display", "block");	
		$("#D35").css("display", "block");		
	}else{
		$("#D33").css("display", "block");
		$("#D34").css("display", "none");
		$("#D35").css("display", "none");			
	}
})		
    //$( document ).tooltip();
    
  } );
	</script> 
<?PHP
}else
{
	echo "<script type='text/javascript'>
		alert('Debe Iniciar Sesion');
		window.location='../index.php';
	</script>";
}	
	?>
</body>
</html>
