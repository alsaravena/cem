<?php
require_once("class/class.php");
$V_Clase= new cTrabajo();
#print_r($_GET);

if($_GET['opcion']==1){## Municipio
	
	$mun=$V_Clase->l_Municipios($_GET["id"]); 
	 ?>
	<select class="form-control input-sm" id="mun" name="mun" title="Seleccione el Municipio...">
	 <option value="0" selected="selected">Seleccione Municipio...</option>
	 <?php
	 for($i=0;$i<sizeof($mun);$i++)
	 {?>
	 <option value="<?php echo $mun[$i]["mun_id"];?>" title="<?php echo $mun[$i]["mun_nombre"];?>"><?php echo $mun[$i]["mun_nombre"];?></option>
	 <?php
	 } ?>
	</select>  
    
<?PHP }## Final de Municipio

if($_GET['opcion']==2){## Municipio
	$trozo= $_GET['id'];  $porciones = explode("-", $trozo); 
	#echo $porciones[0]; // Numero Municipio
	#echo $porciones[1]; // Numero Centro Votacion
	#echo $porciones[2]; // Numero de Mesas
	$V_Clase->comboMesas($porciones[0],$porciones[1],$porciones[2]);
}

if($_GET['opcion']==3){## Validar que Exista

	if($_GET['id']>0){
	$usuario= $V_Clase->v_usuario($_GET['id']);#print_r($usuario);	
	
		if(sizeof($usuario)!=0){
			echo '<div class="alert-danger"><span class="glyphicon glyphicon-alert"></span> ¡Ya Existe Usuario!</div>';	
			echo '<meta http-equiv="refresh" content="3;URL=./CentroControl.php?mod=54&opcion=4&token='.$_GET['id'].'">';
		}else{
			echo '<div class="alert-info"><span class="glyphicon glyphicon-ok"></span> ¡No Existe Usuario!</div>';	
		}
	}
}
### Departamentos del Pais
if($_GET['opcion']==4){## Departamentos
	
	$dep=$V_Clase->l_un_Departamentos($_GET["id"]); 
	 ?>
	<select class="form-control input-sm" id="dep_un" name="dep_un" title="Seleccione el Departamento." onChange ="refre_capa_dos(document.form4.dep_un.value, 'div_mun_un', 'mod_com_ajax.php', '5', document.form4.pais.value)" title="Debe seleccionar">
	 <option value="0" selected="selected">Seleccione Departamento...</option>
	 <?php
	 for($i=0;$i<sizeof($dep);$i++)
	 {?>
	 <option value="<?php echo $dep[$i]["dep_id"];?>" title="<?php echo $dep[$i]["dep_nombre"];?>"><?php echo $dep[$i]["dep_id"];?> - <?php echo $dep[$i]["dep_nombre"];?></option>
	 <?php
	 } ?>
	</select>  
    
<?PHP }## Final de Departamentos


### Municipios  del Pais - Departamento
if($_GET['opcion']==5){## Municipios  del Pais - Departamento

	$mun=$V_Clase->l_un_Municipios($_GET["pais"],$_GET["num"]); 
	 ?>
	<select class="form-control input-sm" id="mun_un" name="mun_un" title="Seleccione el Municipio...">
	 <option value="0" selected="selected">Seleccione Municipio...</option>
	 <?php
	 for($i=0;$i<sizeof($mun);$i++)
	 {?>
	 <option value="<?php echo $mun[$i]["mun_id"];?>" title="<?php echo $mun[$i]["mun_nombre"];?>"><?php echo $mun[$i]["mun_nombre"];?></option>
	 <?php
	 } ?>
	</select> 
<?PHP }## Final de Municipios  del Pais - Departamento 


if($_GET['opcion']==6){## Motrar Ficha?>
<form action="Ejecutar.php" enctype="multipart/form-data" method="post">
        <div class="table-responsive">
<table class="table table-condensed table-hover table-striped">
<thead>
  <tr>
    <th>Ficha</th>
    <th>A17</th> 
    <th>Estado</th> 
    <th>Dirección</th>
  </tr>
</thead>  
<?PHP 
$dato=$V_Clase->pag_fichas_busqueda($_GET['num'],0,50);
## Inicio For Recorrido
for ($i=0;$i<sizeof($dato);$i++){
?>
  <tr>
    <td><?PHP echo $dato[$i]['A1'];?></td>
    <td><?PHP echo $V_Clase->trae_respuesta('A17',$dato[$i]['A17']);?></td>
    <td><?PHP if($dato[$i]['ESTADO']==1){echo '<b class="text-danger">En Edición</b>';
		}elseif($dato[$i]['ESTADO']==2) {echo '<b class="text-success">Terminada</b>';}?></td>
    <td><?PHP echo $dato[$i]['A5'];?></td>  
  </tr>
  <tr>
  <td colspan="4" class="text-center">
  	<input type="submit" name="MoverIntegrante" class="btn btn-success btn-lg" value="Mover Integrante">
    <input type="hidden" name="token" value="<?PHP echo base64_decode($_GET['pais']);?>" />
    <input type="hidden" name="nficha" value="<?PHP echo $_GET['num'];?>" />
  </td>
  </tr>
<?PHP }## Final For Recorrido
if(sizeof($dato) ==0){
 ?>    
<tr>
	<td colspan="4">No hay Datos.</td>
</tr>
<?PHP } ?>
</table>
    	</div>	
</form>	
	
<?PHP }## Final de Municipios  del Pais - Departamento ?

if($_GET['opcion']==7){## Validar que Exista Persona

	if($_GET['id']>0){
	$usuario= $V_Clase->v_integrante($_GET['id']);#print_r($usuario);	
	
		if(sizeof($usuario)!=0){
			echo '<div class="alert-danger text-center h4"><span class="glyphicon glyphicon-alert"></span> ¡Ya Existe Usuario en Ficha Número -- '.$usuario[0]['A1'].' -- , Será redireccionado en 5 Segundos!</div>';	
			echo '<meta http-equiv="refresh" content="6;URL=./VerDatos.php?mod=51&opcion=2&token='.base64_encode($usuario[0]['A1']).'&id='.base64_encode($usuario[0]['ID']).'#i">';
		}else{
			echo '<div class="alert-info text-center h4"><span class="glyphicon glyphicon-ok"></span> ¡No Existe Usuario!</div>';	
		}
	}
}

