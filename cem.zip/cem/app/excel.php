<?php   
require_once("class/class.php");
$V_Clase= new cTrabajo();
$conf=$V_Clase->v_configuracion();

$nombre="Reporte_Exportado_".date("h:i:s")."_".date("d-m-Y").".xls";
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=$nombre");

 // comprobar variables de sesión
if ($_SESSION["user_cedula"] != "" && $_SESSION["user_cedula"]  >= 999999) {
?>
<!DOCTYPE HTML>
<html>
<head>
<!--<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/estilos.css">-->
<title>Caracterización Etnica Municipal | <?PHP  $V_Clase->Guia_Diseno($_GET['mod'],$_GET['opcion']);  ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body>
<?php
### Exportar a Excel Censo Indigenas
#SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'ce_nucleo' AND table_schema = 'bd_caracterizacion'
if($_GET['mod']==54 and $_GET['opcion']==9){ 
#$sql = "SELECT * FROM par_guias WHERE guia_id >0 ORDER BY guia_id";
if($_GET['c']==0){
$sql = "SELECT * FROM  `ce_integrantes`
				INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 
				ORDER BY  ce_nucleo.A1 ASC; ";	
	}elseif($_GET['c']==19){
$sql = "SELECT * FROM  `ce_integrantes`
				INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 
				WHERE ce_nucleo.GRUPO = ".$_GET['token']." 
				ORDER BY  ce_nucleo.A1 ASC; ";
	}else{
$sql = "SELECT * FROM  `ce_integrantes`
				INNER JOIN ce_nucleo ON ce_integrantes.A1 = ce_nucleo.A1 
				WHERE ce_nucleo.A".$_GET['c']." = ".$_GET['token']." 
				ORDER BY  ce_nucleo.A1 ASC; ";
}
$rs = mysql_query($sql,cTrabajo::con()) or die ("Error de consulta");
$numero_campos = mysql_num_fields($rs);
$totalrs= mysql_num_rows ($rs); 
#echo "Cuantos Campos =".$numero_campos;

?>
<table border="1" width="100%">
<thead>
    <tr><?PHP
    for($k=0;$k<$numero_campos;$k++){
    $n_campo = mysql_field_name($rs,$k);?>
        <th><?PHP echo $n_campo;?></th>
    <?PHP
    }?>
    </tr>
</thead>

<?php
for($ir=0;$ir<$totalrs;$ir++){?>
<tr>
	<?PHP 
	for($k=0;$k<$numero_campos;$k++){
	$contenido = mysql_result($rs,$ir,$k);?>
	<td><?PHP echo $contenido;?></td><?PHP 
	}?>
</tr><?PHP	
}
?>
</table> 




<?php } #Final Planilla  Comites de la Entidad ?>

<!-- Archivos Necesario-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php
}else
{
	echo "<script type='text/javascript'>
		alert('Usted no está logueado');
		window.location='ingresar.php';
	</script>";
}
?>