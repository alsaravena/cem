<?php
require_once("app/class/class.php");
$V_Clase= new cTrabajo();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">-->
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minium-scale=1.0">

<meta name="keywords" content="Caracterización Población, Caracterizar">
<meta name="rights" content="Carlos Martinez">
<meta name="author" content="Carlos Martinez asuntosetnicos@saravena-arauca.gov.co">
<meta name="description" content="Caracterizar Población del Municipio de Saravena - Arauca">
<meta name="generator" content="Carlos Martinez">
<link rel="stylesheet" href="app/css/bootstrap.min.css">
<link rel="stylesheet" href="app/css/estilos.css">
<title>Caracterización Étnica Municipal</title>
</head>

<body>
<?php include_once("app/analyticstracking.php") ?>
<div class="jumbotron encabezado">
  <div class="container text-center">
    <h1>Caracterización Étnica Municipal</h1>
  </div>
</div>
<div class="container-fluid">

    <section class="main row">
 		<article class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Ingresar a Software CIE (Caracterización Étnica Municipal)</h3>
              </div>
              <div class="panel-body">
				 <?PHP 
				  if(isset($_GET['token']) and $_GET['token']==15){ session_destroy(); }
				 if(isset($_GET['token']) and $_GET['token']==25){ 
				 
				 if($_POST['oc_cs']  !==  $_POST['cs_user'])
				 {
					 echo "<div class='alert-danger'>
					 <h3><span class='glyphicon glyphicon-remove-sign'></span> Codigo de Seguridad Incorrecto</h3>
					 </div>";
					 echo '<meta http-equiv="refresh" content="0;URL=index.php">';
				 }else{
					 echo "<div class='alert-success'>
					 <h3><span class='glyphicon glyphicon-ok-sign'></span> Codigo de Seguridad Igual</h3>
					 </div>";
				}
				 
				$datoses=$V_Clase->c_usuario_ced_clave($_POST['ced_user'],$_POST['cla_user']);
				
				session_start();   
                $_SESSION["user_cedula"]=$datoses[0]["usua_cedula"]; 				
				$_SESSION["user_nombres"]=$datoses[0]["usua_nombre_completo"]; 
                $_SESSION["user_grupo"]=$datoses[0]["usua_gp"];
				$_SESSION["user_rol"]=$datoses[0]["usua_rol"];
				$_SESSION["user_temporal"]=0;
				if($_SESSION["user_rol"]<=2){$_SESSION['c']='0';}else{$_SESSION['c']='A17';}
				
				$sesion=session_id();
                $info=$V_Clase->detectar();
                $V_Clase->Ins_HistorialAccesos($_SERVER['REMOTE_ADDR'],$_SESSION["user_cedula"],$sesion,$info["browser"], $info["os"]);
				  if (sizeof($datoses) >0) {
					#session_start();
					$_SESSION["user_cedula"]=$datoses[0]['usua_cedula']; 	$_SESSION["user_nombres"]=$datoses[0]['usua_nombre_completo']; 			
					$_SESSION["user_rol"]=$datoses[0]['usua_rol'];
					echo '<div class="alert-success"><span class="glyphicon glyphicon-ok-sign"></span> Ingreso Correcto!!</div>';
					if($_SESSION["user_rol"]==6 or $_SESSION["user_rol"]==5){
						echo '<meta http-equiv="refresh" content="0;URL=app/index.php?mod=54&opcion=13">';
					}else{
						echo '<meta http-equiv="refresh" content="0;URL=app/index.php?mod=54&opcion=13">';
					}
				  }else{
	
					  echo '<script language="javascript">alert ("Validacion Incorrecta")</script>';
					  echo '<meta http-equiv="refresh" content="0;URL=index.php">';
  
				  }
				 }else{$cargar="";} ?>
                <form action="index.php?token=25" method="post" name="form" enctype="multipart/form-data">
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <label for="ced"><b>Usuario</b> &nbsp; <span class="glyphicon glyphicon-user"></span></label>
                    <input type="number" class="form-control" required id="ced" name="ced_user" placeholder="Cedula">
                  </div>
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <label for="cla"><b>Clave</b> &nbsp; <span class="glyphicon glyphicon-lock"></span></label>
                    <input type="password" class="form-control" required id="cla" name="cla_user" placeholder="Clave">
                  </div>
                  <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <label for="cs"><b>Codigo Seguridad</b> &nbsp; </label>
                    <?PHP echo  $cs=rand(10,99);?>
                    <input type="hidden" name="oc_cs" value="<?PHP echo  $cs;?>">
                    <input type="number" class="form-control" required id="cs" name="cs_user" placeholder="Escriba Codigo de Seguridad">
                  </div>                  
                  <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <button type="submit" class="btn btn-primary">Ingresar</button>
                      <button type="reset" class="btn btn-success">Limpiar</button>
                      <!--<a class="btn btn-info" href="index.php?token=15">Cerrar Session</a>-->
                  </div>
                </form>

              </div>
            </div>
        </article>

        

		<article class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <div class="panel panel-primary">

<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="imagenes/inicio1.jpg" alt="Comunidad Indígena" class="img-rounded">
      <div class="carousel-caption">
        Comunidad Indígena
      </div>
    </div>

    <div class="item">
      <img src="imagenes/inicio4.jpg" alt="Comunidad Afro" class="img-rounded">
      <div class="carousel-caption">
        Comunidad Afro
      </div>
    </div> 
    
    <div class="item">
      <img src="imagenes/inicio2.jpg" alt="Comunidad Indígena" class="img-rounded">
      <div class="carousel-caption">
        Comunidad Indígena
      </div>
    </div>

    <div class="item">
      <img src="imagenes/inicio3.jpg" alt="Comunidad Afro" class="img-rounded">
      <div class="carousel-caption">
        Comunidad Afro
      </div>
    </div>    

  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>            

        
  
            
            
  
            </div>
        </article>
       	               
    </section>
    
</div>

<footer class="text-center">Alcaldía Municipal de Saravena - Oficina Asuntos Étnicos - Carlos Martinez</footer>







<!-- Archivos Necesario-->
<script src="app/js/jquery.js"></script>
<script src="app/js/bootstrap.min.js"></script>
<script src="app/js/funciones.js"></script>
</body>
</html>
